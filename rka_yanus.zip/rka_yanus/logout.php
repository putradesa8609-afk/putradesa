<?php
declare(strict_types=1);

require __DIR__ . '/includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(url('login.php'));
}

verifyCsrf($_POST['csrf_token'] ?? null);

logoutUser();

session_start();
setFlash('success', 'Anda telah keluar dari aplikasi.');

redirect(url('login.php'));
