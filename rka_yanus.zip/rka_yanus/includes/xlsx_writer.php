<?php
declare(strict_types=1);

/**
 * Penulis XLSX minimal tanpa ekstensi zip.
 * Hanya mendukung file tersimpan (store) dan gaya yang dipakai rekap belanja.
 */
final class SimpleZip
{
    /** @var array<int, array{name: string, data: string}> */
    private array $entries = [];

    public function add(string $name, string $data): void
    {
        $this->entries[] = ['name' => $name, 'data' => $data];
    }

    public function build(): string
    {
        $waktu = (int) date('H') << 11 | (int) date('i') << 5 | intdiv((int) date('s'), 2);
        $tanggal = ((int) date('Y') - 1980) << 9 | (int) date('n') << 5 | (int) date('j');

        $lokal = '';
        $pusat = '';
        $offset = 0;

        foreach ($this->entries as $entry) {
            $nama = $entry['name'];
            $data = $entry['data'];
            $crc = crc32($data) & 0xFFFFFFFF;
            $ukuran = strlen($data);
            $panjangNama = strlen($nama);

            $header = "PK\x03\x04"
                . pack('v', 20)
                . pack('v', 0)
                . pack('v', 0)
                . pack('v', $waktu)
                . pack('v', $tanggal)
                . pack('V', $crc)
                . pack('V', $ukuran)
                . pack('V', $ukuran)
                . pack('v', $panjangNama)
                . pack('v', 0)
                . $nama;

            $lokal .= $header . $data;

            $pusat .= "PK\x01\x02"
                . pack('v', 20)
                . pack('v', 20)
                . pack('v', 0)
                . pack('v', 0)
                . pack('v', $waktu)
                . pack('v', $tanggal)
                . pack('V', $crc)
                . pack('V', $ukuran)
                . pack('V', $ukuran)
                . pack('v', $panjangNama)
                . pack('v', 0)
                . pack('v', 0)
                . pack('v', 0)
                . pack('v', 0)
                . pack('V', 0)
                . pack('V', $offset)
                . $nama;

            $offset += strlen($header) + $ukuran;
        }

        $jumlah = count($this->entries);

        $akhir = "PK\x05\x06"
            . pack('v', 0)
            . pack('v', 0)
            . pack('v', $jumlah)
            . pack('v', $jumlah)
            . pack('V', strlen($pusat))
            . pack('V', $offset)
            . pack('v', 0);

        return $lokal . $pusat . $akhir;
    }
}

final class XlsxWorkbook
{
    public const STYLE_DEFAULT = 0;
    public const STYLE_TITLE = 1;
    public const STYLE_SUBTITLE = 2;
    public const STYLE_HEADER = 3;
    public const STYLE_TEXT = 4;
    public const STYLE_TEXT_BOLD = 5;
    public const STYLE_NUMBER = 6;
    public const STYLE_INTEGER = 7;
    public const STYLE_TOTAL_TEXT = 8;
    public const STYLE_TOTAL_INTEGER = 9;
    public const STYLE_TOTAL_DECIMAL = 10;

    /** @var XlsxSheet[] */
    private array $sheets = [];

    public function addSheet(XlsxSheet $sheet): void
    {
        $this->sheets[] = $sheet;
    }

    public function build(): string
    {
        $zip = new SimpleZip();
        $zip->add('[Content_Types].xml', $this->contentTypes());
        $zip->add('_rels/.rels', $this->rootRelations());
        $zip->add('xl/workbook.xml', $this->workbookXml());
        $zip->add('xl/_rels/workbook.xml.rels', $this->workbookRelations());
        $zip->add('xl/styles.xml', $this->stylesXml());

        foreach ($this->sheets as $i => $sheet) {
            $zip->add('xl/worksheets/sheet' . ($i + 1) . '.xml', $sheet->build());
        }

        return $zip->build();
    }

    private function contentTypes(): string
    {
        $sheets = '';

        foreach ($this->sheets as $i => $sheet) {
            $sheets .= '<Override PartName="/xl/worksheets/sheet' . ($i + 1) . '.xml"'
                . ' ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
        }

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml"'
            . ' ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/styles.xml"'
            . ' ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            . $sheets
            . '</Types>';
    }

    private function rootRelations(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1"'
            . ' Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"'
            . ' Target="xl/workbook.xml"/>'
            . '</Relationships>';
    }

    private function workbookXml(): string
    {
        $sheets = '';

        foreach ($this->sheets as $i => $sheet) {
            $sheets .= '<sheet name="' . XlsxSheet::escape($sheet->name()) . '"'
                . ' sheetId="' . ($i + 1) . '" r:id="rId' . ($i + 1) . '"/>';
        }

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
            . ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<bookViews><workbookView/></bookViews>'
            . '<sheets>' . $sheets . '</sheets>'
            . '</workbook>';
    }

    private function workbookRelations(): string
    {
        $rels = '';

        foreach ($this->sheets as $i => $sheet) {
            $rels .= '<Relationship Id="rId' . ($i + 1) . '"'
                . ' Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"'
                . ' Target="worksheets/sheet' . ($i + 1) . '.xml"/>';
        }

        $rels .= '<Relationship Id="rId' . (count($this->sheets) + 1) . '"'
            . ' Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles"'
            . ' Target="styles.xml"/>';

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . $rels
            . '</Relationships>';
    }

    private function stylesXml(): string
    {
        $border = '<border><left style="thin"><color rgb="FFB7C3D0"/></left>'
            . '<right style="thin"><color rgb="FFB7C3D0"/></right>'
            . '<top style="thin"><color rgb="FFB7C3D0"/></top>'
            . '<bottom style="thin"><color rgb="FFB7C3D0"/></bottom>'
            . '<diagonal/></border>';

        $fonts = '<fonts count="5">'
            . '<font><sz val="11"/><color theme="1"/><name val="Calibri"/><family val="2"/></font>'
            . '<font><b/><sz val="11"/><color theme="1"/><name val="Calibri"/><family val="2"/></font>'
            . '<font><i/><sz val="10"/><color rgb="FF555555"/><name val="Calibri"/><family val="2"/></font>'
            . '<font><b/><sz val="16"/><color rgb="FF1F4E79"/><name val="Calibri"/><family val="2"/></font>'
            . '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/><family val="2"/></font>'
            . '</fonts>';

        $fills = '<fills count="4">'
            . '<fill><patternFill patternType="none"/></fill>'
            . '<fill><patternFill patternType="gray125"/></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FF1F4E79"/><bgColor indexed="64"/></patternFill></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FFDCE6F1"/><bgColor indexed="64"/></patternFill></fill>'
            . '</fills>';

        $borders = '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>'
            . $border
            . '</borders>';

        $xf = static function (
            int $numFmt,
            int $font,
            int $fill,
            int $border,
            ?string $horizontal = null,
            string $vertical = 'top',
            bool $wrap = false
        ): string {
            $alignment = '';

            if ($horizontal !== null || $wrap || $vertical !== '') {
                $alignment = '<alignment'
                    . ($horizontal !== null ? ' horizontal="' . $horizontal . '"' : '')
                    . ' vertical="' . $vertical . '"'
                    . ($wrap ? ' wrapText="1"' : '')
                    . '/>';
            }

            return '<xf numFmtId="' . $numFmt . '" fontId="' . $font . '" fillId="' . $fill
                . '" borderId="' . $border . '" xfId="0"'
                . ($numFmt > 0 ? ' applyNumberFormat="1"' : '')
                . ($font > 0 ? ' applyFont="1"' : '')
                . ($fill > 0 ? ' applyFill="1"' : '')
                . ($border > 0 ? ' applyBorder="1"' : '')
                . ' applyAlignment="1">'
                . $alignment
                . '</xf>';
        };

        $cellXfs = '<cellXfs count="11">'
            . $xf(0, 0, 0, 0)
            . $xf(0, 3, 0, 0, null, 'center')
            . $xf(0, 2, 0, 0)
            . $xf(0, 4, 2, 1, 'center', 'center', true)
            . $xf(0, 0, 0, 1, null, 'top', true)
            . $xf(0, 1, 0, 1, null, 'top', true)
            . $xf(165, 0, 0, 1, 'right')
            . $xf(164, 0, 0, 1, 'right')
            . $xf(0, 1, 3, 1, null, 'center')
            . $xf(164, 1, 3, 1, 'right', 'center')
            . $xf(165, 1, 3, 1, 'right', 'center')
            . '</cellXfs>';

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<numFmts count="2">'
            . '<numFmt numFmtId="164" formatCode="#,##0"/>'
            . '<numFmt numFmtId="165" formatCode="#,##0.00"/>'
            . '</numFmts>'
            . $fonts
            . $fills
            . $borders
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . $cellXfs
            . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            . '</styleSheet>';
    }
}

final class XlsxSheet
{
    private string $name;
    /** @var float[] */
    private array $widths;
    private int $freezeRows = 0;
    private int $row = 0;
    private int $col = 0;
    /** @var string[] */
    private array $merges = [];
    private string $rowsXml = '';
    private bool $rowOpen = false;

    public function __construct(string $name, array $widths = [])
    {
        $this->name = $name;
        $this->widths = $widths;
    }

    public function name(): string
    {
        return $this->name;
    }

    public function freezeRows(int $jumlah): void
    {
        $this->freezeRows = max(0, $jumlah);
    }

    public static function escape(string $teks): string
    {
        $teks = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $teks) ?? '';

        return htmlspecialchars($teks, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }

    public function addEmptyRow(): void
    {
        $this->startRow();
        $this->endRow();
    }

    public function addMergedRow(string $teks, int $span, int $style): void
    {
        $this->startRow();

        $this->rowsXml .= '<c r="' . $this->ref() . '" s="' . $style . '" t="inlineStr"><is><t xml:space="preserve">'
            . self::escape($teks) . '</t></is></c>';

        if ($span > 1) {
            $this->merges[] = 'A' . $this->row . ':' . self::column($span - 1) . $this->row;
        }

        $this->endRow();
    }

    public function startRow(): void
    {
        $this->row++;
        $this->col = 0;
        $this->rowsXml .= '<row r="' . $this->row . '">';
        $this->rowOpen = true;
    }

    public function endRow(): void
    {
        if (!$this->rowOpen) {
            return;
        }

        $this->rowsXml .= '</row>';
        $this->rowOpen = false;
    }

    public function string(string $teks, int $style = XlsxWorkbook::STYLE_TEXT): void
    {
        $ref = $this->ref();
        $this->col++;

        if ($teks === '') {
            $this->rowsXml .= '<c r="' . $ref . '" s="' . $style . '"/>';

            return;
        }

        $this->rowsXml .= '<c r="' . $ref . '" s="' . $style . '" t="inlineStr"><is><t xml:space="preserve">'
            . self::escape($teks) . '</t></is></c>';
    }

    public function number(float|int|string $nilai, int $style = XlsxWorkbook::STYLE_NUMBER): void
    {
        $ref = $this->ref();
        $this->col++;

        $angka = (float) $nilai;

        if (!is_finite($angka)) {
            $angka = 0.0;
        }

        $teks = rtrim(rtrim(number_format($angka, 6, '.', ''), '0'), '.');

        if ($teks === '' || $teks === '-') {
            $teks = '0';
        }

        $this->rowsXml .= '<c r="' . $ref . '" s="' . $style . '"><v>' . $teks . '</v></c>';
    }

    public function build(): string
    {
        $this->endRow();

        $cols = '';

        foreach ($this->widths as $i => $lebar) {
            $kolom = $i + 1;
            $cols .= '<col min="' . $kolom . '" max="' . $kolom . '" width="' . $lebar . '" customWidth="1"/>';
        }

        $views = '<sheetViews><sheetView workbookViewId="0">';

        if ($this->freezeRows > 0) {
            $views .= '<pane ySplit="' . $this->freezeRows . '"'
                . ' topLeftCell="A' . ($this->freezeRows + 1) . '"'
                . ' activePane="bottomLeft" state="frozen"/>';
        }

        $views .= '</sheetView></sheetViews>';

        $merges = '';

        if (!empty($this->merges)) {
            $merges = '<mergeCells count="' . count($this->merges) . '">';

            foreach ($this->merges as $rentang) {
                $merges .= '<mergeCell ref="' . $rentang . '"/>';
            }

            $merges .= '</mergeCells>';
        }

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . $views
            . '<sheetFormatPr defaultRowHeight="15"/>'
            . ($cols !== '' ? '<cols>' . $cols . '</cols>' : '')
            . '<sheetData>' . $this->rowsXml . '</sheetData>'
            . $merges
            . '</worksheet>';
    }

    private function ref(): string
    {
        return self::column($this->col) . $this->row;
    }

    private static function column(int $index): string
    {
        $nama = '';

        for ($n = $index + 1; $n > 0; $n = intdiv($n - 1, 26)) {
            $nama = chr(65 + (($n - 1) % 26)) . $nama;
        }

        return $nama;
    }
}
