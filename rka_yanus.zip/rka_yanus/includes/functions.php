<?php
declare(strict_types=1);

date_default_timezone_set('Asia/Jakarta');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

/* ---------------------------------------------------------------------
 * Dasar: escape, format, URL
 * ------------------------------------------------------------------- */

function e(mixed $value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function ringkasTeks(?string $teks, int $maks = 50): string
{
    $teks = trim((string) $teks);

    if ($teks === '' || mb_strlen($teks, 'UTF-8') <= $maks) {
        return $teks;
    }

    return rtrim(mb_substr($teks, 0, max(1, $maks - 1), 'UTF-8')) . '…';
}

function rupiah(int|float|string|null $nilai): string
{
    return 'Rp ' . number_format((float) ($nilai ?? 0), 0, ',', '.');
}

function rupiahRingkas(int|float|string|null $nilai): string
{
    $n = (float) ($nilai ?? 0);
    $abs = abs($n);

    if ($abs >= 1_000_000_000_000) {
        return 'Rp ' . number_format($n / 1_000_000_000_000, 2, ',', '.') . ' T';
    }
    if ($abs >= 1_000_000_000) {
        return 'Rp ' . number_format($n / 1_000_000_000, 2, ',', '.') . ' M';
    }
    if ($abs >= 1_000_000) {
        return 'Rp ' . number_format($n / 1_000_000, 2, ',', '.') . ' jt';
    }

    return rupiah($n);
}

function persen(null|int|float|string $nilai, int $desimal = 2): string
{
    if ($nilai === null) {
        return '-';
    }

    return number_format((float) $nilai, $desimal, ',', '.') . '%';
}

function tanggalIndo(?string $tanggal): string
{
    if ($tanggal === null || $tanggal === '' || $tanggal === '0000-00-00') {
        return '-';
    }

    $d = DateTime::createFromFormat('Y-m-d', substr($tanggal, 0, 10));

    return $d ? $d->format('d-m-Y') : '-';
}

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

/**
 * Folder aplikasi dihitung otomatis, sehingga aplikasi tetap jalan
 * walau nama folder di htdocs diganti.
 */
function basePath(): string
{
    static $base = null;

    if ($base !== null) {
        return $base;
    }

    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $dir = $script === '' ? '' : dirname($script);

    if (preg_match('#/(pages|includes)$#', $dir) === 1) {
        $dir = dirname($dir);
    }

    if ($dir === '/' || $dir === '.' || $dir === '\\') {
        $dir = '';
    }

    $base = rtrim($dir, '/');

    return $base;
}

function url(string $path = ''): string
{
    return basePath() . '/' . ltrim($path, '/');
}

/* ---------------------------------------------------------------------
 * Pesan flash (toast)
 * ------------------------------------------------------------------- */

function setFlash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function getFlashes(): array
{
    $flash = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);

    return $flash;
}

function renderFlashes(): void
{
    foreach (getFlashes() as $f) {
        $type = in_array($f['type'], ['success', 'danger', 'warning', 'info'], true)
            ? $f['type']
            : 'info';

        echo '<div class="toast toast-' . $type . '" role="status">';
        echo '<span class="toast-text">' . e($f['message']) . '</span>';
        echo '<button type="button" class="toast-close" aria-label="Tutup">&times;</button>';
        echo '</div>';
    }
}

/* ---------------------------------------------------------------------
 * CSRF
 * ------------------------------------------------------------------- */

function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function verifyCsrf(?string $token): void
{
    if (
        !is_string($token) ||
        !isset($_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $token)
    ) {
        http_response_code(403);
        exit('Permintaan tidak valid. Silahkan muat ulang halaman.');
    }
}

/* ---------------------------------------------------------------------
 * Autentikasi & hak akses
 * ------------------------------------------------------------------- */

function isLoggedIn(): bool
{
    return isset($_SESSION['rka_user_id']);
}

function currentUser(): ?array
{
    static $user = null;

    if ($user !== null) {
        return $user;
    }

    if (!isset($_SESSION['rka_user_id'])) {
        return null;
    }

    global $pdo;

    $stmt = $pdo->prepare(
        'SELECT id, nama, username, peran, status
        FROM pengguna
        WHERE id = :id'
    );
    $stmt->execute([':id' => (int) $_SESSION['rka_user_id']]);
    $row = $stmt->fetch();

    if (!$row || $row['status'] !== 'AKTIF') {
        unset($_SESSION['rka_user_id'], $_SESSION['rka_user_nama'], $_SESSION['rka_user_peran']);
        return null;
    }

    $user = $row;

    return $user;
}

function requireLogin(): void
{
    if (currentUser() !== null) {
        return;
    }

    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'] ?? null;
    setFlash('warning', 'Silahkan masuk terlebih dahulu.');
    redirect(url('login.php'));
}

function peranLabel(string $peran): string
{
    return match ($peran) {
        'ADMIN'       => 'Administrator',
        'OPERATOR'    => 'Operator',
        'VERIFIKATOR' => 'Verifikator',
        'PIMPINAN'    => 'Pimpinan',
        default       => $peran,
    };
}

function requireRole(string ...$roles): void
{
    $user = currentUser();

    if ($user === null) {
        requireLogin();
    }

    if (!in_array($user['peran'], $roles, true)) {
        http_response_code(403);
        $judul = 'Akses Ditolak';
        $pesan = 'Peran Anda (' . peranLabel($user['peran'])
            . ') tidak memiliki izin untuk membuka halaman ini.';
        require __DIR__ . '/akses_ditolak.php';
        exit;
    }
}

function canManage(): bool
{
    $user = currentUser();

    return $user !== null
        && in_array($user['peran'], ['ADMIN', 'OPERATOR'], true);
}

function requireManage(): void
{
    requireRole('ADMIN', 'OPERATOR');
}

function isAdmin(): bool
{
    $user = currentUser();

    return $user !== null && $user['peran'] === 'ADMIN';
}

function loginUser(array $pengguna): void
{
    session_regenerate_id(true);
    $_SESSION['rka_user_id'] = (int) $pengguna['id'];
    $_SESSION['rka_user_nama'] = $pengguna['nama'];
    $_SESSION['rka_user_peran'] = $pengguna['peran'];
    unset($_SESSION['csrf_token']);
}

function logoutUser(): void
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            [
                'expires'  => time() - 42000,
                'path'     => $params['path'],
                'domain'   => $params['domain'],
                'secure'   => (bool) $params['secure'],
                'httponly' => (bool) $params['httponly'],
                'samesite' => 'Lax',
            ]
        );
    }

    session_destroy();
}

/* ---------------------------------------------------------------------
 * Tampilan status
 * ------------------------------------------------------------------- */

function statusBadge(?string $status): string
{
    $status = (string) $status;

    $kelas = match ($status) {
        'DRAFT'                     => 'badge-draft',
        'AKTIF', 'BERJALAN'         => 'badge-aktif',
        'SELESAI'                   => 'badge-selesai',
        'DIBATALKAN', 'NONAKTIF'    => 'badge-batal',
        default                     => 'badge-netral',
    };

    $label = ucwords(strtolower(str_replace('_', ' ', $status)));

    return '<span class="badge ' . $kelas . '">' . e($label) . '</span>';
}

/* ---------------------------------------------------------------------
 * Kategori belanja
 * ------------------------------------------------------------------- */

function kategoriBelanjaOptions(): array
{
    return [
        'BARANG'           => 'Belanja Barang',
        'JASA'             => 'Belanja Jasa',
        'MODAL'            => 'Belanja Modal',
        'PERJALANAN_DINAS' => 'Belanja Perjalanan Dinas',
        'PEMELIHARAAN'     => 'Belanja Pemeliharaan',
    ];
}

function kategoriBelanjaLabel(?string $kode): string
{
    if ($kode === null || $kode === '') {
        return 'Belum Ditentukan';
    }

    return kategoriBelanjaOptions()[$kode] ?? $kode;
}

/* ---------------------------------------------------------------------
 * Perhitungan realisasi
 * ------------------------------------------------------------------- */

function ringkasRealisasi(string|float|null $pagu, string|float|null $realisasi): array
{
    $pagu = round((float) $pagu, 2);
    $realisasi = round((float) $realisasi, 2);
    $sisa = round($pagu - $realisasi, 2);
    $persen = $pagu > 0 ? round($realisasi / $pagu * 100, 2) : 0.0;

    if ($realisasi <= 0) {
        $status = ['Belum Realisasi', '#6b7280'];
    } elseif ($realisasi > $pagu) {
        $status = ['Melebihi Pagu', '#b91c1c'];
    } elseif ($sisa == 0.0) {
        $status = ['Terealisasi Penuh', '#15803d'];
    } else {
        $status = ['Berjalan', '#b45309'];
    }

    return [
        'realisasi' => $realisasi,
        'sisa'      => $sisa,
        'persen'    => $persen,
        'label'     => $status[0],
        'warna'     => $status[1],
    ];
}

/**
 * Kumpulkan peringatan untuk satu baris realisasi.
 * Butuh kolom: status, nilai_realisasi, total_dibayar,
 * tanggal_selesai, nomor_bast.
 */
function peringatanRealisasi(array $r): array
{
    $hasil = [];

    if (($r['status'] ?? '') === 'DIBATALKAN') {
        return $hasil;
    }

    $nilai = (float) ($r['nilai_realisasi'] ?? 0);
    $dibayar = (float) ($r['total_dibayar'] ?? 0);

    if ($dibayar > $nilai) {
        $hasil[] = [
            'level' => 'bahaya',
            'teks'  => 'Total pembayaran melebihi nilai realisasi.',
        ];
    }

    $bastKosong = trim((string) ($r['nomor_bast'] ?? '')) === '';
    $status = $r['status'] ?? '';

    if (!empty($r['tanggal_selesai']) && $bastKosong) {
        $hariIni = new DateTimeImmutable('today');
        $selesai = new DateTimeImmutable($r['tanggal_selesai']);
        $selisih = (int) $hariIni->diff($selesai)->format('%r%a');

        if ($selisih < 0 && in_array($status, ['BERJALAN', 'SELESAI'], true)) {
            $hasil[] = [
                'level' => 'bahaya',
                'teks'  => 'Masa pelaksanaan sudah berakhir '
                         . abs($selisih) . ' hari lalu, tetapi BAST belum diisi.',
            ];
        } elseif ($status === 'BERJALAN' && $selisih === 0) {
            $hasil[] = [
                'level' => 'peringatan',
                'teks'  => 'Masa pelaksanaan berakhir hari ini.',
            ];
        } elseif ($status === 'BERJALAN' && $selisih >= 1 && $selisih <= 7) {
            $hasil[] = [
                'level' => 'peringatan',
                'teks'  => 'Masa pelaksanaan berakhir dalam ' . $selisih . ' hari.',
            ];
        } elseif ($status === 'BERJALAN' && $selisih >= 8 && $selisih <= 14) {
            $hasil[] = [
                'level' => 'info',
                'teks'  => 'Masa pelaksanaan berakhir dalam ' . $selisih . ' hari.',
            ];
        }
    }

    return $hasil;
}

function gayaPeringatan(string $level): string
{
    return match ($level) {
        'bahaya'     => 'background:#fde8e7;color:#8f1d18',
        'peringatan' => 'background:#fef3c7;color:#92400e',
        default      => 'background:#e0f2fe;color:#075985',
    };
}
