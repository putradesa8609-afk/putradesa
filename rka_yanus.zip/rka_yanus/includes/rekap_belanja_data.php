<?php
declare(strict_types=1);

/**
 * Ambil seluruh transaksi belanja beserta ringkasan per kategori.
 * $kategoriFilter: '' = semua, 'NONE' = belum ditentukan, atau kode ENUM.
 */
function ambilRekapBelanja(PDO $pdo, int $tahunFilter, string $kategoriFilter): array
{
    $sql = 'SELECT
            ra.id,
            ra.kode_rup,
            ra.uraian,
            ra.kategori_belanja,
            ra.volume,
            ra.harga_satuan,
            ra.kena_ppn,
            ra.tarif_ppn,
            ra.total_dasar,
            ra.nilai_ppn,
            ra.total_pagu,
            ra.status,
            k.tahun_anggaran,
            sk.kode_sub_kegiatan,
            sk.nama_sub_kegiatan,
            k.kode_kegiatan,
            k.nama_kegiatan,
            mr.kode_rekening,
            mr.nama_rekening,
            ms.nama_satuan,
            COALESCE(vr.total_realisasi, 0) AS total_realisasi,
            COALESCE(vr.sisa_pagu, ra.total_pagu) AS sisa_pagu,
            (
                SELECT COUNT(*)
                FROM realisasi_anggaran AS r
                WHERE r.rincian_anggaran_id = ra.id AND r.status <> \'DIBATALKAN\'
            ) AS jumlah_realisasi,
            (
                SELECT COALESCE(SUM(p.jumlah_dibayar), 0)
                FROM realisasi_anggaran AS r
                INNER JOIN realisasi_pembayaran AS p ON p.realisasi_id = r.id
                WHERE r.rincian_anggaran_id = ra.id AND r.status <> \'DIBATALKAN\'
            ) AS total_dibayar
        FROM rincian_anggaran AS ra
        INNER JOIN sub_kegiatan AS sk ON sk.id = ra.sub_kegiatan_id
        INNER JOIN kegiatan AS k ON k.id = sk.kegiatan_id
        INNER JOIN master_rekening AS mr ON mr.id = ra.rekening_id
        INNER JOIN master_satuan AS ms ON ms.id = ra.satuan_id
        LEFT JOIN v_rincian_ringkasan AS vr ON vr.rincian_id = ra.id';

    $where = [];
    $params = [];

    if ($tahunFilter > 0) {
        $where[] = 'k.tahun_anggaran = :tahun';
        $params[':tahun'] = $tahunFilter;
    }

    if ($kategoriFilter === 'NONE') {
        $where[] = 'ra.kategori_belanja IS NULL';
    } elseif ($kategoriFilter !== '') {
        $where[] = 'ra.kategori_belanja = :kategori';
        $params[':kategori'] = $kategoriFilter;
    }

    if (!empty($where)) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }

    $sql .= ' ORDER BY
        CASE ra.kategori_belanja
            WHEN \'BARANG\' THEN 1
            WHEN \'JASA\' THEN 2
            WHEN \'MODAL\' THEN 3
            WHEN \'PERJALANAN_DINAS\' THEN 4
            WHEN \'PEMELIHARAAN\' THEN 5
            ELSE 6
        END ASC,
        k.tahun_anggaran DESC,
        ra.kode_rup ASC,
        ra.id ASC';

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    $ringkasan = [];

    foreach (kategoriBelanjaOptions() as $kode => $label) {
        $ringkasan[$kode] = [
            'label'     => $label,
            'jumlah'    => 0,
            'pagu'      => 0.0,
            'realisasi' => 0.0,
            'dibayar'   => 0.0,
            'sisa'      => 0.0,
        ];
    }

    $ringkasan['NONE'] = [
        'label'     => 'Belum Ditentukan',
        'jumlah'    => 0,
        'pagu'      => 0.0,
        'realisasi' => 0.0,
        'dibayar'   => 0.0,
        'sisa'      => 0.0,
    ];

    $totalItem = 0;
    $totalPagu = 0.0;
    $totalRealisasi = 0.0;
    $totalDibayar = 0.0;
    $totalSisa = 0.0;

    foreach ($rows as $row) {
        $kode = $row['kategori_belanja'] ?? 'NONE';
        $kode = isset($ringkasan[$kode]) ? $kode : 'NONE';

        $pagu = (float) $row['total_pagu'];
        $realisasi = (float) $row['total_realisasi'];
        $dibayar = (float) $row['total_dibayar'];
        $sisa = (float) $row['sisa_pagu'];

        $ringkasan[$kode]['jumlah']++;
        $ringkasan[$kode]['pagu'] += $pagu;
        $ringkasan[$kode]['realisasi'] += $realisasi;
        $ringkasan[$kode]['dibayar'] += $dibayar;
        $ringkasan[$kode]['sisa'] += $sisa;

        $totalItem++;
        $totalPagu += $pagu;
        $totalRealisasi += $realisasi;
        $totalDibayar += $dibayar;
        $totalSisa += $sisa;
    }

    return [
        'rows'             => $rows,
        'ringkasan'        => $ringkasan,
        'total_item'       => $totalItem,
        'total_pagu'       => $totalPagu,
        'total_realisasi'  => $totalRealisasi,
        'total_dibayar'    => $totalDibayar,
        'total_sisa'       => $totalSisa,
    ];
}
