<?php
$pageTitle = $pageTitle ?? 'Dashboard';
$currentPage = $currentPage ?? '';
$user = currentUser();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Aplikasi Rencana Kerja dan Anggaran Yanus">
    <title><?= e($pageTitle) ?> | RKA YANUS</title>
    <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body>
<header class="app-header">
    <a class="brand" href="<?= e(url('index.php')) ?>">
        <span class="brand-mark">RKA</span>
        <span class="brand-text">
            <strong>RKA YANUS</strong>
            <small>Rencana Kerja dan Anggaran</small>
        </span>
    </a>

    <div class="app-header-actions">
        <button
            type="button"
            class="btn btn-outline btn-sm sidebar-toggle"
            data-sidebar-toggle
            aria-controls="appSidebar"
            aria-expanded="false"
        >Menu</button>

        <?php if ($user !== null): ?>
            <a class="user-chip" href="<?= e(url('pages/profil.php')) ?>" title="Profil saya">
                <span class="user-avatar">
                    <?= e(mb_strtoupper(mb_substr($user['nama'], 0, 1))) ?>
                </span>
                <span class="user-meta">
                    <strong><?= e($user['nama']) ?></strong>
                    <small><?= e(peranLabel($user['peran'])) ?></small>
                </span>
            </a>

            <form method="post" action="<?= e(url('logout.php')) ?>" class="inline-form">
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <button type="submit" class="btn btn-outline btn-sm">Keluar</button>
            </form>
        <?php endif; ?>
    </div>
</header>

<div class="toast-stack" aria-live="polite">
    <?php renderFlashes(); ?>
</div>

<div class="app-layout">
