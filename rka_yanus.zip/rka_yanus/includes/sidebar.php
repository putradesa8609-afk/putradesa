<?php
$currentPage = $currentPage ?? '';
$user = currentUser();

$menu = [
    'Utama' => [
        ['key' => 'dashboard',  'label' => 'Dashboard',      'file' => 'index.php',              'admin' => false],
    ],
    'Master Data' => [
        ['key' => 'kegiatan',     'label' => 'Kegiatan',     'file' => 'pages/kegiatan.php',     'admin' => false],
        ['key' => 'sub_kegiatan', 'label' => 'Sub Kegiatan', 'file' => 'pages/sub_kegiatan.php', 'admin' => false],
        ['key' => 'rekening',     'label' => 'Kode Rekening', 'file' => 'pages/rekening.php',    'admin' => false],
    ],
    'Transaksi' => [
        ['key' => 'anggaran',   'label' => 'Rincian Anggaran', 'file' => 'pages/anggaran.php',   'admin' => false],
        ['key' => 'realisasi',  'label' => 'Realisasi',        'file' => 'pages/realisasi.php',  'admin' => false],
        ['key' => 'pembayaran', 'label' => 'Pembayaran',       'file' => 'pages/pembayaran.php', 'admin' => false],
        ['key' => 'perjalanan_dinas', 'label' => 'Perjalanan Dinas', 'file' => 'pages/perjalanan_dinas.php', 'admin' => false],
    ],
    'Laporan' => [
        ['key' => 'rekap_belanja', 'label' => 'Rekap Belanja', 'file' => 'pages/rekap_belanja.php', 'admin' => false],
        ['key' => 'rekap_penyedia', 'label' => 'Rekap Penyedia', 'file' => 'pages/rekap_penyedia.php', 'admin' => false],
    ],
];
?>
<aside class="sidebar" id="appSidebar">
    <nav class="sidebar-nav">
        <?php foreach ($menu as $grup => $items): ?>
            <div class="sidebar-group">
                <p class="sidebar-heading"><?= e($grup) ?></p>

                <?php foreach ($items as $item): ?>
                    <a
                        href="<?= e(url($item['file'])) ?>"
                        class="sidebar-link<?= $currentPage === $item['key'] ? ' active' : '' ?>"
                        <?= $currentPage === $item['key'] ? 'aria-current="page"' : '' ?>
                    >
                        <?= e($item['label']) ?>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>

        <div class="sidebar-group">
            <p class="sidebar-heading">Pengaturan</p>
            <a
                href="<?= e(url('pages/profil.php')) ?>"
                class="sidebar-link<?= $currentPage === 'profil' ? ' active' : '' ?>"
            >Profil Saya</a>

            <?php if (($user['peran'] ?? '') === 'ADMIN'): ?>
                <a
                    href="<?= e(url('pages/pengguna.php')) ?>"
                    class="sidebar-link<?= $currentPage === 'pengguna' ? ' active' : '' ?>"
                >Kelola Pengguna</a>
            <?php endif; ?>
        </div>
    </nav>

    <div class="sidebar-footer">
        <span>Sesi: <?= e($user['nama'] ?? '-') ?></span>
        <span class="text-muted">&copy; <?= date('Y') ?></span>
    </div>
</aside>
