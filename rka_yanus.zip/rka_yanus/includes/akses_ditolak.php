<?php
/** Halaman 403 sederhana, dipakai oleh requireRole(). */
if (!function_exists('e')) {
    http_response_code(403);
    exit('Akses ditolak.');
}

$judul = $judul ?? 'Akses Ditolak';
$pesan = $pesan ?? 'Anda tidak memiliki izin membuka halaman ini.';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($judul) ?> | RKA YANUS</title>
    <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body class="auth-page">
    <main class="auth-card auth-card--narrow">
        <h1><?= e($judul) ?></h1>
        <p class="text-muted"><?= e($pesan) ?></p>
        <p>
            <a class="btn" href="<?= e(url('index.php')) ?>">Kembali ke Dashboard</a>
        </p>
    </main>
</body>
</html>
