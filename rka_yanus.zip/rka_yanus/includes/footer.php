</div><!-- /.app-layout -->

<div class="sidebar-backdrop" data-sidebar-close></div>

<footer class="app-footer">
    <span>RKA Yanus &copy; <?= date('Y') ?></span>
    <span class="text-muted">Rencana Kerja dan Anggaran &middot; Sistem Informasi Anggaran</span>
</footer>

<script src="<?= e(url('assets/js/app.js')) ?>"></script>
</body>
</html>
