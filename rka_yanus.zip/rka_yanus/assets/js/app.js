/* =====================================================================
   RKA YANUS - skrip bersama
   ===================================================================== */
(function () {
    'use strict';

    /* -----------------------------------------------------------------
     * Sidebar (mobile)
     * --------------------------------------------------------------- */
    var body = document.body;

    function tutupSidebar() {
        body.classList.remove('sidebar-open');

        document.querySelectorAll('[data-sidebar-toggle]').forEach(function (btn) {
            btn.setAttribute('aria-expanded', 'false');
        });
    }

    document.querySelectorAll('[data-sidebar-toggle]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var terbuka = body.classList.toggle('sidebar-open');
            btn.setAttribute('aria-expanded', terbuka ? 'true' : 'false');
        });
    });

    document.querySelectorAll('[data-sidebar-close]').forEach(function (el) {
        el.addEventListener('click', tutupSidebar);
    });

    document.addEventListener('keydown', function (ev) {
        if (ev.key === 'Escape') {
            tutupSidebar();
        }
    });

    window.addEventListener('resize', function () {
        if (window.innerWidth > 800) {
            tutupSidebar();
        }
    });

    /* -----------------------------------------------------------------
     * Toast
     * --------------------------------------------------------------- */
    document.querySelectorAll('.toast').forEach(function (toast) {
        var tombol = toast.querySelector('.toast-close');

        function remove() {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }

        if (tombol) {
            tombol.addEventListener('click', remove);
        }

        window.setTimeout(remove, 7000);
    });

    /* -----------------------------------------------------------------
     * Konfirmasi tindakan berbahaya
     * --------------------------------------------------------------- */
    document.querySelectorAll('form[data-confirm]').forEach(function (form) {
        form.addEventListener('submit', function (ev) {
            var pesan = form.getAttribute('data-confirm') || 'Lanjutkan tindakan ini?';

            if (!window.confirm(pesan)) {
                ev.preventDefault();
            }
        });
    });

    /* -----------------------------------------------------------------
     * Filter otomatis
     * --------------------------------------------------------------- */
    document.querySelectorAll('[data-auto-submit]').forEach(function (el) {
        el.addEventListener('change', function () {
            var form = el.closest('form');

            if (form) {
                form.submit();
            }
        });
    });

    /* -----------------------------------------------------------------
     * Cegah klik ganda pada form simpan
     * --------------------------------------------------------------- */
    document.querySelectorAll('form[data-once]').forEach(function (form) {
        form.addEventListener('submit', function () {
            var tombol = form.querySelector('button[type="submit"]');

            if (!tombol) {
                return;
            }

            // Ditunda agar tombol tidak membatalkan pengiriman form.
            window.setTimeout(function () {
                tombol.disabled = true;
            }, 0);
        });
    });
    /* -----------------------------------------------------------------
     * Pagination tabel
     * --------------------------------------------------------------- */
    var perHalaman = 10;
    var jendelaHalaman = 10;

    document.querySelectorAll('.table-wrapper:not(.rekap-wrapper) > table').forEach(function (tabel) {
        var tbody = tabel.tBodies[0];
        var wrapper = tabel.closest('.table-wrapper');

        if (!tbody || !wrapper) {
            return;
        }

        var baris = Array.prototype.filter.call(tbody.rows, function (tr) {
            return !tr.classList.contains('total-row');
        });

        if (baris.length <= perHalaman) {
            return;
        }

        var jumlahHalaman = Math.ceil(baris.length / perHalaman);
        var halamanAktif = 1;
        var nav = document.createElement('nav');
        var info = document.createElement('span');
        var kontrol = document.createElement('div');
        var judulKolom = tabel.tHead && tabel.tHead.rows[0] && tabel.tHead.rows[0].cells[0]
            ? tabel.tHead.rows[0].cells[0].textContent.trim().toLowerCase()
            : '';
        var nomoriBaris = ['no', 'no.', '#'].indexOf(judulKolom) !== -1;

        nav.className = 'pagination';
        nav.setAttribute('aria-label', 'Navigasi halaman tabel');
        info.className = 'pagination-info';
        info.setAttribute('aria-live', 'polite');
        kontrol.className = 'pagination-pages';
        nav.appendChild(info);
        nav.appendChild(kontrol);
        wrapper.insertAdjacentElement('afterend', nav);

        function buatTombol(teks, tujuan, kelas, label, nonaktif) {
            var tombol = document.createElement('button');

            tombol.type = 'button';
            tombol.className = kelas;
            tombol.textContent = teks;
            tombol.setAttribute('aria-label', label || teks);

            if (nonaktif) {
                tombol.disabled = true;
                return tombol;
            }

            tombol.addEventListener('click', function () {
                halamanAktif = tujuan;
                render(true);
            });

            return tombol;
        }

        function render(gulir) {
            var mulai = (halamanAktif - 1) * perHalaman;
            var selesai = Math.min(mulai + perHalaman, baris.length);

            baris.forEach(function (tr, indeks) {
                var tampil = indeks >= mulai && indeks < selesai;

                tr.hidden = !tampil;

                if (tampil && nomoriBaris && tr.cells.length > 0) {
                    tr.cells[0].textContent = String(indeks + 1);
                }
            });

            info.textContent = 'Menampilkan ' + (mulai + 1) + '–' + selesai
                + ' dari ' + baris.length + ' data';
            kontrol.textContent = '';

            kontrol.appendChild(buatTombol(
                '‹ Sebelumnya',
                halamanAktif - 1,
                'pagination-btn pagination-nav-btn',
                'Halaman sebelumnya',
                halamanAktif === 1
            ));

            var awal = Math.floor((halamanAktif - 1) / jendelaHalaman) * jendelaHalaman + 1;
            var akhir = Math.min(jumlahHalaman, awal + jendelaHalaman - 1);

            for (var halaman = awal; halaman <= akhir; halaman++) {
                (function (nomor) {
                    var tombol = buatTombol(
                        String(nomor),
                        nomor,
                        'pagination-btn pagination-page',
                        'Halaman ' + nomor,
                        false
                    );

                    if (nomor === halamanAktif) {
                        tombol.setAttribute('aria-current', 'page');
                    }

                    kontrol.appendChild(tombol);
                })(halaman);
            }

            kontrol.appendChild(buatTombol(
                'Berikutnya ›',
                halamanAktif + 1,
                'pagination-btn pagination-nav-btn',
                'Halaman berikutnya',
                halamanAktif === jumlahHalaman
            ));

            if (gulir) {
                var atas = wrapper.getBoundingClientRect().top + window.pageYOffset - 78;

                window.scrollTo({
                    top: Math.max(0, atas),
                    behavior: 'smooth'
                });
            }
        }

        render(false);
    });
})();
