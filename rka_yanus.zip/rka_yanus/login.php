<?php
declare(strict_types=1);

require __DIR__ . '/config/database.php';
require __DIR__ . '/includes/functions.php';

if (isLoggedIn()) {
    redirect(url('index.php'));
}

$error = '';
$usernameInput = '';
$batasPercobaan = 5;
$jendelaDetik = 900;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf($_POST['csrf_token'] ?? null);

    $usernameInput = trim((string) ($_POST['username'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    $sekarang = time();
    $percobaan = array_values(array_filter(
        $_SESSION['login_attempts'] ?? [],
        static fn (int $waktu): bool => $waktu > $sekarang - $jendelaDetik
    ));

    if (count($percobaan) >= $batasPercobaan) {
        $sisaMenit = (int) ceil(($percobaan[0] + $jendelaDetik - $sekarang) / 60);
        $error = 'Terlalu banyak percobaan masuk. Coba lagi dalam '
            . max(1, $sisaMenit) . ' menit.';
    } elseif ($usernameInput === '' || $password === '') {
        $error = 'Nama pengguna dan kata sandi wajib diisi.';
    } else {
        $stmt = $pdo->prepare(
            'SELECT id, nama, username, password_hash, peran, status
            FROM pengguna
            WHERE username = :username'
        );
        $stmt->execute([':username' => $usernameInput]);
        $pengguna = $stmt->fetch();

        if (
            $pengguna &&
            $pengguna['status'] === 'AKTIF' &&
            password_verify($password, $pengguna['password_hash'])
        ) {
            if (password_needs_rehash($pengguna['password_hash'], PASSWORD_DEFAULT)) {
                $stmt = $pdo->prepare(
                    'UPDATE pengguna SET password_hash = :hash WHERE id = :id'
                );
                $stmt->execute([
                    ':hash' => password_hash($password, PASSWORD_DEFAULT),
                    ':id'   => $pengguna['id'],
                ]);
            }

            unset($_SESSION['login_attempts']);
            loginUser($pengguna);

            $tujuan = $_SESSION['redirect_after_login'] ?? null;
            unset($_SESSION['redirect_after_login']);

            if (
                is_string($tujuan) &&
                str_starts_with($tujuan, basePath() . '/') &&
                !str_contains($tujuan, '//')
            ) {
                redirect($tujuan);
            }

            redirect(url('index.php'));
        }

        if ($pengguna && $pengguna['status'] !== 'AKTIF') {
            $error = 'Akun Anda sedang tidak aktif. Hubungi Administrator.';
        } else {
            $error = 'Nama pengguna atau kata sandi tidak sesuai.';
        }

        $percobaan[] = $sekarang;
        $_SESSION['login_attempts'] = $percobaan;
    }
}

// Petunjuk akun awal hanya muncul selama password bawaan belum diubah.
$petunjukAkun = false;

$stmt = $pdo->query('SELECT COUNT(*) FROM pengguna');
$jumlahPengguna = (int) $stmt->fetchColumn();

if ($jumlahPengguna > 0) {
    $stmt = $pdo->query("SELECT password_hash FROM pengguna WHERE username = 'admin' LIMIT 1");
    $hashAdmin = $stmt->fetchColumn();
    $petunjukAkun = is_string($hashAdmin) && password_verify('admin123', $hashAdmin);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Masuk | RKA YANUS</title>
    <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body class="auth-page">
    <main class="auth-card">
        <div class="auth-brand">
            <span class="brand-mark">RKA</span>
            <span>
                <strong>RKA YANUS</strong>
                <small>Rencana Kerja dan Anggaran</small>
            </span>
        </div>

        <h1>Masuk Aplikasi</h1>
        <p class="lead">Gunakan akun pengguna yang terdaftar untuk melanjutkan.</p>

        <?php if ($petunjukAkun): ?>
            <div class="alert alert-info">
                Akun awal: <strong>admin</strong> / <strong>admin123</strong>.
                Segera ubah kata sandi melalui menu Profil setelah masuk.
            </div>
        <?php endif; ?>

        <?php if ($error !== ''): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>

        <?php foreach (getFlashes() as $flash): ?>
            <?php
            $kelasFlash = match ($flash['type']) {
                'success' => '',
                'danger'  => ' alert-danger',
                'warning' => ' alert-warning',
                default   => ' alert-info',
            };
            ?>
            <div class="alert<?= $kelasFlash ?>"><?= e($flash['message']) ?></div>
        <?php endforeach; ?>

        <form method="post" action="<?= e(url('login.php')) ?>">
            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">

            <div class="form-group">
                <label for="username">Nama Pengguna</label>
                <input
                    type="text"
                    id="username"
                    name="username"
                    value="<?= e($usernameInput) ?>"
                    maxlength="80"
                    autocomplete="username"
                    autofocus
                    required
                >
            </div>

            <div class="form-group">
                <label for="password">Kata Sandi</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    autocomplete="current-password"
                    required
                >
            </div>

            <button type="submit" class="btn btn-block">Masuk</button>
        </form>

        <p class="auth-footnote">
            Lupa kata sandi? Hubungi Administrator untuk melakukan reset.
        </p>
    </main>
</body>
</html>
