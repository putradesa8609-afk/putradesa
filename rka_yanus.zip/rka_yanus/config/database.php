<?php
declare(strict_types=1);

$host = 'localhost';
$dbname = 'db_rka_yanus';
$username = 'root';
$password = '';

// Kredensial server produksi tanpa mengubah file ini:
// salin database.local.php.sample menjadi database.local.php lalu isi.
$localConfig = __DIR__ . '/database.local.php';
if (is_file($localConfig)) {
    $local = require $localConfig;
    $host = $local['host'] ?? $host;
    $dbname = $local['dbname'] ?? $dbname;
    $username = $local['username'] ?? $username;
    $password = $local['password'] ?? $password;
}

$dsn = "mysql:host={$host};dbname={$dbname};charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    error_log($e->getMessage());
    http_response_code(500);
    exit('Koneksi Database gagal. Periksa Konfigurasi Database RKA_Yanus');
}