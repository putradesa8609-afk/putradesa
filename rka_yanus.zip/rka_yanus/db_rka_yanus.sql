-- =====================================================================
-- Aplikasi RKA YANUS
-- Skema database lengkap + data awal
--
-- Cara pakai:
--   phpMyAdmin  : tab Import, pilih file ini, klik Go.
--   Terminal    : mysql -u root -p < db_rka_yanus.sql
--
-- Akun awal:
--   username : admin
--   password : admin123
--   Segera ubah kata sandi melalui menu Profil setelah masuk.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS db_rka_yanus
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE db_rka_yanus;

-- =====================================================================
-- 1. Pengguna aplikasi
-- =====================================================================
CREATE TABLE IF NOT EXISTS pengguna (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    nama VARCHAR(150) NOT NULL,
    username VARCHAR(80) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    peran ENUM('ADMIN','OPERATOR','VERIFIKATOR','PIMPINAN') NOT NULL DEFAULT 'OPERATOR',
    status ENUM('AKTIF','NONAKTIF') NOT NULL DEFAULT 'AKTIF',
    dibuat_pada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    diperbarui_pada TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_pengguna_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- 2. Kegiatan
-- =====================================================================
CREATE TABLE IF NOT EXISTS kegiatan (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    kode_kegiatan VARCHAR(50) NOT NULL,
    nama_kegiatan VARCHAR(255) NOT NULL,
    tahun_anggaran YEAR NOT NULL DEFAULT 2026,
    keterangan TEXT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_kegiatan_kode_tahun (kode_kegiatan, tahun_anggaran)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- 3. Sub kegiatan
-- =====================================================================
CREATE TABLE IF NOT EXISTS sub_kegiatan (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    kegiatan_id BIGINT UNSIGNED NOT NULL,
    kode_sub_kegiatan VARCHAR(60) NOT NULL,
    nama_sub_kegiatan VARCHAR(255) NOT NULL,
    keterangan TEXT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sub_kegiatan_kode (kegiatan_id, kode_sub_kegiatan),
    CONSTRAINT fk_sub_kegiatan_kegiatan
      FOREIGN KEY (kegiatan_id) REFERENCES kegiatan(id)
      ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- 4. Master rekening dan satuan
-- =====================================================================
CREATE TABLE IF NOT EXISTS master_rekening (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    kode_rekening VARCHAR(80) NOT NULL,
    nama_rekening VARCHAR(255) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_master_rekening_kode (kode_rekening)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS master_satuan (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    kode_satuan VARCHAR(30) NOT NULL,
    nama_satuan VARCHAR(80) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_master_satuan_kode (kode_satuan)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- 5. Master penyedia
-- =====================================================================
CREATE TABLE IF NOT EXISTS master_penyedia (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    nama_penyedia VARCHAR(200) NOT NULL,
    npwp VARCHAR(30) NULL,
    alamat TEXT NULL,
    nama_pimpinan VARCHAR(150) NULL,
    aktif TINYINT(1) NOT NULL DEFAULT 1,
    dibuat_pada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    diperbarui_pada TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_penyedia_nama (nama_penyedia),
    KEY idx_penyedia_npwp (npwp),
    CONSTRAINT chk_penyedia_aktif CHECK (aktif IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- 6. Rincian anggaran (kode RUP)
--    total_dasar, nilai_ppn, dan total_pagu dihitung otomatis.
-- =====================================================================
CREATE TABLE IF NOT EXISTS rincian_anggaran (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    sub_kegiatan_id BIGINT UNSIGNED NOT NULL,
    rekening_id BIGINT UNSIGNED NOT NULL,
    satuan_id BIGINT UNSIGNED NOT NULL,
    kode_rup VARCHAR(60) NOT NULL,
    uraian VARCHAR(500) NOT NULL,
    kategori_belanja ENUM('BARANG','JASA','MODAL','PERJALANAN_DINAS','PEMELIHARAAN')
        NULL DEFAULT NULL,
    volume DECIMAL(18,4) NOT NULL,
    harga_satuan DECIMAL(18,2) NOT NULL,
    kena_ppn TINYINT(1) NOT NULL DEFAULT 1,
    tarif_ppn DECIMAL(5,2) NOT NULL DEFAULT 11.00,
    total_dasar DECIMAL(18,2) GENERATED ALWAYS AS (
        ROUND(volume * harga_satuan, 2)
    ) STORED,
    nilai_ppn DECIMAL(18,2) GENERATED ALWAYS AS (
        CASE WHEN kena_ppn = 1
            THEN ROUND(volume * harga_satuan * tarif_ppn / 100, 2)
            ELSE 0.00
        END
    ) STORED,
    total_pagu DECIMAL(18,2) GENERATED ALWAYS AS (
        ROUND(
            volume * harga_satuan
            + CASE WHEN kena_ppn = 1
                THEN ROUND(volume * harga_satuan * tarif_ppn / 100, 2)
                ELSE 0.00
              END,
            2
        )
    ) STORED,
    status ENUM('DRAFT','AKTIF','DIBATALKAN') NOT NULL DEFAULT 'DRAFT',
    catatan TEXT NULL,
    dibuat_pada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    diperbarui_pada TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_rincian_kode_rup (kode_rup),
    KEY idx_rincian_kategori (kategori_belanja),
    KEY idx_rincian_rekening (rekening_id),
    KEY fk_rincian_sub_kegiatan (sub_kegiatan_id),
    KEY fk_rincian_satuan (satuan_id),
    CONSTRAINT fk_rincian_sub_kegiatan
      FOREIGN KEY (sub_kegiatan_id) REFERENCES sub_kegiatan(id)
      ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_rincian_rekening
      FOREIGN KEY (rekening_id) REFERENCES master_rekening(id)
      ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_rincian_satuan
      FOREIGN KEY (satuan_id) REFERENCES master_satuan(id)
      ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_rincian_volume CHECK (volume > 0),
    CONSTRAINT chk_rincian_harga CHECK (harga_satuan >= 0),
    CONSTRAINT chk_rincian_kena_ppn CHECK (kena_ppn IN (0,1)),
    CONSTRAINT chk_rincian_tarif_ppn CHECK (tarif_ppn >= 0 AND tarif_ppn <= 100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- 7. Realisasi anggaran
-- =====================================================================
CREATE TABLE IF NOT EXISTS realisasi_anggaran (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    rincian_anggaran_id BIGINT UNSIGNED NOT NULL,
    metode ENUM('PENYEDIA','SWAKELOLA') NOT NULL,
    penyedia_id BIGINT UNSIGNED NULL,
    tipe_swakelola ENUM('I','II','III','IV') NULL,
    pelaksana_swakelola VARCHAR(200) NULL,
    nomor_sk_tim VARCHAR(100) NULL,
    tanggal_sk_tim DATE NULL,
    nomor_kontrak VARCHAR(100) NULL,
    tanggal_kontrak DATE NULL,
    nomor_surat_pesanan VARCHAR(100) NULL,
    tanggal_surat_pesanan DATE NULL,
    nomor_spk VARCHAR(100) NULL,
    tanggal_spk DATE NULL,
    nilai_realisasi DECIMAL(18,2) NOT NULL,
    tanggal_mulai DATE NULL,
    tanggal_selesai DATE NULL,
    lama_hari INT GENERATED ALWAYS AS (
        CASE WHEN tanggal_mulai IS NOT NULL AND tanggal_selesai IS NOT NULL
            THEN TO_DAYS(tanggal_selesai) - TO_DAYS(tanggal_mulai) + 1
            ELSE NULL
        END
    ) STORED,
    nomor_bast VARCHAR(100) NULL,
    tanggal_bast DATE NULL,
    status ENUM('DRAFT','BERJALAN','SELESAI','DIBATALKAN') NOT NULL DEFAULT 'BERJALAN',
    catatan TEXT NULL,
    dibuat_pada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    diperbarui_pada TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_real_rincian (rincian_anggaran_id),
    KEY idx_real_penyedia (penyedia_id),
    KEY idx_real_metode (metode),
    KEY idx_real_status (status),
    KEY idx_real_nomor_kontrak (nomor_kontrak),
    KEY idx_real_nomor_sp (nomor_surat_pesanan),
    CONSTRAINT fk_real_rincian
      FOREIGN KEY (rincian_anggaran_id) REFERENCES rincian_anggaran(id)
      ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_real_penyedia
      FOREIGN KEY (penyedia_id) REFERENCES master_penyedia(id)
      ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_real_nilai CHECK (nilai_realisasi > 0),
    CONSTRAINT chk_real_periode CHECK (
        tanggal_selesai IS NULL
        OR tanggal_mulai IS NULL
        OR tanggal_selesai >= tanggal_mulai
    ),
    CONSTRAINT chk_real_metode CHECK (
        (metode = 'PENYEDIA' AND penyedia_id IS NOT NULL AND tipe_swakelola IS NULL)
        OR
        (metode = 'SWAKELOLA' AND penyedia_id IS NULL AND tipe_swakelola IS NOT NULL)
    ),
    CONSTRAINT chk_real_bast CHECK (nomor_bast IS NULL = (tanggal_bast IS NULL))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- 8. Pembayaran realisasi
-- =====================================================================
CREATE TABLE IF NOT EXISTS realisasi_pembayaran (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    realisasi_id BIGINT UNSIGNED NOT NULL,
    jenis ENUM('UANG_MUKA','TERMIN','PELUNASAN') NOT NULL DEFAULT 'TERMIN',
    nomor_spm VARCHAR(100) NULL,
    nomor_sp2d VARCHAR(100) NULL,
    tanggal_bayar DATE NOT NULL,
    jumlah_dibayar DECIMAL(18,2) NOT NULL,
    persentase_fisik DECIMAL(5,2) NULL,
    catatan TEXT NULL,
    dibuat_pada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_bayar_realisasi (realisasi_id),
    KEY idx_bayar_sp2d (nomor_sp2d),
    CONSTRAINT fk_bayar_realisasi
      FOREIGN KEY (realisasi_id) REFERENCES realisasi_anggaran(id)
      ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_bayar_jumlah CHECK (jumlah_dibayar > 0),
    CONSTRAINT chk_bayar_fisik CHECK (
        persentase_fisik IS NULL
        OR (persentase_fisik >= 0 AND persentase_fisik <= 100)
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- 9. Perjalanan dinas
--    Satu surat tugas dapat memiliki banyak peserta. Biaya dicatat
--    per peserta, total_biaya dihitung otomatis.
-- =====================================================================
CREATE TABLE IF NOT EXISTS perjalanan_dinas (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    sub_kegiatan_id BIGINT UNSIGNED NOT NULL,
    rekening_id BIGINT UNSIGNED NOT NULL,
    nomor_st VARCHAR(100) NOT NULL,
    tanggal_st DATE NOT NULL,
    maksud VARCHAR(500) NOT NULL,
    tujuan VARCHAR(255) NOT NULL,
    lama_hari INT NOT NULL DEFAULT 1,
    tanggal_berangkat DATE NOT NULL,
    tanggal_kembali DATE NOT NULL,
    catatan TEXT NULL,
    dibuat_oleh BIGINT UNSIGNED NULL,
    dibuat_pada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    diperbarui_pada TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_pd_nomor_st (nomor_st),
    KEY idx_pd_tanggal (tanggal_berangkat),
    KEY idx_pd_sub_kegiatan (sub_kegiatan_id),
    KEY idx_pd_rekening (rekening_id),
    KEY idx_pd_dibuat_oleh (dibuat_oleh),
    CONSTRAINT fk_pd_sub_kegiatan
      FOREIGN KEY (sub_kegiatan_id) REFERENCES sub_kegiatan(id)
      ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_pd_rekening
      FOREIGN KEY (rekening_id) REFERENCES master_rekening(id)
      ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_pd_pengguna
      FOREIGN KEY (dibuat_oleh) REFERENCES pengguna(id)
      ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT chk_pd_lama_hari CHECK (lama_hari >= 1 AND lama_hari <= 365),
    CONSTRAINT chk_pd_tanggal CHECK (tanggal_kembali >= tanggal_berangkat)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS perjalanan_dinas_peserta (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    perjalanan_id BIGINT UNSIGNED NOT NULL,
    nama VARCHAR(150) NOT NULL,
    nip VARCHAR(30) NULL,
    pangkat VARCHAR(100) NULL,
    golongan_ruang VARCHAR(20) NULL,
    jabatan VARCHAR(150) NULL,
    nama_hotel VARCHAR(200) NULL,
    tanggal_check_in DATE NULL,
    tanggal_check_out DATE NULL,
    uang_harian DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    penginapan DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    representasi DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    transport_lokal DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    taksi_sewa DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    bbm DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    biaya_lain DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    total_biaya DECIMAL(18,2) GENERATED ALWAYS AS (
        ROUND(
            uang_harian + penginapan + representasi + transport_lokal
            + taksi_sewa + bbm + biaya_lain,
            2
        )
    ) STORED,
    dibuat_pada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_pdp_perjalanan (perjalanan_id),
    CONSTRAINT fk_pdp_perjalanan
      FOREIGN KEY (perjalanan_id) REFERENCES perjalanan_dinas(id)
      ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_pdp_uang_harian CHECK (uang_harian >= 0),
    CONSTRAINT chk_pdp_penginapan CHECK (penginapan >= 0),
    CONSTRAINT chk_pdp_representasi CHECK (representasi >= 0),
    CONSTRAINT chk_pdp_transport CHECK (transport_lokal >= 0),
    CONSTRAINT chk_pdp_taksi CHECK (taksi_sewa >= 0),
    CONSTRAINT chk_pdp_bbm CHECK (bbm >= 0),
    CONSTRAINT chk_pdp_biaya_lain CHECK (biaya_lain >= 0),
    CONSTRAINT chk_pdp_menginap CHECK (
        tanggal_check_out IS NULL
        OR tanggal_check_in IS NULL
        OR tanggal_check_out >= tanggal_check_in
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- 10. View ringkasan
-- =====================================================================
CREATE OR REPLACE VIEW v_realisasi_ringkasan AS
SELECT
    r.id AS realisasi_id,
    r.rincian_anggaran_id,
    r.nilai_realisasi,
    COALESCE(SUM(p.jumlah_dibayar), 0) AS total_dibayar,
    r.nilai_realisasi - COALESCE(SUM(p.jumlah_dibayar), 0) AS sisa_belum_dibayar,
    ROUND(
        COALESCE(SUM(p.jumlah_dibayar), 0) / NULLIF(r.nilai_realisasi, 0) * 100,
        2
    ) AS persen_dibayar,
    MAX(p.persentase_fisik) AS persen_fisik
FROM realisasi_anggaran AS r
LEFT JOIN realisasi_pembayaran AS p ON p.realisasi_id = r.id
GROUP BY r.id, r.rincian_anggaran_id, r.nilai_realisasi;

CREATE OR REPLACE VIEW v_rincian_ringkasan AS
SELECT
    ra.id AS rincian_id,
    ra.kode_rup,
    ra.total_pagu,
    COALESCE(SUM(
        CASE WHEN r.status <> 'DIBATALKAN' THEN r.nilai_realisasi END
    ), 0) AS total_realisasi,
    ra.total_pagu - COALESCE(SUM(
        CASE WHEN r.status <> 'DIBATALKAN' THEN r.nilai_realisasi END
    ), 0) AS sisa_pagu,
    ROUND(
        COALESCE(SUM(
            CASE WHEN r.status <> 'DIBATALKAN' THEN r.nilai_realisasi END
        ), 0) / NULLIF(ra.total_pagu, 0) * 100,
        2
    ) AS persen_realisasi
FROM rincian_anggaran AS ra
LEFT JOIN realisasi_anggaran AS r ON r.rincian_anggaran_id = ra.id
GROUP BY ra.id, ra.kode_rup, ra.total_pagu;

CREATE OR REPLACE VIEW v_perjalanan_ringkasan AS
SELECT
    pd.id AS perjalanan_id,
    COUNT(p.id) AS jumlah_peserta,
    COALESCE(SUM(p.total_biaya), 0) AS total_biaya
FROM perjalanan_dinas AS pd
LEFT JOIN perjalanan_dinas_peserta AS p ON p.perjalanan_id = pd.id
GROUP BY pd.id;

-- =====================================================================
-- 11. Data awal
-- =====================================================================

-- Satuan standar
INSERT IGNORE INTO master_satuan (kode_satuan, nama_satuan) VALUES
('UNIT','Unit'),
('RIM','Rim'),
('PCS','Pcs'),
('PAK','Pak'),
('KG','Kilogram'),
('M','Meter'),
('M2','Meter persegi'),
('M3','Meter kubik'),
('LS','Lumpsum'),
('HARI','Hari'),
('OH','Orang/Hari'),
('OP','Orang/Paket'),
('LEMBAR','Lembar'),
('BUAH','Buah'),
('DUS','Dus'),
('PORSI','Porsi');

-- Akun administrator awal (username: admin, password: admin123)
-- Ubah kata sandi segera setelah login pertama.
INSERT IGNORE INTO pengguna (nama, username, password_hash, peran, status)
VALUES (
    'Administrator',
    'admin',
    '$2y$10$UZ7xQsUfzCbYqIP4h.hufeNRsHA35746HlDPTOCadcVA/itAOGPOe',
    'ADMIN',
    'AKTIF'
);
