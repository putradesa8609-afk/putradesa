<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

requireLogin();

$pageTitle = 'Pembayaran Realisasi';
$currentPage = 'pembayaran';

$errors = [];
$edit = null;

function tanggalValid(string $nilai): string|false
{
    $d = DateTime::createFromFormat('!Y-m-d', $nilai);

    return ($d !== false && $d->format('Y-m-d') === $nilai) ? $nilai : false;
}

// ID dari ?edit= atau dari POST (agar nilai form tidak hilang saat validasi gagal)
$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);

if (!is_int($editId) || $editId < 1) {
    $idPost = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    $editId = (is_int($idPost) && $idPost > 0) ? $idPost : null;
}

if ($editId !== null) {
    $stmt = $pdo->prepare(
        'SELECT
            b.*,
            r.nilai_realisasi,
            ra.kode_rup,
            ra.uraian
        FROM realisasi_pembayaran AS b
        INNER JOIN realisasi_anggaran AS r ON r.id = b.realisasi_id
        INNER JOIN rincian_anggaran AS ra ON ra.id = r.rincian_anggaran_id
        WHERE b.id = :id'
    );
    $stmt->execute([':id' => $editId]);
    $edit = $stmt->fetch() ?: null;

    if ($edit === null) {
        setFlash('warning', 'Data pembayaran yang ingin dibuka tidak ditemukan.');
        redirect(url('pages/pembayaran.php'));
    }
}

$old = static function (string $key) use ($edit): string {
    if (array_key_exists($key, $_POST)) {
        $v = $_POST[$key];

        return e(is_string($v) ? $v : '');
    }

    return e($edit[$key] ?? '');
};

$selected = static function (string $key, string $value): string {
    $v = $_POST[$key] ?? null;

    if (!is_scalar($v)) {
        return '';
    }

    return (string) $v === $value ? 'selected' : '';
};

$labelJenis = [
    'UANG_MUKA' => 'Uang Muka',
    'TERMIN'    => 'Termin',
    'PELUNASAN' => 'Pelunasan',
];

// =====================================================================
// PROSES POST
// =====================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf($_POST['csrf_token'] ?? null);
    requireManage();

    $aksi = (string) ($_POST['aksi'] ?? 'simpan');

    // -----------------------------------------------------------------
    // A. Hapus pembayaran (hanya pembayaran terakhir per realisasi)
    // -----------------------------------------------------------------
    if ($aksi === 'hapus') {
        $targetId = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);

        if (!is_int($targetId) || $targetId < 1) {
            setFlash('danger', 'Data pembayaran tidak valid.');
            redirect(url('pages/pembayaran.php'));
        }

        $stmt = $pdo->prepare(
            'SELECT realisasi_id, tanggal_bayar
            FROM realisasi_pembayaran
            WHERE id = :id'
        );
        $stmt->execute([':id' => $targetId]);
        $target = $stmt->fetch();

        if (!$target) {
            setFlash('warning', 'Pembayaran tidak ditemukan.');
            redirect(url('pages/pembayaran.php'));
        }

        $stmt = $pdo->prepare(
            'SELECT COUNT(*)
            FROM realisasi_pembayaran
            WHERE realisasi_id = :rid
            AND (
                tanggal_bayar > :tgl1
                OR (tanggal_bayar = :tgl2 AND id > :id2)
            )'
        );
        $stmt->execute([
            ':rid'  => $target['realisasi_id'],
            ':tgl1' => $target['tanggal_bayar'],
            ':tgl2' => $target['tanggal_bayar'],
            ':id2'  => $targetId,
        ]);

        if ((int) $stmt->fetchColumn() > 0) {
            setFlash(
                'danger',
                'Hanya pembayaran terakhir pada satu realisasi yang boleh dihapus, '
                . 'agar urutan kumulatif tetap benar.'
            );
            redirect(url('pages/pembayaran.php'));
        }

        $stmt = $pdo->prepare('DELETE FROM realisasi_pembayaran WHERE id = :id');
        $stmt->execute([':id' => $targetId]);

        setFlash('success', 'Pembayaran berhasil dihapus.');
        redirect(url('pages/pembayaran.php'));
    }

    // -----------------------------------------------------------------
    // B. Ubah data administratif pembayaran
    // -----------------------------------------------------------------
    if ($aksi === 'ubah') {
        if ($edit === null) {
            setFlash('danger', 'Data pembayaran tidak valid.');
            redirect(url('pages/pembayaran.php'));
        }

        $nomorSpm = trim((string) ($_POST['nomor_spm'] ?? ''));
        $nomorSp2d = trim((string) ($_POST['nomor_sp2d'] ?? ''));
        $catatan = trim((string) ($_POST['catatan'] ?? ''));

        if (mb_strlen($nomorSpm) > 100 || mb_strlen($nomorSp2d) > 100) {
            $errors[] = 'Nomor SPM atau SP2D maksimal 100 karakter.';
        }

        if ($nomorSp2d !== '' && empty($errors)) {
            $stmt = $pdo->prepare(
                'SELECT COUNT(*)
                FROM realisasi_pembayaran
                WHERE nomor_sp2d = :nomor AND id <> :id'
            );
            $stmt->execute([':nomor' => $nomorSp2d, ':id' => (int) $edit['id']]);

            if ((int) $stmt->fetchColumn() > 0) {
                $errors[] = 'Nomor SP2D sudah digunakan pada pembayaran lain.';
            }
        }

        if (empty($errors)) {
            $stmt = $pdo->prepare(
                'UPDATE realisasi_pembayaran SET
                    nomor_spm = :nomor_spm,
                    nomor_sp2d = :nomor_sp2d,
                    catatan = :catatan
                WHERE id = :id'
            );
            $stmt->execute([
                ':nomor_spm' => $nomorSpm !== '' ? $nomorSpm : null,
                ':nomor_sp2d' => $nomorSp2d !== '' ? $nomorSp2d : null,
                ':catatan' => $catatan !== '' ? $catatan : null,
                ':id' => (int) $edit['id'],
            ]);

            setFlash('success', 'Data pembayaran berhasil diperbarui.');
            redirect(url('pages/pembayaran.php'));
        }
    }

    // -----------------------------------------------------------------
    // C. Simpan pembayaran baru
    // -----------------------------------------------------------------
    if ($aksi === 'simpan') {
        $realisasiId = filter_var($_POST['realisasi_id'] ?? null, FILTER_VALIDATE_INT);
        $jenis = (string) ($_POST['jenis'] ?? '');
        $nomorSpm = trim((string) ($_POST['nomor_spm'] ?? ''));
        $nomorSp2d = trim((string) ($_POST['nomor_sp2d'] ?? ''));
        $tanggalInput = trim((string) ($_POST['tanggal_bayar'] ?? ''));
        $jumlahInput = trim((string) ($_POST['jumlah_dibayar'] ?? ''));
        $fisikInput = trim((string) ($_POST['persentase_fisik'] ?? ''));
        $catatan = trim((string) ($_POST['catatan'] ?? ''));

        $tanggalBayar = $tanggalInput === '' ? null : tanggalValid($tanggalInput);
        $jumlahValid = $jumlahInput !== '' && is_numeric($jumlahInput);
        $jumlah = $jumlahValid ? (float) $jumlahInput : 0.0;
        $fisikValid = $fisikInput === '' || is_numeric($fisikInput);
        $fisik = ($fisikInput !== '' && $fisikValid) ? (float) $fisikInput : null;

        if (!is_int($realisasiId) || $realisasiId < 1) {
            $errors[] = 'Realisasi wajib dipilih.';
        }

        if (!isset($labelJenis[$jenis])) {
            $errors[] = 'Jenis pembayaran tidak valid.';
        }

        if ($tanggalBayar === null || $tanggalBayar === false) {
            $errors[] = 'Tanggal bayar wajib diisi dengan format yang benar.';
        } elseif ($tanggalBayar > date('Y-m-d')) {
            $errors[] = 'Tanggal bayar tidak boleh lebih dari hari ini.';
        }

        if (!$jumlahValid || $jumlah <= 0 || $jumlah > 9_999_999_999_999_999.99) {
            $errors[] = 'Jumlah dibayar harus berupa angka lebih besar dari nol.';
        }

        if (!$fisikValid || ($fisik !== null && ($fisik < 0 || $fisik > 100))) {
            $errors[] = 'Persentase fisik harus berada antara 0 dan 100.';
        }

        if (empty($errors)) {
            try {
                $pdo->beginTransaction();

                // Kunci baris realisasi agar pengecekan sisa aman
                $stmt = $pdo->prepare(
                    'SELECT id, nilai_realisasi, status,
                    tanggal_mulai, tanggal_kontrak, tanggal_surat_pesanan,
                    tanggal_spk, tanggal_sk_tim, nomor_bast, tanggal_bast
                    FROM realisasi_anggaran
                    WHERE id = :id
                    FOR UPDATE'
                );
                $stmt->execute([':id' => $realisasiId]);
                $realisasi = $stmt->fetch();

                if (!$realisasi || $realisasi['status'] === 'DIBATALKAN') {
                    throw new RuntimeException(
                        'Realisasi tidak ditemukan atau sudah dibatalkan.'
                    );
                }

                $stmt = $pdo->prepare(
                    "SELECT
                    COALESCE(SUM(jumlah_dibayar), 0) AS total,
                    COALESCE(SUM(jenis = 'UANG_MUKA'), 0) AS jml_uang_muka,
                    COALESCE(SUM(jenis = 'PELUNASAN'), 0) AS jml_pelunasan,
                    MAX(persentase_fisik) AS fisik_tertinggi
                    FROM realisasi_pembayaran
                    WHERE realisasi_id = :id"
                );
                $stmt->execute([':id' => $realisasiId]);
                $rekap = $stmt->fetch();

                $sisa = (float) $realisasi['nilai_realisasi'] - (float) $rekap['total'];

                if ((int) $rekap['jml_pelunasan'] > 0) {
                    throw new RuntimeException(
                        'Realisasi ini sudah dilunasi, pembayaran baru tidak dapat ditambahkan.'
                    );
                }

                if ($jenis === 'UANG_MUKA' && (int) $rekap['jml_uang_muka'] > 0) {
                    throw new RuntimeException(
                        'Uang muka sudah pernah dicatat untuk realisasi ini.'
                    );
                }

                if ($jumlah > $sisa + 0.005) {
                    throw new RuntimeException(
                        'Jumlah dibayar melebihi sisa yang belum dibayar ('
                        . rupiah($sisa) . ').'
                    );
                }

                if ($jenis === 'PELUNASAN' && abs($jumlah - $sisa) > 0.005) {
                    throw new RuntimeException(
                        'Pelunasan harus sama dengan sisa yang belum dibayar ('
                        . rupiah($sisa) . ').'
                    );
                }

                // Realisasi Draft belum boleh dibayar
                if ($realisasi['status'] === 'DRAFT') {
                    throw new RuntimeException(
                        'Realisasi masih berstatus Draft, ubah ke Berjalan sebelum mencatat pembayaran.'
                    );
                }

                // Pembayaran yang menghabiskan seluruh sisa harus berjenis Pelunasan
                if ($jenis !== 'PELUNASAN' && round($sisa - $jumlah, 2) <= 0.005) {
                    throw new RuntimeException(
                        'Pembayaran yang menghabiskan seluruh sisa harus berjenis Pelunasan.'
                    );
                }

                // Tanggal bayar tidak boleh sebelum dokumen paling awal
                $tglDokumen = array_filter([
                    $realisasi['tanggal_kontrak'],
                    $realisasi['tanggal_surat_pesanan'],
                    $realisasi['tanggal_spk'],
                    $realisasi['tanggal_sk_tim'],
                ]);

                if (!empty($tglDokumen) && $tanggalBayar < min($tglDokumen)) {
                    throw new RuntimeException(
                        'Tanggal bayar tidak boleh sebelum tanggal dokumen ('
                        . tanggalIndo(min($tglDokumen)) . ').'
                    );
                }

                // Termin dan pelunasan tidak boleh sebelum pekerjaan dimulai
                if ($jenis !== 'UANG_MUKA' && $tanggalBayar < $realisasi['tanggal_mulai']) {
                    throw new RuntimeException(
                        'Termin dan pelunasan tidak boleh sebelum tanggal mulai pekerjaan ('
                        . tanggalIndo($realisasi['tanggal_mulai']) . ').'
                    );
                }

                // Syarat pelunasan: BAST ada dan fisik 100%
                if ($jenis === 'PELUNASAN') {
                    if (trim((string) ($realisasi['nomor_bast'] ?? '')) === '') {
                        throw new RuntimeException(
                            'Pelunasan mensyaratkan BAST. Lengkapi BAST pada data realisasi terlebih dahulu.'
                        );
                    }

                    if (
                        $realisasi['tanggal_bast'] !== null
                        && $tanggalBayar < $realisasi['tanggal_bast']
                    ) {
                        throw new RuntimeException(
                            'Tanggal pelunasan tidak boleh sebelum tanggal BAST ('
                            . tanggalIndo($realisasi['tanggal_bast']) . ').'
                        );
                    }

                    if ($fisik === null || $fisik < 100) {
                        throw new RuntimeException('Pelunasan mensyaratkan progres fisik 100%.');
                    }
                }

                // Progres fisik tidak boleh turun
                if (
                    $fisik !== null
                    && $rekap['fisik_tertinggi'] !== null
                    && $fisik + 0.005 < (float) $rekap['fisik_tertinggi']
                ) {
                    throw new RuntimeException(
                        'Progres fisik tidak boleh lebih kecil dari progres sebelumnya ('
                        . persen($rekap['fisik_tertinggi']) . ').'
                    );
                }

                // Nomor SP2D tidak boleh ganda
                if ($nomorSp2d !== '') {
                    $stmt = $pdo->prepare(
                        'SELECT COUNT(*) FROM realisasi_pembayaran WHERE nomor_sp2d = :nomor'
                    );
                    $stmt->execute([':nomor' => $nomorSp2d]);

                    if ((int) $stmt->fetchColumn() > 0) {
                        throw new RuntimeException(
                            'Nomor SP2D sudah digunakan pada pembayaran lain.'
                        );
                    }
                }

                // Cegah input ganda (misalnya klik simpan dua kali)
                $stmt = $pdo->prepare(
                    'SELECT COUNT(*) FROM realisasi_pembayaran
                    WHERE realisasi_id = :rid
                    AND jenis = :jenis
                    AND tanggal_bayar = :tgl
                    AND jumlah_dibayar = :jml'
                );
                $stmt->execute([
                    ':rid'   => $realisasiId,
                    ':jenis' => $jenis,
                    ':tgl'   => $tanggalBayar,
                    ':jml'   => $jumlahInput,
                ]);

                if ((int) $stmt->fetchColumn() > 0) {
                    throw new RuntimeException(
                        'Pembayaran dengan jenis, tanggal, dan jumlah yang sama sudah tercatat.'
                    );
                }

                $stmt = $pdo->prepare(
                    'INSERT INTO realisasi_pembayaran (
                    realisasi_id, jenis, nomor_spm, nomor_sp2d,
                    tanggal_bayar, jumlah_dibayar, persentase_fisik, catatan
                    ) VALUES (
                    :realisasi_id, :jenis, :nomor_spm, :nomor_sp2d,
                    :tanggal_bayar, :jumlah, :fisik, :catatan
                    )'
                );

                $stmt->execute([
                    ':realisasi_id' => $realisasiId,
                    ':jenis' => $jenis,
                    ':nomor_spm' => $nomorSpm !== '' ? $nomorSpm : null,
                    ':nomor_sp2d' => $nomorSp2d !== '' ? $nomorSp2d : null,
                    ':tanggal_bayar' => $tanggalBayar,
                    ':jumlah' => $jumlahInput,
                    ':fisik' => $fisikInput !== '' ? $fisikInput : null,
                    ':catatan' => $catatan !== '' ? $catatan : null,
                ]);

                $pdo->commit();

                setFlash('success', 'Pembayaran berhasil disimpan.');
                redirect(url('pages/pembayaran.php'));
            } catch (RuntimeException $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $errors[] = $e->getMessage();
            } catch (PDOException $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                error_log($e->getMessage());
                $errors[] = 'Pembayaran gagal disimpan. Periksa log PHP.';
            }
        }
    }
}

// =====================================================================
// DATA
// =====================================================================

// Ringkasan per rincian: pagu, realisasi, sisa pagu, persentase
$ringkasanRincian = $pdo->query(
    "SELECT
    v.kode_rup,
    ra.uraian,
    v.total_pagu,
    v.total_realisasi,
    v.sisa_pagu,
    v.persen_realisasi
    FROM v_rincian_ringkasan AS v
    INNER JOIN rincian_anggaran AS ra ON ra.id = v.rincian_id
    WHERE ra.status <> 'DIBATALKAN'
    ORDER BY v.kode_rup ASC, v.rincian_id ASC"
)->fetchAll();

// Realisasi aktif + posisi pembayaran
$realisasiList = $pdo->query(
    "SELECT
    r.id,
    r.metode,
    r.status,
    r.nomor_kontrak,
    r.nomor_surat_pesanan,
    r.nomor_spk,
    r.pelaksana_swakelola,
    ra.kode_rup,
    ra.uraian,
    p.nama_penyedia,
    v.nilai_realisasi,
    v.total_dibayar,
    v.sisa_belum_dibayar,
    v.persen_dibayar,
    v.persen_fisik
    FROM realisasi_anggaran AS r
    INNER JOIN rincian_anggaran AS ra ON ra.id = r.rincian_anggaran_id
    INNER JOIN v_realisasi_ringkasan AS v ON v.realisasi_id = r.id
    LEFT JOIN master_penyedia AS p ON p.id = r.penyedia_id
    WHERE r.status <> 'DIBATALKAN'
    ORDER BY r.id DESC"
)->fetchAll();

// Realisasi yang masih bisa dibayar
$realisasiBisaBayar = array_filter(
    $realisasiList,
    static fn (array $r): bool => $r['status'] !== 'DRAFT'
        && (float) $r['sisa_belum_dibayar'] > 0.005
);

// Riwayat pembayaran (urut lama ke baru agar kumulatif benar)
$riwayatRaw = $pdo->query(
    "SELECT
    b.id,
    b.realisasi_id,
    b.jenis,
    b.nomor_spm,
    b.nomor_sp2d,
    b.tanggal_bayar,
    b.jumlah_dibayar,
    b.persentase_fisik,
    b.catatan,
    r.nilai_realisasi,
    ra.kode_rup
    FROM realisasi_pembayaran AS b
    INNER JOIN realisasi_anggaran AS r ON r.id = b.realisasi_id
    INNER JOIN rincian_anggaran AS ra ON ra.id = r.rincian_anggaran_id
    ORDER BY b.realisasi_id ASC, b.tanggal_bayar ASC, b.id ASC"
)->fetchAll();

$kumulatif = [];
$riwayat = [];
$terakhirMap = [];

foreach ($riwayatRaw as $row) {
    $rid = (int) $row['realisasi_id'];
    $kumulatif[$rid] = ($kumulatif[$rid] ?? 0.0) + (float) $row['jumlah_dibayar'];
    $terakhirMap[$rid] = (int) $row['id'];

    $nilai = (float) $row['nilai_realisasi'];
    $row['persen_ini'] = $nilai > 0 ? (float) $row['jumlah_dibayar'] / $nilai * 100 : 0;
    $row['persen_kumulatif'] = $nilai > 0 ? $kumulatif[$rid] / $nilai * 100 : 0;
    $row['sisa_setelah'] = $nilai - $kumulatif[$rid];

    $riwayat[] = $row;
}

// Terbaru di atas
$riwayat = array_reverse($riwayat);

function pelaksanaLabel(array $r): string
{
    return $r['metode'] === 'PENYEDIA'
        ? (string) ($r['nama_penyedia'] ?? '-')
        : 'Swakelola: ' . (string) ($r['pelaksana_swakelola'] ?? '-');
}

function dokumenLabel(array $r): string
{
    return (string) ($r['nomor_kontrak'] ?? $r['nomor_surat_pesanan'] ?? $r['nomor_spk'] ?? '-');
}

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<main class="main-content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Pembayaran Realisasi</h2>
            <p class="page-description">
                Catat uang muka, termin, dan pelunasan, lengkap dengan persentase
                realisasi dan sisa anggaran.
            </p>
        </div>

        <?php if ($edit !== null && canManage()): ?>
            <div class="page-actions">
                <a class="btn btn-light" href="<?= e(url('pages/pembayaran.php')) ?>">
                    Batal Ubah
                </a>
            </div>
        <?php endif; ?>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $msg): ?>
                <div><?= e($msg) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!canManage()): ?>
        <div class="alert alert-info">
            Peran Anda hanya dapat melihat data. Pencatatan dan perubahan
            pembayaran memerlukan peran Administrator atau Operator.
        </div>
    <?php endif; ?>

    <!-- ================= RINGKASAN PER RINCIAN ================= -->
    <section class="card">
        <div class="card-header">
            <h3>Ringkasan Pagu per Rincian</h3>
            <span><?= count($ringkasanRincian) ?> rincian</span>
        </div>

        <div class="card-body">
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Kode RUP</th>
                            <th>Uraian</th>
                            <th class="num">Total Pagu</th>
                            <th class="num">Total Realisasi</th>
                            <th class="num">Sisa Pagu</th>
                            <th class="num">% Realisasi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($ringkasanRincian)): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted">
                                    Belum ada rincian anggaran.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($ringkasanRincian as $i => $row): ?>
                                <tr>
                                    <td><?= $i + 1 ?></td>
                                    <td><?= e($row['kode_rup']) ?></td>
                                    <td><?= e($row['uraian']) ?></td>
                                    <td class="num"><?= e(rupiah($row['total_pagu'])) ?></td>
                                    <td class="num"><?= e(rupiah($row['total_realisasi'])) ?></td>
                                    <td class="num"><?= e(rupiah($row['sisa_pagu'])) ?></td>
                                    <td class="num"><?= e(persen($row['persen_realisasi'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <?php if ($edit !== null && canManage()): ?>
        <!-- ================= FORM UBAH PEMBAYARAN ================= -->
        <section class="card">
            <div class="card-header">
                <h3>Ubah Data Pembayaran</h3>
                <span class="badge badge-netral"><?= e($edit['kode_rup']) ?></span>
            </div>

            <div class="card-body">
                <div class="alert alert-info">
                    Hanya nomor SPM, nomor SP2D, dan catatan yang dapat diubah.
                    Untuk membetulkan tanggal atau jumlah, hapus pembayaran
                    terakhir lalu catat ulang.
                </div>

                <div class="stat-list">
                    <div class="stat-row">
                        <span class="label">Jenis</span>
                        <span class="value"><?= e($labelJenis[$edit['jenis']] ?? $edit['jenis']) ?></span>
                    </div>
                    <div class="stat-row">
                        <span class="label">Tanggal Bayar</span>
                        <span class="value"><?= e(tanggalIndo($edit['tanggal_bayar'])) ?></span>
                    </div>
                    <div class="stat-row">
                        <span class="label">Jumlah Dibayar</span>
                        <span class="value"><?= e(rupiah($edit['jumlah_dibayar'])) ?></span>
                    </div>
                    <div class="stat-row">
                        <span class="label">Progres Fisik</span>
                        <span class="value">
                            <?= $edit['persentase_fisik'] !== null
                                ? e(persen($edit['persentase_fisik']))
                                : '-' ?>
                        </span>
                    </div>
                </div>

                <form method="post" action="<?= e(url('pages/pembayaran.php')) ?>">
                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                    <input type="hidden" name="aksi" value="ubah">
                    <input type="hidden" name="id" value="<?= (int) $edit['id'] ?>">

                    <div class="form-grid">
                        <div class="form-group">
                            <label for="nomor_spm">Nomor SPM</label>
                            <input
                                type="text"
                                id="nomor_spm"
                                name="nomor_spm"
                                maxlength="100"
                                value="<?= $old('nomor_spm') ?>"
                            >
                        </div>

                        <div class="form-group">
                            <label for="nomor_sp2d">Nomor SP2D</label>
                            <input
                                type="text"
                                id="nomor_sp2d"
                                name="nomor_sp2d"
                                maxlength="100"
                                value="<?= $old('nomor_sp2d') ?>"
                            >
                        </div>

                        <div class="form-group full">
                            <label for="catatan">Catatan</label>
                            <textarea id="catatan" name="catatan"><?= $old('catatan') ?></textarea>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Simpan Perubahan</button>
                        <a class="btn btn-light" href="<?= e(url('pages/pembayaran.php')) ?>">
                            Batal
                        </a>
                    </div>
                </form>
            </div>
        </section>
    <?php elseif (canManage()): ?>
        <!-- ================= FORM PEMBAYARAN ================= -->
        <section class="card">
            <div class="card-header">
                <h3>Formulir Pembayaran</h3>
            </div>

            <div class="card-body">
                <?php if (empty($realisasiBisaBayar)): ?>
                    <p class="text-muted">
                        Belum ada realisasi yang dapat dibayar (semua sudah lunas
                        atau masih Draft).
                    </p>
                <?php else: ?>
                    <form method="post" action="<?= e(url('pages/pembayaran.php')) ?>">
                        <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                        <input type="hidden" name="aksi" value="simpan">

                        <div class="form-grid">
                            <div class="form-group full">
                                <label for="realisasi_id">Realisasi *</label>

                                <select id="realisasi_id" name="realisasi_id" required>
                                    <option value="">-- Pilih Realisasi --</option>

                                    <?php foreach ($realisasiBisaBayar as $r): ?>
                                        <option
                                            value="<?= e($r['id']) ?>"
                                            data-sisa="<?= e($r['sisa_belum_dibayar']) ?>"
                                            data-nilai="<?= e($r['nilai_realisasi']) ?>"
                                            <?= $selected('realisasi_id', (string) $r['id']) ?>
                                        >
                                            <?= e($r['kode_rup']) ?>
                                            | <?= e(pelaksanaLabel($r)) ?>
                                            | <?= e(dokumenLabel($r)) ?>
                                            | Sisa: <?= e(rupiah($r['sisa_belum_dibayar'])) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <small id="infoSisa"></small>
                            </div>

                            <div class="form-group">
                                <label for="jenis">Jenis Pembayaran *</label>

                                <select id="jenis" name="jenis" required>
                                    <option value="">-- Pilih Jenis --</option>
                                    <?php foreach ($labelJenis as $kode => $label): ?>
                                        <option value="<?= e($kode) ?>" <?= $selected('jenis', $kode) ?>>
                                            <?= e($label) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="tanggal_bayar">Tanggal Bayar *</label>
                                <input
                                    type="date"
                                    id="tanggal_bayar"
                                    name="tanggal_bayar"
                                    max="<?= e(date('Y-m-d')) ?>"
                                    value="<?= $old('tanggal_bayar') ?>"
                                    required
                                >
                            </div>

                            <div class="form-group">
                                <label for="nomor_spm">Nomor SPM</label>
                                <input
                                    type="text"
                                    id="nomor_spm"
                                    name="nomor_spm"
                                    maxlength="100"
                                    value="<?= $old('nomor_spm') ?>"
                                >
                            </div>

                            <div class="form-group">
                                <label for="nomor_sp2d">Nomor SP2D</label>
                                <input
                                    type="text"
                                    id="nomor_sp2d"
                                    name="nomor_sp2d"
                                    maxlength="100"
                                    value="<?= $old('nomor_sp2d') ?>"
                                >
                            </div>

                            <div class="form-group">
                                <label for="jumlah_dibayar">Jumlah Dibayar *</label>
                                <input
                                    type="number"
                                    id="jumlah_dibayar"
                                    name="jumlah_dibayar"
                                    min="0.01"
                                    step="0.01"
                                    value="<?= $old('jumlah_dibayar') ?>"
                                    required
                                >
                                <small id="infoPersen"></small>
                            </div>

                            <div class="form-group">
                                <label for="persentase_fisik">Progres Fisik (%)</label>
                                <input
                                    type="number"
                                    id="persentase_fisik"
                                    name="persentase_fisik"
                                    min="0"
                                    max="100"
                                    step="0.01"
                                    value="<?= $old('persentase_fisik') ?>"
                                >
                            </div>

                            <div class="form-group full">
                                <label for="catatan">Catatan</label>
                                <textarea id="catatan" name="catatan"><?= $old('catatan') ?></textarea>
                            </div>
                        </div>

                        <p class="text-muted">* Wajib diisi.</p>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-success">Simpan Pembayaran</button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <!-- ================= POSISI PER REALISASI ================= -->
    <section class="card">
        <div class="card-header">
            <h3>Posisi Pembayaran per Realisasi</h3>
            <span><?= count($realisasiList) ?> realisasi</span>
        </div>

        <div class="card-body">
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Kode RUP</th>
                            <th>Pelaksana</th>
                            <th>Dokumen</th>
                            <th class="num">Nilai Realisasi</th>
                            <th class="num">Total Dibayar</th>
                            <th class="num">Sisa Belum Dibayar</th>
                            <th class="num">% Dibayar</th>
                            <th class="num">% Fisik</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($realisasiList)): ?>
                            <tr>
                                <td colspan="10" class="text-center text-muted">
                                    Belum ada realisasi.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($realisasiList as $i => $row): ?>
                                <tr>
                                    <td><?= $i + 1 ?></td>
                                    <td><?= e($row['kode_rup']) ?></td>
                                    <td><?= e(pelaksanaLabel($row)) ?></td>
                                    <td><?= e(dokumenLabel($row)) ?></td>
                                    <td class="num"><?= e(rupiah($row['nilai_realisasi'])) ?></td>
                                    <td class="num"><?= e(rupiah($row['total_dibayar'])) ?></td>
                                    <td class="num"><?= e(rupiah($row['sisa_belum_dibayar'])) ?></td>
                                    <td class="num"><?= e(persen($row['persen_dibayar'])) ?></td>
                                    <td class="num"><?= e(persen($row['persen_fisik'])) ?></td>
                                    <td><?= statusBadge($row['status']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <!-- ================= RIWAYAT ================= -->
    <section class="card">
        <div class="card-header">
            <h3>Riwayat Pembayaran</h3>
            <span><?= count($riwayat) ?> transaksi</span>
        </div>

        <div class="card-body">
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Tanggal</th>
                            <th>Kode RUP</th>
                            <th>Jenis</th>
                            <th>No. SPM</th>
                            <th>No. SP2D</th>
                            <th class="num">Jumlah</th>
                            <th class="num">% Ini</th>
                            <th class="num">% Kumulatif</th>
                            <th class="num">Sisa Setelahnya</th>
                            <th class="num">% Fisik</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($riwayat)): ?>
                            <tr>
                                <td colspan="12" class="text-center text-muted">
                                    Belum ada pembayaran.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($riwayat as $i => $row): ?>
                                <tr>
                                    <td><?= $i + 1 ?></td>
                                    <td><?= e(tanggalIndo($row['tanggal_bayar'])) ?></td>
                                    <td><?= e($row['kode_rup']) ?></td>
                                    <td><?= e($labelJenis[$row['jenis']] ?? $row['jenis']) ?></td>
                                    <td><?= e($row['nomor_spm'] ?? '-') ?></td>
                                    <td><?= e($row['nomor_sp2d'] ?? '-') ?></td>
                                    <td class="num"><?= e(rupiah($row['jumlah_dibayar'])) ?></td>
                                    <td class="num"><?= e(persen($row['persen_ini'])) ?></td>
                                    <td class="num"><?= e(persen($row['persen_kumulatif'])) ?></td>
                                    <td class="num"><?= e(rupiah($row['sisa_setelah'])) ?></td>
                                    <td class="num"><?= e(persen($row['persentase_fisik'])) ?></td>
                                    <td>
                                        <?php if (canManage()): ?>
                                            <div class="actions">
                                                <a
                                                    class="btn btn-light btn-sm"
                                                    href="<?= e(url('pages/pembayaran.php?edit=' . (int) $row['id'])) ?>"
                                                >Ubah</a>

                                                <?php if (($terakhirMap[(int) $row['realisasi_id']] ?? 0) === (int) $row['id']): ?>
                                                    <form
                                                        method="post"
                                                        action="<?= e(url('pages/pembayaran.php')) ?>"
                                                        data-confirm="Hapus pembayaran terakhir ini? Tindakan tidak dapat dibatalkan."
                                                    >
                                                        <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                                        <input type="hidden" name="aksi" value="hapus">
                                                        <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                                                        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <?php if (canManage() && empty($realisasiBisaBayar)): ?>
        <p class="text-muted">
            Pembayaran hanya dapat dicatat untuk realisasi berstatus Berjalan
            atau Selesai dan masih memiliki sisa yang belum dibayar.
        </p>
    <?php endif; ?>

    <script>
    (function () {
        var pilih = document.getElementById('realisasi_id');
        var jenis = document.getElementById('jenis');
        var jumlah = document.getElementById('jumlah_dibayar');
        var infoSisa = document.getElementById('infoSisa');
        var infoPersen = document.getElementById('infoPersen');

        if (!pilih) { return; }

        function rp(n) {
            return 'Rp ' + n.toLocaleString('id-ID', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }

        function opsi() { return pilih.options[pilih.selectedIndex]; }

        function updateInfo() {
            var o = opsi();
            var sisa = parseFloat(o.getAttribute('data-sisa'));
            var nilai = parseFloat(o.getAttribute('data-nilai'));

            if (!o.value || isNaN(sisa)) {
                infoSisa.textContent = '';
                infoPersen.textContent = '';
                return;
            }

            infoSisa.textContent = 'Sisa belum dibayar: ' + rp(sisa)
                + ' dari nilai ' + rp(nilai);

            var j = parseFloat(jumlah.value);

            if (!isNaN(j) && nilai > 0) {
                infoPersen.textContent = (j / nilai * 100).toFixed(2).replace('.', ',')
                    + '% dari nilai realisasi';
            } else {
                infoPersen.textContent = '';
            }
        }

        function isiPelunasan() {
            var o = opsi();
            var sisa = parseFloat(o.getAttribute('data-sisa'));

            if (jenis.value === 'PELUNASAN' && o.value && !isNaN(sisa)) {
                jumlah.value = sisa.toFixed(2);
            }
            updateInfo();
        }

        pilih.addEventListener('change', isiPelunasan);
        jenis.addEventListener('change', isiPelunasan);
        jumlah.addEventListener('input', updateInfo);

        updateInfo();
    })();
    </script>
</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
