<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

requireLogin();

$pageTitle = 'Rekap Penyedia';
$currentPage = 'rekap_penyedia';

$tahunList = array_map(
    'intval',
    $pdo->query('SELECT DISTINCT tahun_anggaran FROM kegiatan ORDER BY tahun_anggaran DESC')
        ->fetchAll(PDO::FETCH_COLUMN)
);

$tahunFilter = filter_input(INPUT_GET, 'tahun', FILTER_VALIDATE_INT);
$tahunFilter = is_int($tahunFilter) && in_array($tahunFilter, $tahunList, true)
    ? $tahunFilter
    : 0;

$penyediaList = $pdo->query(
    'SELECT DISTINCT mp.id, mp.nama_penyedia, mp.npwp
    FROM master_penyedia AS mp
    INNER JOIN realisasi_anggaran AS r ON r.penyedia_id = mp.id
    ORDER BY mp.nama_penyedia ASC'
)->fetchAll();

$penyediaIds = array_map('intval', array_column($penyediaList, 'id'));
$penyediaFilter = filter_input(INPUT_GET, 'penyedia', FILTER_VALIDATE_INT);

if (!is_int($penyediaFilter) || !in_array($penyediaFilter, $penyediaIds, true)) {
    $penyediaFilter = 0;
}

$pembayaranSub = '(
    SELECT realisasi_id, SUM(jumlah_dibayar) AS total_dibayar
    FROM realisasi_pembayaran
    GROUP BY realisasi_id
) AS b';

$sqlRingkasan = 'SELECT
        mp.id,
        mp.nama_penyedia,
        mp.npwp,
        mp.nama_pimpinan,
        mp.aktif,
        COUNT(CASE WHEN r.status <> \'DIBATALKAN\' THEN r.id END) AS jumlah_realisasi,
        COUNT(DISTINCT CASE WHEN r.status <> \'DIBATALKAN\' THEN ra.kode_rup END) AS jumlah_rup,
        COALESCE(SUM(
            CASE WHEN r.status <> \'DIBATALKAN\' THEN r.nilai_realisasi ELSE 0 END
        ), 0) AS total_nilai,
        COALESCE(SUM(
            CASE WHEN r.status <> \'DIBATALKAN\' THEN COALESCE(b.total_dibayar, 0) ELSE 0 END
        ), 0) AS total_dibayar
    FROM master_penyedia AS mp
    INNER JOIN realisasi_anggaran AS r ON r.penyedia_id = mp.id
    INNER JOIN rincian_anggaran AS ra ON ra.id = r.rincian_anggaran_id
    INNER JOIN sub_kegiatan AS sk ON sk.id = ra.sub_kegiatan_id
    INNER JOIN kegiatan AS k ON k.id = sk.kegiatan_id
    LEFT JOIN ' . $pembayaranSub . ' ON b.realisasi_id = r.id
    WHERE 1 = 1';

$paramsRingkasan = [];

if ($tahunFilter > 0) {
    $sqlRingkasan .= ' AND k.tahun_anggaran = :tahun_ringkasan';
    $paramsRingkasan[':tahun_ringkasan'] = $tahunFilter;
}

if ($penyediaFilter > 0) {
    $sqlRingkasan .= ' AND mp.id = :penyedia_ringkasan';
    $paramsRingkasan[':penyedia_ringkasan'] = $penyediaFilter;
}

$sqlRingkasan .= ' GROUP BY
        mp.id, mp.nama_penyedia, mp.npwp, mp.nama_pimpinan, mp.aktif
    ORDER BY total_nilai DESC, mp.nama_penyedia ASC';

$stmt = $pdo->prepare($sqlRingkasan);
$stmt->execute($paramsRingkasan);
$ringkasanPenyedia = $stmt->fetchAll();

$sqlAktivitas = 'SELECT
        r.id,
        r.nilai_realisasi,
        r.nomor_kontrak,
        r.tanggal_kontrak,
        r.nomor_surat_pesanan,
        r.tanggal_surat_pesanan,
        r.nomor_spk,
        r.tanggal_spk,
        r.tanggal_mulai,
        r.tanggal_selesai,
        r.nomor_bast,
        r.tanggal_bast,
        r.status,
        ra.kode_rup,
        ra.uraian,
        sk.kode_sub_kegiatan,
        sk.nama_sub_kegiatan,
        k.tahun_anggaran,
        mr.kode_rekening,
        mr.nama_rekening,
        mp.id AS penyedia_id,
        mp.nama_penyedia,
        COALESCE(b.total_dibayar, 0) AS total_dibayar
    FROM realisasi_anggaran AS r
    INNER JOIN rincian_anggaran AS ra ON ra.id = r.rincian_anggaran_id
    INNER JOIN sub_kegiatan AS sk ON sk.id = ra.sub_kegiatan_id
    INNER JOIN kegiatan AS k ON k.id = sk.kegiatan_id
    INNER JOIN master_rekening AS mr ON mr.id = ra.rekening_id
    INNER JOIN master_penyedia AS mp ON mp.id = r.penyedia_id
    LEFT JOIN ' . $pembayaranSub . ' ON b.realisasi_id = r.id
    WHERE r.penyedia_id IS NOT NULL';

$paramsAktivitas = [];

if ($tahunFilter > 0) {
    $sqlAktivitas .= ' AND k.tahun_anggaran = :tahun_aktivitas';
    $paramsAktivitas[':tahun_aktivitas'] = $tahunFilter;
}

if ($penyediaFilter > 0) {
    $sqlAktivitas .= ' AND mp.id = :penyedia_aktivitas';
    $paramsAktivitas[':penyedia_aktivitas'] = $penyediaFilter;
}

$sqlAktivitas .= ' ORDER BY mp.nama_penyedia ASC, r.tanggal_mulai ASC, r.id ASC';

$stmt = $pdo->prepare($sqlAktivitas);
$stmt->execute($paramsAktivitas);
$aktivitas = $stmt->fetchAll();

$jumlahPenyedia = count($ringkasanPenyedia);
$jumlahAktivitas = count($aktivitas);
$totalNilai = 0.0;
$totalDibayar = 0.0;

foreach ($ringkasanPenyedia as $ringkasan) {
    $totalNilai += (float) $ringkasan['total_nilai'];
    $totalDibayar += (float) $ringkasan['total_dibayar'];
}

$totalSisa = $totalNilai - $totalDibayar;

$labelTahun = $tahunFilter > 0 ? (string) $tahunFilter : 'Semua Tahun';
$labelPenyedia = 'Semua Penyedia';

foreach ($penyediaList as $penyedia) {
    if ((int) $penyedia['id'] === $penyediaFilter) {
        $labelPenyedia = $penyedia['nama_penyedia'];
        break;
    }
}

$parameterTautan = [];

if ($tahunFilter > 0) {
    $parameterTautan['tahun'] = $tahunFilter;
}

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<main class="main-content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Rekap Penyedia</h2>
            <p class="page-description">
                Rekapitulasi aktivitas penyedia pada realisasi anggaran, lengkap dengan
                nilai realisasi, pembayaran, dan sisa yang belum dibayar.
            </p>
        </div>
    </div>

    <div class="kpi-grid">
        <div class="kpi">
            <span class="kpi-label">Jumlah Penyedia</span>
            <span class="kpi-value"><?= number_format($jumlahPenyedia, 0, ',', '.') ?></span>
            <span class="kpi-sub"><?= e($labelTahun) ?></span>
        </div>

        <div class="kpi kpi--info">
            <span class="kpi-label">Jumlah Aktivitas</span>
            <span class="kpi-value"><?= number_format($jumlahAktivitas, 0, ',', '.') ?></span>
            <span class="kpi-sub">Realisasi melalui penyedia</span>
        </div>

        <div class="kpi kpi--accent">
            <span class="kpi-label">Total Nilai Realisasi</span>
            <span class="kpi-value" title="<?= e(rupiah($totalNilai)) ?>">
                <?= e(rupiahRingkas($totalNilai)) ?>
            </span>
            <span class="kpi-sub"><?= e($labelPenyedia) ?></span>
        </div>

        <div class="kpi <?= $totalSisa < 0 ? 'kpi--danger' : 'kpi--warning' ?>">
            <span class="kpi-label">Sisa Belum Dibayar</span>
            <span class="kpi-value" title="<?= e(rupiah($totalSisa)) ?>">
                <?= e(rupiahRingkas($totalSisa)) ?>
            </span>
            <span class="kpi-sub">
                Dibayar <strong><?= e(rupiahRingkas($totalDibayar)) ?></strong>
            </span>
        </div>
    </div>

    <section class="card">
        <div class="card-header">
            <div>
                <h3>Ringkasan per Penyedia</h3>
                <p class="card-subtitle">
                    Tahun <?= e($labelTahun) ?> &middot; <?= e($labelPenyedia) ?>
                </p>
            </div>
            <span class="text-muted"><?= $jumlahPenyedia ?> penyedia</span>
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Penyedia</th>
                        <th>Status</th>
                        <th class="num">Jumlah RUP</th>
                        <th class="num">Jumlah Realisasi</th>
                        <th class="num">Total Realisasi</th>
                        <th class="num">Dibayar</th>
                        <th class="num">Sisa</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($ringkasanPenyedia)): ?>
                        <tr>
                            <td colspan="9" class="text-center">
                                Belum ada aktivitas penyedia pada realisasi anggaran.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($ringkasanPenyedia as $i => $row): ?>
                            <?php
                            $sisa = (float) $row['total_nilai'] - (float) $row['total_dibayar'];
                            $tautanFilter = $parameterTautan;
                            $tautanFilter['penyedia'] = (int) $row['id'];
                            ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td>
                                    <strong><?= e($row['nama_penyedia']) ?></strong><br>
                                    <span class="text-muted">
                                        <?= e($row['npwp'] !== null && $row['npwp'] !== '' ? $row['npwp'] : 'NPWP -') ?>
                                    </span>
                                    <?php if (!empty($row['nama_pimpinan'])): ?>
                                        <br>
                                        <small class="text-muted"><?= e($row['nama_pimpinan']) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?= statusBadge((int) $row['aktif'] === 1 ? 'AKTIF' : 'NONAKTIF') ?></td>
                                <td class="num"><?= number_format((int) $row['jumlah_rup'], 0, ',', '.') ?></td>
                                <td class="num"><?= number_format((int) $row['jumlah_realisasi'], 0, ',', '.') ?></td>
                                <td class="num"><strong><?= rupiah($row['total_nilai']) ?></strong></td>
                                <td class="num"><?= rupiah($row['total_dibayar']) ?></td>
                                <td class="num <?= $sisa < 0 ? 'text-danger' : '' ?>"><?= rupiah($sisa) ?></td>
                                <td>
                                    <a
                                        class="btn btn-light btn-sm"
                                        href="<?= e(url('pages/rekap_penyedia.php') . '?' . http_build_query($tautanFilter)) ?>"
                                    >Lihat Aktivitas</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
                <?php if (!empty($ringkasanPenyedia)): ?>
                    <tfoot>
                        <tr>
                            <th colspan="5">Total</th>
                            <th class="num"><?= rupiah($totalNilai) ?></th>
                            <th class="num"><?= rupiah($totalDibayar) ?></th>
                            <th class="num <?= $totalSisa < 0 ? 'text-danger' : '' ?>">
                                <?= rupiah($totalSisa) ?>
                            </th>
                            <th></th>
                        </tr>
                    </tfoot>
                <?php endif; ?>
            </table>
        </div>
    </section>

    <section class="card">
        <div class="card-header">
            <h3>Aktivitas Penyedia pada Realisasi</h3>
            <span class="text-muted"><?= number_format($jumlahAktivitas, 0, ',', '.') ?> data</span>
        </div>

        <form method="get" class="filter-bar" action="<?= e(url('pages/rekap_penyedia.php')) ?>">
            <div class="form-group">
                <label for="filter_tahun">Tahun Anggaran</label>
                <select id="filter_tahun" name="tahun" data-auto-submit>
                    <option value="0">Semua tahun</option>
                    <?php foreach ($tahunList as $th): ?>
                        <option value="<?= $th ?>" <?= $tahunFilter === $th ? 'selected' : '' ?>>
                            <?= $th ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="filter_penyedia">Penyedia</label>
                <select id="filter_penyedia" name="penyedia" data-auto-submit>
                    <option value="0">Semua penyedia</option>
                    <?php foreach ($penyediaList as $penyedia): ?>
                        <option
                            value="<?= (int) $penyedia['id'] ?>"
                            <?= $penyediaFilter === (int) $penyedia['id'] ? 'selected' : '' ?>
                        >
                            <?= e($penyedia['nama_penyedia']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit" class="btn btn-sm">Terapkan</button>
            <a class="btn btn-outline-dark btn-sm" href="<?= e(url('pages/rekap_penyedia.php')) ?>">Reset</a>
        </form>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Penyedia</th>
                        <th>Tahun</th>
                        <th>Kode RUP / Uraian</th>
                        <th>Sub Kegiatan</th>
                        <th>Rekening</th>
                        <th>Dokumen</th>
                        <th>Pelaksanaan</th>
                        <th class="num">Nilai Realisasi</th>
                        <th class="num">Dibayar</th>
                        <th class="num">Sisa</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($aktivitas)): ?>
                        <tr>
                            <td colspan="12" class="text-center">
                                Belum ada aktivitas penyedia pada realisasi anggaran.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($aktivitas as $i => $row): ?>
                            <?php
                            $dibayar = (float) $row['total_dibayar'];
                            $sisa = (float) $row['nilai_realisasi'] - $dibayar;

                            $jenisDokumen = 'Dokumen';
                            $nomorDokumen = (string) ($row['nomor_kontrak'] ?? '');

                            if ($nomorDokumen === '') {
                                $nomorDokumen = (string) ($row['nomor_spk'] ?? '');
                                $jenisDokumen = 'SPK';
                            }

                            if ($nomorDokumen === '') {
                                $nomorDokumen = (string) ($row['nomor_surat_pesanan'] ?? '');
                                $jenisDokumen = 'Surat Pesanan';
                            }
                            ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td><?= e($row['nama_penyedia']) ?></td>
                                <td><?= e($row['tahun_anggaran']) ?></td>
                                <td>
                                    <strong><?= e($row['kode_rup']) ?></strong><br>
                                    <span class="text-muted"><?= e($row['uraian']) ?></span>
                                </td>
                                <td>
                                    <strong><?= e($row['kode_sub_kegiatan']) ?></strong><br>
                                    <span class="text-muted"><?= e($row['nama_sub_kegiatan']) ?></span>
                                </td>
                                <td>
                                    <?= e($row['kode_rekening']) ?><br>
                                    <span class="text-muted"><?= e($row['nama_rekening']) ?></span>
                                </td>
                                <td>
                                    <?php if ($nomorDokumen !== ''): ?>
                                        <small class="text-muted"><?= e($jenisDokumen) ?></small><br>
                                        <?= e($nomorDokumen) ?>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="nowrap">
                                    <?= e(tanggalIndo($row['tanggal_mulai'])) ?><br>
                                    <span class="text-muted">s.d. <?= e(tanggalIndo($row['tanggal_selesai'])) ?></span>
                                    <?php if (!empty($row['nomor_bast'])): ?>
                                        <br>
                                        <small class="text-muted">BAST: <?= e($row['nomor_bast']) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td class="num"><?= rupiah($row['nilai_realisasi']) ?></td>
                                <td class="num"><?= rupiah($dibayar) ?></td>
                                <td class="num <?= $sisa < 0 ? 'text-danger' : '' ?>"><?= rupiah($sisa) ?></td>
                                <td><?= statusBadge($row['status']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
