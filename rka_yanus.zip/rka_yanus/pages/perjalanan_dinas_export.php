<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

requireLogin();

$tahunList = array_map(
    'intval',
    $pdo->query('SELECT DISTINCT tahun_anggaran FROM kegiatan ORDER BY tahun_anggaran DESC')
        ->fetchAll(PDO::FETCH_COLUMN)
);

$tahun = filter_input(INPUT_GET, 'tahun', FILTER_VALIDATE_INT);
$tahun = is_int($tahun) && in_array($tahun, $tahunList, true) ? $tahun : 0;

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$id = is_int($id) && $id > 0 ? $id : 0;

$sql = 'SELECT
        pd.id,
        pd.nomor_st,
        pd.tanggal_st,
        pd.maksud,
        pd.tujuan,
        pd.lama_hari,
        pd.tanggal_berangkat,
        pd.tanggal_kembali,
        sk.kode_sub_kegiatan,
        sk.nama_sub_kegiatan,
        k.kode_kegiatan,
        k.nama_kegiatan,
        k.tahun_anggaran,
        mr.kode_rekening,
        mr.nama_rekening,
        COALESCE(vp.total_biaya, 0) AS total_biaya
    FROM perjalanan_dinas AS pd
    INNER JOIN sub_kegiatan AS sk ON sk.id = pd.sub_kegiatan_id
    INNER JOIN kegiatan AS k ON k.id = sk.kegiatan_id
    INNER JOIN master_rekening AS mr ON mr.id = pd.rekening_id
    LEFT JOIN v_perjalanan_ringkasan AS vp ON vp.perjalanan_id = pd.id';

$where = [];
$params = [];

if ($id > 0) {
    $where[] = 'pd.id = :id';
    $params[':id'] = $id;
} elseif ($tahun > 0) {
    $where[] = 'k.tahun_anggaran = :tahun';
    $params[':tahun'] = $tahun;
}

if (!empty($where)) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}

$sql .= ' ORDER BY pd.tanggal_berangkat ASC, pd.id ASC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$daftar = $stmt->fetchAll();

if ($id > 0 && empty($daftar)) {
    setFlash('warning', 'Perjalanan dinas yang ingin diekspor tidak ditemukan.');
    redirect(url('pages/perjalanan_dinas.php'));
}

$pesertaGrup = [];

if (!empty($daftar)) {
    $ids = array_map('intval', array_column($daftar, 'id'));
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare(
        'SELECT *
        FROM perjalanan_dinas_peserta
        WHERE perjalanan_id IN (' . $placeholders . ')
        ORDER BY perjalanan_id ASC, id ASC'
    );
    $stmt->execute($ids);

    foreach ($stmt->fetchAll() as $p) {
        $pesertaGrup[(int) $p['perjalanan_id']][] = $p;
    }
}

$tahunExport = $tahun;

if ($id > 0 && !empty($daftar)) {
    $tahunExport = (int) $daftar[0]['tahun_anggaran'];
}

$judulTahun = $tahunExport > 0 ? (string) $tahunExport : 'SEMUA TAHUN';
$namaFile = 'rekap-perjadin-' . ($tahunExport > 0 ? $tahunExport : 'semua') . '.csv';

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $namaFile . '"');
header('Cache-Control: no-store, no-cache, must-revalidate');

$out = fopen('php://output', 'w');

if ($out === false) {
    exit('Gagal membuat file ekspor.');
}

fwrite($out, "\xEF\xBB\xBF");

$baris = static function (array $values) use ($out): void {
    $aman = array_map(static function (mixed $value): mixed {
        if (!is_string($value) || $value === '') {
            return $value;
        }

        if (preg_match('/^="\d+"$/', $value) === 1) {
            return $value;
        }

        return preg_match('/^[=+\-@\t\r]/', $value) === 1 ? "'" . $value : $value;
    }, $values);

    fputcsv($out, $aman, ';');
};

$baris(['REKAP PERJALANAN DINAS DALAM DAERAH']);
$baris(['TAHUN ANGGARAN ' . $judulTahun]);
$baris(['NAMA SKPD', 'DINAS PERIKANAN DAN PETERNAKAN KABUPATEN BOGOR']);
$baris(['BIDANG', 'PENGUATAN DAYA SAING PRODUK PERIKANAN']);
$baris(['TIM', 'TIM PELAYANAN USAHA DAN PEMASARAN HASIL PERIKANAN']);
$baris([]);
$baris([
    'No',
    'Kode Rekening',
    'Kegiatan',
    'Sub Kegiatan',
    'Nama',
    'NIP',
    'Pangkat',
    'Golongan Ruang',
    'Nomor/tgl Surat Tugas',
    'Jumlah Hari',
    'Tanggal Berangkat',
    'Tanggal Kembali',
    'Maksud Perjalanan Dinas',
    'Tempat Tujuan',
    'Nama Hotel/Penginapan',
    'Tanggal Check In',
    'Tanggal Check Out',
    'Uang Harian',
    'Penginapan/Hotel',
    'Representasi/Biaya Lain2',
    'Biaya Transport Lokal',
    'Taksi/Sewa Mobil',
    'Biaya BBM',
    'Biaya Lain-lain',
    'Total Biaya',
]);

$nomor = 0;
$grandTotal = 0.0;

foreach ($daftar as $row) {
    $nomor++;
    $pesertaRows = $pesertaGrup[(int) $row['id']] ?? [];
    $subtotal = (float) $row['total_biaya'];
    $grandTotal += $subtotal;

    if (empty($pesertaRows)) {
        $baris([
            $nomor,
            $row['kode_rekening'],
            $row['nama_kegiatan'],
            $row['nama_sub_kegiatan'],
            'Tidak ada peserta',
            '', '', '', '', '', '', '', '', '', '', '', '',
            '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00',
        ]);
        continue;
    }

    foreach ($pesertaRows as $p) {
        $nip = trim((string) $p['nip']);

        if ($nip !== '' && preg_match('/^\d{5,30}$/', $nip) === 1) {
            $nip = '="' . $nip . '"';
        }

        $baris([
            $nomor,
            $row['kode_rekening'],
            $row['nama_kegiatan'],
            $row['nama_sub_kegiatan'],
            $p['nama'],
            $nip,
            $p['pangkat'],
            $p['golongan_ruang'],
            $row['nomor_st'] . ' / ' . tanggalIndo($row['tanggal_st']),
            (int) $row['lama_hari'],
            tanggalIndo($row['tanggal_berangkat']),
            tanggalIndo($row['tanggal_kembali']),
            $row['maksud'],
            $row['tujuan'],
            $p['nama_hotel'],
            $p['tanggal_check_in'] !== null ? tanggalIndo($p['tanggal_check_in']) : '',
            $p['tanggal_check_out'] !== null ? tanggalIndo($p['tanggal_check_out']) : '',
            number_format((float) $p['uang_harian'], 2, '.', ''),
            number_format((float) $p['penginapan'], 2, '.', ''),
            number_format((float) $p['representasi'], 2, '.', ''),
            number_format((float) $p['transport_lokal'], 2, '.', ''),
            number_format((float) $p['taksi_sewa'], 2, '.', ''),
            number_format((float) $p['bbm'], 2, '.', ''),
            number_format((float) $p['biaya_lain'], 2, '.', ''),
            number_format((float) $p['total_biaya'], 2, '.', ''),
        ]);
    }

    $subtotalRow = array_fill(0, 25, '');
    $subtotalRow[8] = 'Subtotal ' . $row['nomor_st'];
    $subtotalRow[24] = number_format($subtotal, 2, '.', '');
    $baris($subtotalRow);
}

if (empty($daftar)) {
    $baris(['Belum ada data perjalanan dinas pada periode ini.']);
} else {
    $grandRow = array_fill(0, 25, '');
    $grandRow[0] = 'JUMLAH';
    $grandRow[24] = number_format($grandTotal, 2, '.', '');
    $baris($grandRow);
}

fclose($out);
exit;
