<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

requireLogin();

$pageTitle = 'Data Kegiatan';
$currentPage = 'kegiatan';

$errors = [];
$edit = null;

$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);

if (is_int($editId) && $editId > 0) {
    $stmt = $pdo->prepare(
        'SELECT id, kode_kegiatan, nama_kegiatan, tahun_anggaran, keterangan
        FROM kegiatan
        WHERE id = :id'
    );
    $stmt->execute([':id' => $editId]);
    $edit = $stmt->fetch() ?: null;

    if ($edit === null) {
        setFlash('warning', 'Kegiatan yang ingin diubah tidak ditemukan.');
        redirect(url('pages/kegiatan.php'));
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf($_POST['csrf_token'] ?? null);
    requireManage();

    $aksi = (string) ($_POST['aksi'] ?? 'simpan');

    if ($aksi === 'hapus') {
        $hapusId = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);

        if (!is_int($hapusId) || $hapusId < 1) {
            setFlash('danger', 'Data kegiatan tidak valid.');
        } else {
            $stmt = $pdo->prepare('SELECT nama_kegiatan FROM kegiatan WHERE id = :id');
            $stmt->execute([':id' => $hapusId]);
            $nama = $stmt->fetchColumn();

            $stmt = $pdo->prepare('SELECT COUNT(*) FROM sub_kegiatan WHERE kegiatan_id = :id');
            $stmt->execute([':id' => $hapusId]);
            $jumlahSub = (int) $stmt->fetchColumn();

            if ($nama === false) {
                setFlash('warning', 'Kegiatan tidak ditemukan.');
            } elseif ($jumlahSub > 0) {
                setFlash(
                    'danger',
                    'Kegiatan tidak dapat dihapus karena masih memiliki '
                    . $jumlahSub . ' sub kegiatan.'
                );
            } else {
                $stmt = $pdo->prepare('DELETE FROM kegiatan WHERE id = :id');
                $stmt->execute([':id' => $hapusId]);
                setFlash('success', 'Kegiatan "' . $nama . '" berhasil dihapus.');
            }
        }

        redirect(url('pages/kegiatan.php'));
    }

    $kode = trim((string) ($_POST['kode_kegiatan'] ?? ''));
    $nama = trim((string) ($_POST['nama_kegiatan'] ?? ''));
    $tahun = filter_input(INPUT_POST, 'tahun_anggaran', FILTER_VALIDATE_INT);
    $keterangan = trim((string) ($_POST['keterangan'] ?? ''));

    if ($kode === '' || mb_strlen($kode) > 50) {
        $errors[] = 'Kode kegiatan wajib diisi (maksimal 50 karakter).';
    }

    if ($nama === '' || mb_strlen($nama) > 255) {
        $errors[] = 'Nama kegiatan wajib diisi (maksimal 255 karakter).';
    }

    if (!is_int($tahun) || $tahun < 2000 || $tahun > 2155) {
        $errors[] = 'Tahun anggaran tidak valid.';
    }

    if (empty($errors)) {
        try {
            $cek = $pdo->prepare(
                'SELECT COUNT(*) FROM kegiatan
                WHERE kode_kegiatan = :kode
                  AND tahun_anggaran = :tahun
                  AND id <> :id'
            );
            $cek->execute([
                ':kode'  => $kode,
                ':tahun' => $tahun,
                ':id'    => $edit !== null ? (int) $edit['id'] : 0,
            ]);

            if ((int) $cek->fetchColumn() > 0) {
                $errors[] = 'Kode kegiatan sudah digunakan pada tahun anggaran tersebut.';
            } else {
                if ($edit === null) {
                    $stmt = $pdo->prepare(
                        'INSERT INTO kegiatan
                        (kode_kegiatan, nama_kegiatan, tahun_anggaran, keterangan)
                        VALUES (:kode, :nama, :tahun, :keterangan)'
                    );
                    $stmt->execute([
                        ':kode'       => $kode,
                        ':nama'       => $nama,
                        ':tahun'      => $tahun,
                        ':keterangan' => $keterangan !== '' ? $keterangan : null,
                    ]);

                    setFlash('success', 'Kegiatan berhasil disimpan.');
                } else {
                    $stmt = $pdo->prepare(
                        'UPDATE kegiatan
                        SET kode_kegiatan = :kode,
                            nama_kegiatan = :nama,
                            tahun_anggaran = :tahun,
                            keterangan = :keterangan
                        WHERE id = :id'
                    );
                    $stmt->execute([
                        ':kode'       => $kode,
                        ':nama'       => $nama,
                        ':tahun'      => $tahun,
                        ':keterangan' => $keterangan !== '' ? $keterangan : null,
                        ':id'         => (int) $edit['id'],
                    ]);

                    setFlash('success', 'Kegiatan berhasil diperbarui.');
                }

                redirect(url('pages/kegiatan.php'));
            }
        } catch (PDOException $e) {
            error_log($e->getMessage());

            $errors[] = $e->getCode() === '23000'
                ? 'Kode kegiatan sudah ada. Gunakan kode lain.'
                : 'Data belum berhasil disimpan. Periksa log PHP.';
        }
    }
}

$dataKegiatan = $pdo->query(
    'SELECT
        k.id,
        k.kode_kegiatan,
        k.nama_kegiatan,
        k.tahun_anggaran,
        k.keterangan,
        (SELECT COUNT(*) FROM sub_kegiatan sk WHERE sk.kegiatan_id = k.id) AS jml_sub
    FROM kegiatan AS k
    ORDER BY k.tahun_anggaran DESC, k.id DESC'
)->fetchAll();

$nilai = static function (string $key, string $bawaan = '') use ($edit): string {
    if (array_key_exists($key, $_POST)) {
        return (string) $_POST[$key];
    }

    return $edit !== null ? (string) ($edit[$key] ?? $bawaan) : $bawaan;
};

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<main class="main-content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Data Kegiatan</h2>
            <p class="page-description">
                Kelola kegiatan untuk perencanaan anggaran tahunan.
            </p>
        </div>
        <?php if ($edit !== null): ?>
            <div class="page-actions">
                <a class="btn btn-light" href="<?= e(url('pages/kegiatan.php')) ?>">Batal Ubah</a>
            </div>
        <?php endif; ?>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $msg): ?>
                <div><?= e($msg) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!canManage()): ?>
        <div class="alert alert-info">
            Peran Anda hanya dapat melihat data. Perubahan data dilakukan oleh
            Administrator atau Operator.
        </div>
    <?php endif; ?>

    <?php if (canManage()): ?>
        <section class="card">
            <div class="card-header">
                <div>
                    <h3><?= $edit !== null ? 'Formulir Ubah Kegiatan' : 'Formulir Tambah Kegiatan' ?></h3>
                    <p class="card-subtitle">Kode kegiatan unik untuk setiap tahun anggaran.</p>
                </div>
            </div>

            <form method="post" data-once>
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <input type="hidden" name="aksi" value="simpan">

                <div class="form-grid">
                    <div class="form-group">
                        <label for="kode_kegiatan">Kode Kegiatan *</label>
                        <input
                            type="text"
                            id="kode_kegiatan"
                            name="kode_kegiatan"
                            maxlength="50"
                            value="<?= e($nilai('kode_kegiatan')) ?>"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="tahun_anggaran">Tahun Anggaran *</label>
                        <input
                            type="number"
                            id="tahun_anggaran"
                            name="tahun_anggaran"
                            min="2000"
                            max="2155"
                            value="<?= e($nilai('tahun_anggaran', (string) date('Y'))) ?>"
                            required
                        >
                    </div>

                    <div class="form-group full">
                        <label for="nama_kegiatan">Nama Kegiatan *</label>
                        <input
                            type="text"
                            id="nama_kegiatan"
                            name="nama_kegiatan"
                            maxlength="255"
                            value="<?= e($nilai('nama_kegiatan')) ?>"
                            required
                        >
                    </div>

                    <div class="form-group full">
                        <label for="keterangan">Keterangan</label>
                        <textarea id="keterangan" name="keterangan" rows="3"><?= e($nilai('keterangan')) ?></textarea>
                    </div>
                </div>

                <p class="text-muted">* Wajib diisi</p>

                <div class="form-actions">
                    <button type="submit" class="btn btn-success">
                        <?= $edit !== null ? 'Simpan Perubahan' : 'Simpan Kegiatan' ?>
                    </button>
                    <a class="btn btn-light" href="<?= e(url('pages/kegiatan.php')) ?>">Reset</a>
                </div>
            </form>
        </section>
    <?php endif; ?>

    <section class="card">
        <div class="card-header">
            <h3>Daftar Kegiatan</h3>
            <span class="text-muted"><?= count($dataKegiatan) ?> data</span>
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Kode Kegiatan</th>
                        <th>Nama Kegiatan</th>
                        <th>Tahun</th>
                        <th class="num">Sub</th>
                        <th>Keterangan</th>
                        <?php if (canManage()): ?>
                            <th>Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($dataKegiatan)): ?>
                        <tr>
                            <td colspan="<?= canManage() ? 7 : 6 ?>" class="text-center">
                                Belum ada data kegiatan.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($dataKegiatan as $i => $row): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td class="nowrap"><?= e($row['kode_kegiatan']) ?></td>
                                <td><?= e($row['nama_kegiatan']) ?></td>
                                <td><?= e($row['tahun_anggaran']) ?></td>
                                <td class="num">
                                    <a href="<?= e(url('pages/sub_kegiatan.php?kegiatan=' . (int) $row['id'])) ?>">
                                        <?= (int) $row['jml_sub'] ?>
                                    </a>
                                </td>
                                <td><?= e($row['keterangan']) ?></td>
                                <?php if (canManage()): ?>
                                    <td>
                                        <div class="actions">
                                            <a
                                                class="btn btn-light btn-sm"
                                                href="<?= e(url('pages/kegiatan.php?edit=' . (int) $row['id'])) ?>"
                                            >Ubah</a>

                                            <form
                                                method="post"
                                                data-confirm="Hapus kegiatan &quot;<?= e($row['nama_kegiatan']) ?>&quot;?"
                                            >
                                                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                                <input type="hidden" name="aksi" value="hapus">
                                                <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                            </form>
                                        </div>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
