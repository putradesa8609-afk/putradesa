<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

requireLogin();

$pageTitle = 'Perjalanan Dinas';
$currentPage = 'perjalanan_dinas';

$errors = [];
$edit = null;
$pesertaEdit = [];

$parseTanggal = static function (string $value): ?string {
    $value = trim($value);

    if ($value === '') {
        return null;
    }

    $d = DateTime::createFromFormat('!Y-m-d', $value);

    return $d !== false && $d->format('Y-m-d') === $value ? $value : null;
};

$parseAngka = static function (mixed $value): ?float {
    if (!is_scalar($value)) {
        return null;
    }

    $text = trim((string) $value);

    if ($text === '') {
        return 0.0;
    }

    return is_numeric($text) ? (float) $text : null;
};

$biayaKeys = [
    'uang_harian',
    'penginapan',
    'representasi',
    'transport_lokal',
    'taksi_sewa',
    'bbm',
    'biaya_lain',
];

$pangkatOptions = [
    'Pembina Utama',
    'Pembina Utama Madya',
    'Pembina Utama Muda',
    'Pembina Tk. I',
    'Pembina',
    'Penata Tk. I',
    'Penata',
    'Penata Muda Tk. I',
    'Penata Muda',
    'Pengatur Tk. I',
    'Pengatur',
    'Pengatur Muda Tk. I',
    'Pengatur Muda',
    'Juru Tk. I',
    'Juru',
    'Juru Muda Tk. I',
    'Juru Muda',
];

$golonganOptions = [
    'IV.e',
    'IV.d',
    'IV.c',
    'IV.b',
    'IV.a',
    'III.d',
    'III.c',
    'III.b',
    'III.a',
    'II.d',
    'II.c',
    'II.b',
    'II.a',
    'I.d',
    'I.c',
    'I.b',
    'I.a',
];

$pesertaKosong = static function () use ($biayaKeys): array {
    $row = [
        'nama'            => '',
        'nip'             => '',
        'pangkat'         => '',
        'golongan_ruang'  => '',
        'jabatan'         => '',
        'nama_hotel'      => '',
        'check_in'        => '',
        'check_out'       => '',
    ];

    foreach ($biayaKeys as $key) {
        $row[$key] = '';
    }

    return $row;
};

/* ---------------------------------------------------------------------
 * Data surat tugas yang akan diubah
 * ------------------------------------------------------------------- */

$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);

if (is_int($editId) && $editId > 0) {
    $stmt = $pdo->prepare(
        'SELECT id, sub_kegiatan_id, rekening_id, nomor_st, tanggal_st,
                maksud, tujuan, lama_hari, tanggal_berangkat, tanggal_kembali,
                catatan
        FROM perjalanan_dinas
        WHERE id = :id'
    );
    $stmt->execute([':id' => $editId]);
    $edit = $stmt->fetch() ?: null;

    if ($edit === null) {
        setFlash('warning', 'Perjalanan dinas yang ingin diubah tidak ditemukan.');
        redirect(url('pages/perjalanan_dinas.php'));
    }

    $stmt = $pdo->prepare(
        'SELECT nama, nip, pangkat, golongan_ruang, jabatan, nama_hotel,
                tanggal_check_in, tanggal_check_out,
                uang_harian, penginapan, representasi, transport_lokal,
                taksi_sewa, bbm, biaya_lain
        FROM perjalanan_dinas_peserta
        WHERE perjalanan_id = :id
        ORDER BY id ASC'
    );
    $stmt->execute([':id' => (int) $edit['id']]);
    $pesertaEdit = $stmt->fetchAll();
}

/* ---------------------------------------------------------------------
 * Proses POST
 * ------------------------------------------------------------------- */

$postPeserta = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf($_POST['csrf_token'] ?? null);
    requireManage();

    $aksi = (string) ($_POST['aksi'] ?? 'simpan');

    if ($aksi === 'hapus') {
        $hapusId = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);

        if (!is_int($hapusId) || $hapusId < 1) {
            setFlash('danger', 'Data perjalanan dinas tidak valid.');
        } else {
            $stmt = $pdo->prepare('SELECT nomor_st FROM perjalanan_dinas WHERE id = :id');
            $stmt->execute([':id' => $hapusId]);
            $nomorSt = $stmt->fetchColumn();

            if ($nomorSt === false) {
                setFlash('warning', 'Perjalanan dinas tidak ditemukan.');
            } else {
                $stmt = $pdo->prepare('DELETE FROM perjalanan_dinas WHERE id = :id');
                $stmt->execute([':id' => $hapusId]);
                setFlash(
                    'success',
                    'Perjalanan dinas ' . $nomorSt . ' beserta seluruh pesertanya berhasil dihapus.'
                );
            }
        }

        redirect(url('pages/perjalanan_dinas.php'));
    }

    $subKegiatanId = filter_var($_POST['sub_kegiatan_id'] ?? null, FILTER_VALIDATE_INT);
    $rekeningId = filter_var($_POST['rekening_id'] ?? null, FILTER_VALIDATE_INT);
    $nomorSt = trim((string) ($_POST['nomor_st'] ?? ''));
    $maksud = trim((string) ($_POST['maksud'] ?? ''));
    $tujuan = trim((string) ($_POST['tujuan'] ?? ''));
    $catatan = trim((string) ($_POST['catatan'] ?? ''));
    $tanggalSt = $parseTanggal((string) ($_POST['tanggal_st'] ?? ''));
    $tanggalBerangkat = $parseTanggal((string) ($_POST['tanggal_berangkat'] ?? ''));
    $tanggalKembali = $parseTanggal((string) ($_POST['tanggal_kembali'] ?? ''));
    $lamaHari = filter_var($_POST['lama_hari'] ?? null, FILTER_VALIDATE_INT);

    if (!is_int($subKegiatanId) || $subKegiatanId < 1) {
        $errors[] = 'Sub kegiatan wajib dipilih.';
    }

    if (!is_int($rekeningId) || $rekeningId < 1) {
        $errors[] = 'Kode rekening wajib dipilih.';
    }

    if ($nomorSt === '' || mb_strlen($nomorSt) > 100) {
        $errors[] = 'Nomor surat tugas wajib diisi (maksimal 100 karakter).';
    }

    if ($tanggalSt === null) {
        $errors[] = 'Tanggal surat tugas tidak valid.';
    }

    if ($maksud === '' || mb_strlen($maksud) > 500) {
        $errors[] = 'Maksud perjalanan dinas wajib diisi (maksimal 500 karakter).';
    }

    if ($tujuan === '' || mb_strlen($tujuan) > 255) {
        $errors[] = 'Tempat tujuan wajib diisi (maksimal 255 karakter).';
    }

    if ($tanggalBerangkat === null || $tanggalKembali === null) {
        $errors[] = 'Tanggal berangkat dan tanggal kembali wajib diisi dengan benar.';
    } elseif ($tanggalKembali < $tanggalBerangkat) {
        $errors[] = 'Tanggal kembali tidak boleh sebelum tanggal berangkat.';
    }

    if (!is_int($lamaHari) || $lamaHari < 1 || $lamaHari > 365) {
        $errors[] = 'Jumlah hari harus berada antara 1 dan 365.';
    }

    if (mb_strlen($catatan) > 2000) {
        $errors[] = 'Catatan maksimal 2000 karakter.';
    }

    $namaArr = $_POST['peserta_nama'] ?? [];
    $namaArr = is_array($namaArr) ? array_values($namaArr) : [];
    $jumlahBaris = count($namaArr);

    if ($jumlahBaris > 100) {
        $errors[] = 'Maksimal 100 peserta dalam satu surat tugas.';
        $jumlahBaris = 100;
    }

    $ambilArray = static function (string $key): array {
        $value = $_POST[$key] ?? [];

        return is_array($value) ? array_values($value) : [];
    };

    $input = static function (array $arr, int $index): string {
        if (!isset($arr[$index]) || !is_scalar($arr[$index])) {
            return '';
        }

        return trim((string) $arr[$index]);
    };

    $arrNip = $ambilArray('peserta_nip');
    $arrPangkat = $ambilArray('peserta_pangkat');
    $arrGol = $ambilArray('peserta_golongan_ruang');
    $arrJabatan = $ambilArray('peserta_jabatan');
    $arrHotel = $ambilArray('peserta_nama_hotel');
    $arrCheckIn = $ambilArray('peserta_check_in');
    $arrCheckOut = $ambilArray('peserta_check_out');
    $arrBiaya = [];

    foreach ($biayaKeys as $key) {
        $arrBiaya[$key] = $ambilArray('peserta_' . $key);
    }

    $pesertaBersih = [];

    for ($i = 0; $i < $jumlahBaris; $i++) {
        $row = [
            'nama'           => $input($namaArr, $i),
            'nip'            => $input($arrNip, $i),
            'pangkat'        => $input($arrPangkat, $i),
            'golongan_ruang' => $input($arrGol, $i),
            'jabatan'        => $input($arrJabatan, $i),
            'nama_hotel'     => $input($arrHotel, $i),
            'check_in'       => $input($arrCheckIn, $i),
            'check_out'      => $input($arrCheckOut, $i),
        ];

        foreach ($biayaKeys as $key) {
            $row[$key] = $input($arrBiaya[$key], $i);
        }

        $postPeserta[] = $row;

        $adaIsi = false;

        foreach ($row as $field => $value) {
            if ($value !== '') {
                $adaIsi = true;
                break;
            }
        }

        if (!$adaIsi) {
            continue;
        }

        $baris = $i + 1;

        if ($row['nama'] === '' || mb_strlen($row['nama']) > 150) {
            $errors[] = 'Nama peserta baris ke-' . $baris . ' wajib diisi (maksimal 150 karakter).';
        }

        if (mb_strlen($row['nip']) > 30) {
            $errors[] = 'NIP peserta baris ke-' . $baris . ' maksimal 30 karakter.';
        }

        if (mb_strlen($row['pangkat']) > 100) {
            $errors[] = 'Pangkat peserta baris ke-' . $baris . ' maksimal 100 karakter.';
        }

        if (mb_strlen($row['golongan_ruang']) > 20) {
            $errors[] = 'Golongan ruang peserta baris ke-' . $baris . ' maksimal 20 karakter.';
        }

        if (mb_strlen($row['jabatan']) > 150) {
            $errors[] = 'Jabatan peserta baris ke-' . $baris . ' maksimal 150 karakter.';
        }

        if (mb_strlen($row['nama_hotel']) > 200) {
            $errors[] = 'Nama hotel peserta baris ke-' . $baris . ' maksimal 200 karakter.';
        }

        $checkIn = $row['check_in'] !== '' ? $parseTanggal($row['check_in']) : null;
        $checkOut = $row['check_out'] !== '' ? $parseTanggal($row['check_out']) : null;

        if ($row['check_in'] !== '' && $checkIn === null) {
            $errors[] = 'Tanggal check in peserta baris ke-' . $baris . ' tidak valid.';
        }

        if ($row['check_out'] !== '' && $checkOut === null) {
            $errors[] = 'Tanggal check out peserta baris ke-' . $baris . ' tidak valid.';
        }

        if ($checkIn !== null && $checkOut !== null && $checkOut < $checkIn) {
            $errors[] = 'Tanggal check out peserta baris ke-' . $baris
                . ' tidak boleh sebelum check in.';
        }

        $biaya = [];

        foreach ($biayaKeys as $key) {
            $nilai = $parseAngka($row[$key]);

            if ($nilai === null || $nilai < 0 || $nilai > 999_999_999_999_999.99) {
                $errors[] = 'Nilai biaya ' . str_replace('_', ' ', $key)
                    . ' peserta baris ke-' . $baris . ' tidak valid.';
                $nilai = 0.0;
            }

            $biaya[$key] = $nilai;
        }

        $pesertaBersih[] = [
            'nama'            => $row['nama'],
            'nip'             => $row['nip'] !== '' ? $row['nip'] : null,
            'pangkat'         => $row['pangkat'] !== '' ? $row['pangkat'] : null,
            'golongan_ruang'  => $row['golongan_ruang'] !== '' ? $row['golongan_ruang'] : null,
            'jabatan'         => $row['jabatan'] !== '' ? $row['jabatan'] : null,
            'nama_hotel'      => $row['nama_hotel'] !== '' ? $row['nama_hotel'] : null,
            'tanggal_check_in'  => $checkIn,
            'tanggal_check_out' => $checkOut,
            'biaya'           => $biaya,
        ];
    }

    if (empty($pesertaBersih)) {
        $errors[] = 'Minimal satu peserta perjalanan dinas harus diisi.';
    }

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            $paramsHeader = [
                ':sub_kegiatan_id'   => $subKegiatanId,
                ':rekening_id'       => $rekeningId,
                ':nomor_st'          => $nomorSt,
                ':tanggal_st'        => $tanggalSt,
                ':maksud'            => $maksud,
                ':tujuan'            => $tujuan,
                ':lama_hari'         => $lamaHari,
                ':tanggal_berangkat' => $tanggalBerangkat,
                ':tanggal_kembali'   => $tanggalKembali,
                ':catatan'           => $catatan !== '' ? $catatan : null,
            ];

            if ($edit === null) {
                $stmt = $pdo->prepare(
                    'INSERT INTO perjalanan_dinas (
                        sub_kegiatan_id, rekening_id, nomor_st, tanggal_st,
                        maksud, tujuan, lama_hari, tanggal_berangkat,
                        tanggal_kembali, catatan, dibuat_oleh
                    ) VALUES (
                        :sub_kegiatan_id, :rekening_id, :nomor_st, :tanggal_st,
                        :maksud, :tujuan, :lama_hari, :tanggal_berangkat,
                        :tanggal_kembali, :catatan, :dibuat_oleh
                    )'
                );
                $stmt->execute($paramsHeader + [
                    ':dibuat_oleh' => (int) (currentUser()['id'] ?? 0) ?: null,
                ]);
                $perjalananId = (int) $pdo->lastInsertId();
            } else {
                $paramsHeader[':id'] = (int) $edit['id'];
                $stmt = $pdo->prepare(
                    'UPDATE perjalanan_dinas SET
                        sub_kegiatan_id = :sub_kegiatan_id,
                        rekening_id = :rekening_id,
                        nomor_st = :nomor_st,
                        tanggal_st = :tanggal_st,
                        maksud = :maksud,
                        tujuan = :tujuan,
                        lama_hari = :lama_hari,
                        tanggal_berangkat = :tanggal_berangkat,
                        tanggal_kembali = :tanggal_kembali,
                        catatan = :catatan
                    WHERE id = :id'
                );
                $stmt->execute($paramsHeader);

                $perjalananId = (int) $edit['id'];

                $stmt = $pdo->prepare(
                    'DELETE FROM perjalanan_dinas_peserta WHERE perjalanan_id = :id'
                );
                $stmt->execute([':id' => $perjalananId]);
            }

            $stmt = $pdo->prepare(
                'INSERT INTO perjalanan_dinas_peserta (
                    perjalanan_id, nama, nip, pangkat, golongan_ruang, jabatan,
                    nama_hotel, tanggal_check_in, tanggal_check_out,
                    uang_harian, penginapan, representasi, transport_lokal,
                    taksi_sewa, bbm, biaya_lain
                ) VALUES (
                    :perjalanan_id, :nama, :nip, :pangkat, :golongan_ruang, :jabatan,
                    :nama_hotel, :check_in, :check_out,
                    :uang_harian, :penginapan, :representasi, :transport_lokal,
                    :taksi_sewa, :bbm, :biaya_lain
                )'
            );

            foreach ($pesertaBersih as $p) {
                $stmt->execute([
                    ':perjalanan_id'    => $perjalananId,
                    ':nama'             => $p['nama'],
                    ':nip'              => $p['nip'],
                    ':pangkat'          => $p['pangkat'],
                    ':golongan_ruang'   => $p['golongan_ruang'],
                    ':jabatan'          => $p['jabatan'],
                    ':nama_hotel'       => $p['nama_hotel'],
                    ':check_in'         => $p['tanggal_check_in'],
                    ':check_out'        => $p['tanggal_check_out'],
                    ':uang_harian'      => $p['biaya']['uang_harian'],
                    ':penginapan'       => $p['biaya']['penginapan'],
                    ':representasi'     => $p['biaya']['representasi'],
                    ':transport_lokal'  => $p['biaya']['transport_lokal'],
                    ':taksi_sewa'       => $p['biaya']['taksi_sewa'],
                    ':bbm'              => $p['biaya']['bbm'],
                    ':biaya_lain'       => $p['biaya']['biaya_lain'],
                ]);
            }

            $pdo->commit();

            setFlash(
                'success',
                $edit === null
                    ? 'Perjalanan dinas ' . $nomorSt . ' berhasil disimpan.'
                    : 'Perjalanan dinas ' . $nomorSt . ' berhasil diperbarui.'
            );

            redirect(url('pages/perjalanan_dinas.php'));
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log($e->getMessage());

            $errors[] = $e instanceof PDOException && $e->getCode() === '23000'
                ? 'Data belum dapat disimpan karena relasi atau nilai tidak valid.'
                : 'Data perjalanan dinas gagal disimpan. Periksa log PHP.';
        }
    }
}

/* ---------------------------------------------------------------------
 * Data pendukung dan daftar
 * ------------------------------------------------------------------- */

$subKegiatanList = $pdo->query(
    'SELECT
        sk.id,
        sk.kode_sub_kegiatan,
        sk.nama_sub_kegiatan,
        k.kode_kegiatan,
        k.nama_kegiatan,
        k.tahun_anggaran
    FROM sub_kegiatan AS sk
    INNER JOIN kegiatan AS k ON k.id = sk.kegiatan_id
    ORDER BY k.tahun_anggaran DESC, sk.nama_sub_kegiatan ASC'
)->fetchAll();

$rekeningList = $pdo->query(
    'SELECT id, kode_rekening, nama_rekening
    FROM master_rekening
    ORDER BY kode_rekening ASC'
)->fetchAll();

$tahunList = array_map(
    'intval',
    $pdo->query('SELECT DISTINCT tahun_anggaran FROM kegiatan ORDER BY tahun_anggaran DESC')
        ->fetchAll(PDO::FETCH_COLUMN)
);

$tahunFilter = filter_input(INPUT_GET, 'tahun', FILTER_VALIDATE_INT);
$tahunFilter = is_int($tahunFilter) && in_array($tahunFilter, $tahunList, true)
    ? $tahunFilter
    : 0;

$cari = trim((string) ($_GET['q'] ?? ''));

$sql = 'SELECT
        pd.id,
        pd.nomor_st,
        pd.tanggal_st,
        pd.maksud,
        pd.tujuan,
        pd.lama_hari,
        pd.tanggal_berangkat,
        pd.tanggal_kembali,
        pd.catatan,
        sk.kode_sub_kegiatan,
        sk.nama_sub_kegiatan,
        k.kode_kegiatan,
        k.nama_kegiatan,
        k.tahun_anggaran,
        mr.kode_rekening,
        mr.nama_rekening,
        COALESCE(vp.jumlah_peserta, 0) AS jumlah_peserta,
        COALESCE(vp.total_biaya, 0) AS total_biaya
    FROM perjalanan_dinas AS pd
    INNER JOIN sub_kegiatan AS sk ON sk.id = pd.sub_kegiatan_id
    INNER JOIN kegiatan AS k ON k.id = sk.kegiatan_id
    INNER JOIN master_rekening AS mr ON mr.id = pd.rekening_id
    LEFT JOIN v_perjalanan_ringkasan AS vp ON vp.perjalanan_id = pd.id';

$where = [];
$params = [];

if ($tahunFilter > 0) {
    $where[] = 'k.tahun_anggaran = :tahun';
    $params[':tahun'] = $tahunFilter;
}

if ($cari !== '') {
    $where[] = '(pd.nomor_st LIKE :cari1
        OR pd.maksud LIKE :cari2
        OR pd.tujuan LIKE :cari3
        OR EXISTS (
            SELECT 1
            FROM perjalanan_dinas_peserta AS px
            WHERE px.perjalanan_id = pd.id
              AND (px.nama LIKE :cari4 OR px.nip LIKE :cari5)
        ))';
    $params[':cari1'] = '%' . $cari . '%';
    $params[':cari2'] = '%' . $cari . '%';
    $params[':cari3'] = '%' . $cari . '%';
    $params[':cari4'] = '%' . $cari . '%';
    $params[':cari5'] = '%' . $cari . '%';
}

if (!empty($where)) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}

$sql .= ' ORDER BY pd.tanggal_berangkat DESC, pd.id DESC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$daftarPerjadin = $stmt->fetchAll();

$totalBiayaList = 0.0;
$totalPesertaList = 0;

foreach ($daftarPerjadin as $row) {
    $totalBiayaList += (float) $row['total_biaya'];
    $totalPesertaList += (int) $row['jumlah_peserta'];
}

/* ---------------------------------------------------------------------
 * Nilai formulir
 * ------------------------------------------------------------------- */

if (!empty($postPeserta)) {
    $pesertaForm = $postPeserta;
} elseif (!empty($pesertaEdit)) {
    $pesertaForm = [];

    foreach ($pesertaEdit as $p) {
        $pesertaForm[] = [
            'nama'           => (string) ($p['nama'] ?? ''),
            'nip'            => (string) ($p['nip'] ?? ''),
            'pangkat'        => (string) ($p['pangkat'] ?? ''),
            'golongan_ruang' => (string) ($p['golongan_ruang'] ?? ''),
            'jabatan'        => (string) ($p['jabatan'] ?? ''),
            'nama_hotel'     => (string) ($p['nama_hotel'] ?? ''),
            'check_in'       => (string) ($p['tanggal_check_in'] ?? ''),
            'check_out'      => (string) ($p['tanggal_check_out'] ?? ''),
            'uang_harian'    => (string) ($p['uang_harian'] ?? ''),
            'penginapan'     => (string) ($p['penginapan'] ?? ''),
            'representasi'   => (string) ($p['representasi'] ?? ''),
            'transport_lokal' => (string) ($p['transport_lokal'] ?? ''),
            'taksi_sewa'     => (string) ($p['taksi_sewa'] ?? ''),
            'bbm'            => (string) ($p['bbm'] ?? ''),
            'biaya_lain'     => (string) ($p['biaya_lain'] ?? ''),
        ];
    }
} else {
    $pesertaForm = [$pesertaKosong()];
}

$nilai = static function (string $key, string $bawaan = '') use ($edit): string {
    if (array_key_exists($key, $_POST)) {
        $value = $_POST[$key];

        return is_scalar($value) ? (string) $value : '';
    }

    return $edit !== null ? (string) ($edit[$key] ?? $bawaan) : $bawaan;
};

$pilih = static function (string $key, string $value) use ($edit): string {
    $current = array_key_exists($key, $_POST) ? $_POST[$key] : ($edit[$key] ?? '');

    return is_scalar($current) && (string) $current === $value ? 'selected' : '';
};

$masterLengkap = !empty($subKegiatanList) && !empty($rekeningList);

$renderPeserta = static function (array $p, int $index) use ($biayaKeys, $pangkatOptions, $golonganOptions): void {
    $total = 0.0;

    foreach ($biayaKeys as $key) {
        $total += (float) ($p[$key] ?? 0);
    }

    $nilaiPangkat = (string) ($p['pangkat'] ?? '');
    $opsiPangkat = $pangkatOptions;

    if ($nilaiPangkat !== '' && !in_array($nilaiPangkat, $opsiPangkat, true)) {
        $opsiPangkat[] = $nilaiPangkat;
    }

    $nilaiGolongan = (string) ($p['golongan_ruang'] ?? '');
    $opsiGolongan = $golonganOptions;

    if ($nilaiGolongan !== '' && !in_array($nilaiGolongan, $opsiGolongan, true)) {
        $opsiGolongan[] = $nilaiGolongan;
    }
    ?>
    <div class="peserta-item" data-peserta>
        <div class="peserta-head">
            <h4>Peserta <span data-peserta-nomor><?= $index + 1 ?></span></h4>
            <button type="button" class="btn btn-danger btn-sm" data-hapus-peserta>
                Hapus Peserta
            </button>
        </div>

        <div class="form-grid form-grid--3">
            <div class="form-group">
                <label>Nama *</label>
                <input
                    type="text"
                    name="peserta_nama[]"
                    maxlength="150"
                    value="<?= e($p['nama'] ?? '') ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label>NIP</label>
                <input type="text" name="peserta_nip[]" maxlength="30" value="<?= e($p['nip'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label>Pangkat</label>
                <select name="peserta_pangkat[]">
                    <option value="">-- Pilih Pangkat --</option>
                    <?php foreach ($opsiPangkat as $opsi): ?>
                        <option
                            value="<?= e($opsi) ?>"
                            <?= $nilaiPangkat === $opsi ? 'selected' : '' ?>
                        ><?= e($opsi) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Golongan Ruang</label>
                <select name="peserta_golongan_ruang[]">
                    <option value="">-- Pilih Golongan --</option>
                    <?php foreach ($opsiGolongan as $opsi): ?>
                        <option
                            value="<?= e($opsi) ?>"
                            <?= $nilaiGolongan === $opsi ? 'selected' : '' ?>
                        ><?= e($opsi) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Jabatan</label>
                <input
                    type="text"
                    name="peserta_jabatan[]"
                    maxlength="150"
                    value="<?= e($p['jabatan'] ?? '') ?>"
                >
            </div>

            <div class="form-group">
                <label>Nama Hotel / Penginapan</label>
                <input
                    type="text"
                    name="peserta_nama_hotel[]"
                    maxlength="200"
                    value="<?= e($p['nama_hotel'] ?? '') ?>"
                >
            </div>

            <div class="form-group">
                <label>Tanggal Check In</label>
                <input type="date" name="peserta_check_in[]" value="<?= e($p['check_in'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label>Tanggal Check Out</label>
                <input type="date" name="peserta_check_out[]" value="<?= e($p['check_out'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label>Uang Harian (Rp)</label>
                <input
                    type="number"
                    name="peserta_uang_harian[]"
                    min="0"
                    step="0.01"
                    value="<?= e($p['uang_harian'] ?? '') ?>"
                    data-biaya
                >
            </div>

            <div class="form-group">
                <label>Penginapan / Hotel (Rp)</label>
                <input
                    type="number"
                    name="peserta_penginapan[]"
                    min="0"
                    step="0.01"
                    value="<?= e($p['penginapan'] ?? '') ?>"
                    data-biaya
                >
            </div>

            <div class="form-group">
                <label>Representasi / Biaya Lain2 (Rp)</label>
                <input
                    type="number"
                    name="peserta_representasi[]"
                    min="0"
                    step="0.01"
                    value="<?= e($p['representasi'] ?? '') ?>"
                    data-biaya
                >
            </div>

            <div class="form-group">
                <label>Biaya Transport Lokal (Rp)</label>
                <input
                    type="number"
                    name="peserta_transport_lokal[]"
                    min="0"
                    step="0.01"
                    value="<?= e($p['transport_lokal'] ?? '') ?>"
                    data-biaya
                >
            </div>

            <div class="form-group">
                <label>Taksi / Sewa Mobil (Rp)</label>
                <input
                    type="number"
                    name="peserta_taksi_sewa[]"
                    min="0"
                    step="0.01"
                    value="<?= e($p['taksi_sewa'] ?? '') ?>"
                    data-biaya
                >
            </div>

            <div class="form-group">
                <label>Biaya BBM (Rp)</label>
                <input
                    type="number"
                    name="peserta_bbm[]"
                    min="0"
                    step="0.01"
                    value="<?= e($p['bbm'] ?? '') ?>"
                    data-biaya
                >
            </div>

            <div class="form-group">
                <label>Biaya Lain-lain (Rp)</label>
                <input
                    type="number"
                    name="peserta_biaya_lain[]"
                    min="0"
                    step="0.01"
                    value="<?= e($p['biaya_lain'] ?? '') ?>"
                    data-biaya
                >
            </div>
        </div>

        <p class="peserta-total">
            Total biaya peserta: <strong data-peserta-total><?= rupiah($total) ?></strong>
        </p>
    </div>
    <?php
};

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<main class="main-content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Perjalanan Dinas</h2>
            <p class="page-description">
                Catat surat tugas, peserta, dan rincian belanja perjalanan dinas,
                lalu cetak rekap sesuai form.
            </p>
        </div>

        <div class="page-actions">
            <a
                class="btn btn-light"
                href="<?= e(url('pages/perjalanan_dinas_cetak.php?tahun=' . $tahunFilter)) ?>"
            >Buka Rekap</a>

            <?php if (canManage() && $masterLengkap): ?>
                <a class="btn btn-success" href="#formPerjadin">Tambah Perjalanan Dinas</a>
            <?php endif; ?>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $msg): ?>
                <div><?= e($msg) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!canManage()): ?>
        <div class="alert alert-info">
            Peran Anda hanya dapat melihat data. Perubahan data dilakukan oleh
            Administrator atau Operator.
        </div>
    <?php endif; ?>

    <div class="kpi-grid kpi-grid--3">
        <article class="kpi">
            <span class="kpi-label">Surat Tugas</span>
            <span class="kpi-value"><?= count($daftarPerjadin) ?></span>
            <span class="kpi-sub">Pada filter yang dipilih</span>
        </article>

        <article class="kpi kpi--info">
            <span class="kpi-label">Peserta</span>
            <span class="kpi-value"><?= $totalPesertaList ?></span>
            <span class="kpi-sub">Total orang yang melakukan perjalanan</span>
        </article>

        <article class="kpi kpi--accent">
            <span class="kpi-label">Total Biaya</span>
            <span class="kpi-value" title="<?= e(rupiah($totalBiayaList)) ?>">
                <?= e(rupiahRingkas($totalBiayaList)) ?>
            </span>
            <span class="kpi-sub"><?= e(rupiah($totalBiayaList)) ?></span>
        </article>
    </div>

    <?php if (canManage()): ?>
        <section class="card" id="formPerjadin">
            <div class="card-header">
                <div>
                    <h3>
                        <?= $edit !== null
                            ? 'Formulir Ubah Perjalanan Dinas'
                            : 'Formulir Tambah Perjalanan Dinas' ?>
                    </h3>
                    <p class="card-subtitle">
                        Satu surat tugas dapat berisi beberapa peserta. Total biaya dihitung otomatis.
                    </p>
                </div>

                <?php if ($edit !== null): ?>
                    <a class="btn btn-light btn-sm" href="<?= e(url('pages/perjalanan_dinas.php')) ?>">
                        Batal Ubah
                    </a>
                <?php endif; ?>
            </div>

            <?php if (!$masterLengkap): ?>
                <div class="empty-state">
                    <strong>Data master belum lengkap.</strong>
                    Pastikan sudah ada sub kegiatan dan kode rekening sebelum mencatat perjalanan dinas.
                </div>
            <?php else: ?>
                <form
                    method="post"
                    action="<?= e(url('pages/perjalanan_dinas.php' . ($edit !== null ? '?edit=' . (int) $edit['id'] : ''))) ?>"
                    data-once
                >
                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                    <input type="hidden" name="aksi" value="simpan">

                    <div class="form-grid">
                        <div class="form-group full">
                            <label for="sub_kegiatan_id">Sub Kegiatan *</label>
                            <select id="sub_kegiatan_id" name="sub_kegiatan_id" required>
                                <option value="">-- Pilih Sub Kegiatan --</option>
                                <?php foreach ($subKegiatanList as $sk): ?>
                                    <option
                                        value="<?= (int) $sk['id'] ?>"
                                        title="<?= e($sk['kode_sub_kegiatan'] . ' - ' . $sk['nama_sub_kegiatan'] . ' | ' . $sk['nama_kegiatan'] . ' (' . $sk['tahun_anggaran'] . ')') ?>"
                                        <?= $pilih('sub_kegiatan_id', (string) $sk['id']) ?>
                                    >
                                        <?= e($sk['kode_sub_kegiatan']) ?>
                                        - <?= e(ringkasTeks($sk['nama_sub_kegiatan'], 60)) ?>
                                        | <?= e(ringkasTeks($sk['nama_kegiatan'], 30)) ?>
                                        (<?= e($sk['tahun_anggaran']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group full">
                            <label for="rekening_id">Kode Rekening *</label>
                            <select id="rekening_id" name="rekening_id" required>
                                <option value="">-- Pilih Rekening --</option>
                                <?php foreach ($rekeningList as $rek): ?>
                                    <option
                                        value="<?= (int) $rek['id'] ?>"
                                        <?= $pilih('rekening_id', (string) $rek['id']) ?>
                                    >
                                        <?= e($rek['kode_rekening']) ?> - <?= e($rek['nama_rekening']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="nomor_st">Nomor Surat Tugas *</label>
                            <input
                                type="text"
                                id="nomor_st"
                                name="nomor_st"
                                maxlength="100"
                                value="<?= e($nilai('nomor_st')) ?>"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="tanggal_st">Tanggal Surat Tugas *</label>
                            <input
                                type="date"
                                id="tanggal_st"
                                name="tanggal_st"
                                value="<?= e($nilai('tanggal_st')) ?>"
                                required
                            >
                        </div>

                        <div class="form-group full">
                            <label for="maksud">Maksud Perjalanan Dinas *</label>
                            <textarea
                                id="maksud"
                                name="maksud"
                                maxlength="500"
                                required
                            ><?= e($nilai('maksud')) ?></textarea>
                        </div>

                        <div class="form-group">
                            <label for="tujuan">Tempat Tujuan *</label>
                            <input
                                type="text"
                                id="tujuan"
                                name="tujuan"
                                maxlength="255"
                                value="<?= e($nilai('tujuan')) ?>"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="lama_hari">Jumlah Hari *</label>
                            <input
                                type="number"
                                id="lama_hari"
                                name="lama_hari"
                                min="1"
                                max="365"
                                step="1"
                                value="<?= e($nilai('lama_hari')) ?>"
                                required
                            >
                            <small>Terisi otomatis dari tanggal berangkat dan kembali.</small>
                        </div>

                        <div class="form-group">
                            <label for="tanggal_berangkat">Tanggal Berangkat *</label>
                            <input
                                type="date"
                                id="tanggal_berangkat"
                                name="tanggal_berangkat"
                                value="<?= e($nilai('tanggal_berangkat')) ?>"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="tanggal_kembali">Tanggal Kembali *</label>
                            <input
                                type="date"
                                id="tanggal_kembali"
                                name="tanggal_kembali"
                                value="<?= e($nilai('tanggal_kembali')) ?>"
                                required
                            >
                        </div>

                        <div class="form-group full">
                            <label for="catatan">Catatan</label>
                            <textarea id="catatan" name="catatan" maxlength="2000"><?= e($nilai('catatan')) ?></textarea>
                        </div>
                    </div>

                    <div class="peserta-section">
                        <div class="card-header">
                            <div>
                                <h3>Peserta dan Biaya</h3>
                                <p class="card-subtitle">
                                    Isi satu baris peserta untuk setiap orang. Biaya kosong dianggap nol.
                                </p>
                            </div>
                            <button type="button" class="btn btn-light btn-sm" data-tambah-peserta>
                                Tambah Peserta
                            </button>
                        </div>

                        <div id="pesertaList">
                            <?php foreach ($pesertaForm as $i => $p): ?>
                                <?php $renderPeserta($p, $i); ?>
                            <?php endforeach; ?>
                        </div>

                        <template id="pesertaTemplate">
                            <?php $renderPeserta($pesertaKosong(), 0); ?>
                        </template>
                    </div>

                    <p class="text-muted">* Wajib diisi.</p>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">
                            <?= $edit !== null ? 'Simpan Perubahan' : 'Simpan Perjalanan Dinas' ?>
                        </button>
                        <a class="btn btn-light" href="<?= e(url('pages/perjalanan_dinas.php')) ?>">Reset</a>
                    </div>
                </form>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <section class="card">
        <div class="card-header">
            <h3>Daftar Perjalanan Dinas</h3>
            <span class="text-muted"><?= count($daftarPerjadin) ?> surat tugas</span>
        </div>

        <form method="get" class="filter-bar" action="<?= e(url('pages/perjalanan_dinas.php')) ?>">
            <div class="form-group">
                <label for="filter_tahun">Tahun Anggaran</label>
                <select id="filter_tahun" name="tahun" data-auto-submit>
                    <option value="0">Semua tahun</option>
                    <?php foreach ($tahunList as $th): ?>
                        <option value="<?= $th ?>" <?= $tahunFilter === $th ? 'selected' : '' ?>>
                            <?= $th ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="q">Cari Surat Tugas / Peserta / Tujuan</label>
                <input type="text" id="q" name="q" value="<?= e($cari) ?>">
            </div>

            <button type="submit" class="btn btn-sm">Cari</button>
            <a class="btn btn-outline-dark btn-sm" href="<?= e(url('pages/perjalanan_dinas.php')) ?>">Reset</a>

            <a
                class="btn btn-outline btn-sm"
                href="<?= e(url('pages/perjalanan_dinas_export.php?tahun=' . $tahunFilter . '&q=' . urlencode($cari))) ?>"
            >Ekspor CSV</a>
        </form>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Surat Tugas</th>
                        <th>Kegiatan / Sub Kegiatan</th>
                        <th>Rekening</th>
                        <th>Maksud &amp; Tujuan</th>
                        <th>Tanggal Perjalanan</th>
                        <th class="num">Hari</th>
                        <th class="num">Peserta</th>
                        <th class="num">Total Biaya</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($daftarPerjadin)): ?>
                        <tr>
                            <td colspan="10" class="text-center">
                                Belum ada perjalanan dinas pada filter ini.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($daftarPerjadin as $i => $row): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td class="nowrap">
                                    <strong><?= e($row['nomor_st']) ?></strong><br>
                                    <span class="text-muted">
                                        <?= e(tanggalIndo($row['tanggal_st'])) ?>
                                        &middot; <?= e($row['tahun_anggaran']) ?>
                                    </span>
                                </td>
                                <td>
                                    <strong><?= e($row['kode_sub_kegiatan']) ?></strong><br>
                                    <span class="text-muted"><?= e($row['nama_sub_kegiatan']) ?></span>
                                </td>
                                <td>
                                    <?= e($row['kode_rekening']) ?><br>
                                    <span class="text-muted"><?= e($row['nama_rekening']) ?></span>
                                </td>
                                <td>
                                    <?= e($row['maksud']) ?><br>
                                    <span class="text-muted">Tujuan: <?= e($row['tujuan']) ?></span>
                                </td>
                                <td class="nowrap">
                                    <?= e(tanggalIndo($row['tanggal_berangkat'])) ?>
                                    <br>
                                    <span class="text-muted">
                                        s.d. <?= e(tanggalIndo($row['tanggal_kembali'])) ?>
                                    </span>
                                </td>
                                <td class="num"><?= (int) $row['lama_hari'] ?></td>
                                <td class="num"><?= (int) $row['jumlah_peserta'] ?></td>
                                <td class="num"><strong><?= rupiah($row['total_biaya']) ?></strong></td>
                                <td>
                                    <div class="actions">
                                        <a
                                            class="btn btn-light btn-sm"
                                            href="<?= e(url('pages/perjalanan_dinas_detail.php?id=' . (int) $row['id'])) ?>"
                                        >Detail</a>

                                        <a
                                            class="btn btn-light btn-sm"
                                            href="<?= e(url('pages/perjalanan_dinas_cetak.php?tahun=' . (int) $row['tahun_anggaran'] . '&id=' . (int) $row['id'])) ?>"
                                        >Cetak</a>

                                        <?php if (canManage()): ?>
                                            <a
                                                class="btn btn-light btn-sm"
                                                href="<?= e(url('pages/perjalanan_dinas.php?edit=' . (int) $row['id'])) ?>"
                                            >Ubah</a>

                                            <form
                                                method="post"
                                                data-confirm="Hapus perjalanan dinas <?= e($row['nomor_st']) ?> beserta seluruh pesertanya?"
                                            >
                                                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                                <input type="hidden" name="aksi" value="hapus">
                                                <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<script>
(function () {
    var list = document.getElementById('pesertaList');
    var template = document.getElementById('pesertaTemplate');
    var tambah = document.querySelector('[data-tambah-peserta]');

    if (!list || !template || !tambah) {
        return;
    }

    function rupiah(nominal) {
        return 'Rp ' + nominal.toLocaleString('id-ID', { maximumFractionDigits: 0 });
    }

    function hitung(item) {
        var total = 0;

        item.querySelectorAll('[data-biaya]').forEach(function (input) {
            var nilai = parseFloat(input.value);

            if (!isNaN(nilai)) {
                total += nilai;
            }
        });

        var output = item.querySelector('[data-peserta-total]');

        if (output) {
            output.textContent = rupiah(total);
        }
    }

    function renumber() {
        var items = list.querySelectorAll('[data-peserta]');

        items.forEach(function (item, index) {
            var nomor = item.querySelector('[data-peserta-nomor]');
            var hapus = item.querySelector('[data-hapus-peserta]');

            if (nomor) {
                nomor.textContent = String(index + 1);
            }

            if (hapus) {
                hapus.disabled = items.length <= 1;
            }
        });
    }

    function pasang(item) {
        item.querySelectorAll('[data-biaya]').forEach(function (input) {
            input.addEventListener('input', function () {
                hitung(item);
            });
        });

        var hapus = item.querySelector('[data-hapus-peserta]');

        if (hapus) {
            hapus.addEventListener('click', function () {
                if (list.querySelectorAll('[data-peserta]').length <= 1) {
                    return;
                }

                item.remove();
                renumber();
            });
        }

        hitung(item);
    }

    tambah.addEventListener('click', function () {
        var item = template.content.querySelector('[data-peserta]').cloneNode(true);

        list.appendChild(item);
        pasang(item);
        renumber();

        var pertama = item.querySelector('input');

        if (pertama) {
            pertama.focus();
        }
    });

    list.querySelectorAll('[data-peserta]').forEach(pasang);
    renumber();

    var berangkat = document.getElementById('tanggal_berangkat');
    var kembali = document.getElementById('tanggal_kembali');
    var lama = document.getElementById('lama_hari');
    var manual = false;

    if (lama) {
        lama.addEventListener('input', function () {
            manual = true;
        });
    }

    function isiHari() {
        if (!berangkat || !kembali || !lama || manual) {
            return;
        }

        if (!berangkat.value || !kembali.value) {
            return;
        }

        var awal = new Date(berangkat.value + 'T00:00:00');
        var akhir = new Date(kembali.value + 'T00:00:00');

        if (isNaN(awal.getTime()) || isNaN(akhir.getTime()) || akhir < awal) {
            return;
        }

        lama.value = Math.round((akhir - awal) / 86400000) + 1;
    }

    if (berangkat && kembali) {
        berangkat.addEventListener('change', isiHari);
        kembali.addEventListener('change', isiHari);

        if (!lama.value) {
            isiHari();
        }
    }
})();
</script>

<?php require __DIR__ . '/../includes/footer.php'; ?>
