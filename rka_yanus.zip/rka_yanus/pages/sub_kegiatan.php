<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

requireLogin();

$pageTitle = 'Data Sub Kegiatan';
$currentPage = 'sub_kegiatan';

$errors = [];
$edit = null;

$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);
$filterKegiatanId = filter_input(INPUT_GET, 'kegiatan', FILTER_VALIDATE_INT);
$filterKegiatanId = is_int($filterKegiatanId) && $filterKegiatanId > 0 ? $filterKegiatanId : 0;

if (is_int($editId) && $editId > 0) {
    $stmt = $pdo->prepare(
        'SELECT id, kegiatan_id, kode_sub_kegiatan, nama_sub_kegiatan, keterangan
        FROM sub_kegiatan
        WHERE id = :id'
    );
    $stmt->execute([':id' => $editId]);
    $edit = $stmt->fetch() ?: null;

    if ($edit === null) {
        setFlash('warning', 'Sub kegiatan yang ingin diubah tidak ditemukan.');
        redirect(url('pages/sub_kegiatan.php'));
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf($_POST['csrf_token'] ?? null);
    requireManage();

    $aksi = (string) ($_POST['aksi'] ?? 'simpan');

    if ($aksi === 'hapus') {
        $hapusId = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);

        if (!is_int($hapusId) || $hapusId < 1) {
            setFlash('danger', 'Data sub kegiatan tidak valid.');
        } else {
            $stmt = $pdo->prepare('SELECT nama_sub_kegiatan FROM sub_kegiatan WHERE id = :id');
            $stmt->execute([':id' => $hapusId]);
            $nama = $stmt->fetchColumn();

            $stmt = $pdo->prepare(
                'SELECT COUNT(*) FROM rincian_anggaran WHERE sub_kegiatan_id = :id'
            );
            $stmt->execute([':id' => $hapusId]);
            $jumlahRincian = (int) $stmt->fetchColumn();

            if ($nama === false) {
                setFlash('warning', 'Sub kegiatan tidak ditemukan.');
            } elseif ($jumlahRincian > 0) {
                setFlash(
                    'danger',
                    'Sub kegiatan tidak dapat dihapus karena masih memiliki '
                    . $jumlahRincian . ' rincian anggaran.'
                );
            } else {
                $stmt = $pdo->prepare('DELETE FROM sub_kegiatan WHERE id = :id');
                $stmt->execute([':id' => $hapusId]);
                setFlash('success', 'Sub kegiatan "' . $nama . '" berhasil dihapus.');
            }
        }

        redirect(url('pages/sub_kegiatan.php'));
    }

    $kegiatanId = filter_var($_POST['kegiatan_id'] ?? null, FILTER_VALIDATE_INT);
    $kode = trim((string) ($_POST['kode_sub_kegiatan'] ?? ''));
    $nama = trim((string) ($_POST['nama_sub_kegiatan'] ?? ''));
    $keterangan = trim((string) ($_POST['keterangan'] ?? ''));

    if (!is_int($kegiatanId) || $kegiatanId < 1) {
        $errors[] = 'Silahkan pilih kegiatan induk yang valid.';
    } else {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM kegiatan WHERE id = :id');
        $stmt->execute([':id' => $kegiatanId]);

        if ((int) $stmt->fetchColumn() === 0) {
            $errors[] = 'Kegiatan induk tidak ditemukan.';
        }
    }

    if ($kode === '' || mb_strlen($kode) > 60) {
        $errors[] = 'Kode sub kegiatan wajib diisi (maksimal 60 karakter).';
    }

    if ($nama === '' || mb_strlen($nama) > 255) {
        $errors[] = 'Nama sub kegiatan wajib diisi (maksimal 255 karakter).';
    }

    if (empty($errors)) {
        try {
            $cek = $pdo->prepare(
                'SELECT COUNT(*) FROM sub_kegiatan
                WHERE kegiatan_id = :kegiatan
                  AND kode_sub_kegiatan = :kode
                  AND id <> :id'
            );
            $cek->execute([
                ':kegiatan' => $kegiatanId,
                ':kode'     => $kode,
                ':id'       => $edit !== null ? (int) $edit['id'] : 0,
            ]);

            if ((int) $cek->fetchColumn() > 0) {
                $errors[] = 'Kode sub kegiatan sudah digunakan pada kegiatan induk tersebut.';
            } else {
                if ($edit === null) {
                    $stmt = $pdo->prepare(
                        'INSERT INTO sub_kegiatan
                        (kegiatan_id, kode_sub_kegiatan, nama_sub_kegiatan, keterangan)
                        VALUES (:kegiatan, :kode, :nama, :keterangan)'
                    );
                    $stmt->execute([
                        ':kegiatan'   => $kegiatanId,
                        ':kode'       => $kode,
                        ':nama'       => $nama,
                        ':keterangan' => $keterangan !== '' ? $keterangan : null,
                    ]);

                    setFlash('success', 'Sub kegiatan berhasil disimpan.');
                } else {
                    $stmt = $pdo->prepare(
                        'UPDATE sub_kegiatan
                        SET kegiatan_id = :kegiatan,
                            kode_sub_kegiatan = :kode,
                            nama_sub_kegiatan = :nama,
                            keterangan = :keterangan
                        WHERE id = :id'
                    );
                    $stmt->execute([
                        ':kegiatan'   => $kegiatanId,
                        ':kode'       => $kode,
                        ':nama'       => $nama,
                        ':keterangan' => $keterangan !== '' ? $keterangan : null,
                        ':id'         => (int) $edit['id'],
                    ]);

                    setFlash('success', 'Sub kegiatan berhasil diperbarui.');
                }

                redirect(url('pages/sub_kegiatan.php'));
            }
        } catch (PDOException $e) {
            error_log($e->getMessage());

            $errors[] = $e->getCode() === '23000'
                ? 'Data melanggar aturan database. Periksa kode sub kegiatan atau kegiatan induk.'
                : 'Sub kegiatan gagal disimpan. Periksa log PHP.';
        }
    }
}

$kegiatanList = $pdo->query(
    'SELECT id, kode_kegiatan, nama_kegiatan, tahun_anggaran
    FROM kegiatan
    ORDER BY tahun_anggaran DESC, nama_kegiatan ASC'
)->fetchAll();

$sql = 'SELECT
        sk.id,
        sk.kegiatan_id,
        sk.kode_sub_kegiatan,
        sk.nama_sub_kegiatan,
        sk.keterangan,
        k.kode_kegiatan,
        k.nama_kegiatan,
        k.tahun_anggaran,
        (SELECT COUNT(*) FROM rincian_anggaran ra WHERE ra.sub_kegiatan_id = sk.id) AS jml_rincian
    FROM sub_kegiatan AS sk
    INNER JOIN kegiatan AS k ON k.id = sk.kegiatan_id';

$params = [];

if ($filterKegiatanId > 0) {
    $sql .= ' WHERE sk.kegiatan_id = :kegiatan';
    $params[':kegiatan'] = $filterKegiatanId;
}

$sql .= ' ORDER BY k.tahun_anggaran DESC, sk.nama_sub_kegiatan ASC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$dataSubkegiatan = $stmt->fetchAll();

$nilai = static function (string $key, string $bawaan = '') use ($edit, $filterKegiatanId): string {
    if (array_key_exists($key, $_POST)) {
        return (string) $_POST[$key];
    }

    if ($edit !== null) {
        return (string) ($edit[$key] ?? $bawaan);
    }

    if ($key === 'kegiatan_id' && $filterKegiatanId > 0) {
        return (string) $filterKegiatanId;
    }

    return $bawaan;
};

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<main class="main-content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Data Sub Kegiatan</h2>
            <p class="page-description">
                Kelola sub kegiatan berdasarkan kegiatan induk.
            </p>
        </div>
        <?php if ($edit !== null): ?>
            <div class="page-actions">
                <a class="btn btn-light" href="<?= e(url('pages/sub_kegiatan.php')) ?>">Batal Ubah</a>
            </div>
        <?php endif; ?>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $msg): ?>
                <div><?= e($msg) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!canManage()): ?>
        <div class="alert alert-info">
            Peran Anda hanya dapat melihat data. Perubahan data dilakukan oleh
            Administrator atau Operator.
        </div>
    <?php endif; ?>

    <?php if (canManage()): ?>
        <section class="card">
            <div class="card-header">
                <div>
                    <h3><?= $edit !== null ? 'Formulir Ubah Sub Kegiatan' : 'Formulir Tambah Sub Kegiatan' ?></h3>
                    <p class="card-subtitle">Sub kegiatan mengikuti kegiatan induk yang dipilih.</p>
                </div>
            </div>

            <?php if (empty($kegiatanList)): ?>
                <div class="empty-state">
                    <strong>Belum ada kegiatan induk.</strong>
                    Tambahkan kegiatan melalui menu Kegiatan terlebih dahulu.
                </div>
            <?php else: ?>
                <form method="post" data-once>
                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                    <input type="hidden" name="aksi" value="simpan">

                    <div class="form-grid">
                        <div class="form-group full">
                            <label for="kegiatan_id">Kegiatan Induk *</label>
                            <select id="kegiatan_id" name="kegiatan_id" required>
                                <option value="">-- Pilih Kegiatan --</option>
                                <?php foreach ($kegiatanList as $kegiatan): ?>
                                    <option
                                        value="<?= (int) $kegiatan['id'] ?>"
                                        title="<?= e($kegiatan['kode_kegiatan'] . ' - ' . $kegiatan['nama_kegiatan'] . ' (' . $kegiatan['tahun_anggaran'] . ')') ?>"
                                        <?= $nilai('kegiatan_id') === (string) $kegiatan['id'] ? 'selected' : '' ?>
                                    >
                                        <?= e($kegiatan['kode_kegiatan']) ?>
                                        - <?= e(ringkasTeks($kegiatan['nama_kegiatan'], 50)) ?>
                                        (<?= e($kegiatan['tahun_anggaran']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="kode_sub_kegiatan">Kode Sub Kegiatan *</label>
                            <input
                                type="text"
                                id="kode_sub_kegiatan"
                                name="kode_sub_kegiatan"
                                maxlength="60"
                                value="<?= e($nilai('kode_sub_kegiatan')) ?>"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="nama_sub_kegiatan">Nama Sub Kegiatan *</label>
                            <input
                                type="text"
                                id="nama_sub_kegiatan"
                                name="nama_sub_kegiatan"
                                maxlength="255"
                                value="<?= e($nilai('nama_sub_kegiatan')) ?>"
                                required
                            >
                        </div>

                        <div class="form-group full">
                            <label for="keterangan">Keterangan</label>
                            <textarea id="keterangan" name="keterangan" rows="3"><?= e($nilai('keterangan')) ?></textarea>
                        </div>
                    </div>

                    <p class="text-muted">* Wajib diisi.</p>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">
                            <?= $edit !== null ? 'Simpan Perubahan' : 'Simpan Sub Kegiatan' ?>
                        </button>
                        <a class="btn btn-light" href="<?= e(url('pages/sub_kegiatan.php')) ?>">Reset</a>
                    </div>
                </form>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <section class="card">
        <div class="card-header">
            <h3>Daftar Sub Kegiatan</h3>
            <span class="text-muted"><?= count($dataSubkegiatan) ?> data</span>
        </div>

        <form method="get" class="filter-bar" action="<?= e(url('pages/sub_kegiatan.php')) ?>">
            <div class="form-group">
                <label for="filter_kegiatan">Filter Kegiatan</label>
                <select id="filter_kegiatan" name="kegiatan" data-auto-submit>
                    <option value="0">Semua kegiatan</option>
                    <?php foreach ($kegiatanList as $kegiatan): ?>
                        <option
                            value="<?= (int) $kegiatan['id'] ?>"
                            title="<?= e($kegiatan['kode_kegiatan'] . ' - ' . $kegiatan['nama_kegiatan'] . ' (' . $kegiatan['tahun_anggaran'] . ')') ?>"
                            <?= $filterKegiatanId === (int) $kegiatan['id'] ? 'selected' : '' ?>
                        >
                            <?= e($kegiatan['kode_kegiatan']) ?> - <?= e(ringkasTeks($kegiatan['nama_kegiatan'], 50)) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <a class="btn btn-outline-dark btn-sm" href="<?= e(url('pages/sub_kegiatan.php')) ?>">Reset</a>
        </form>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Kegiatan</th>
                        <th>Kode Sub Kegiatan</th>
                        <th>Nama Sub Kegiatan</th>
                        <th>Tahun</th>
                        <th class="num">Rincian</th>
                        <th>Keterangan</th>
                        <?php if (canManage()): ?>
                            <th>Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($dataSubkegiatan)): ?>
                        <tr>
                            <td colspan="<?= canManage() ? 8 : 7 ?>" class="text-center">
                                Belum ada data sub kegiatan.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($dataSubkegiatan as $i => $row): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td>
                                    <strong><?= e($row['kode_kegiatan']) ?></strong><br>
                                    <span class="text-muted"><?= e($row['nama_kegiatan']) ?></span>
                                </td>
                                <td class="nowrap"><?= e($row['kode_sub_kegiatan']) ?></td>
                                <td><?= e($row['nama_sub_kegiatan']) ?></td>
                                <td><?= e($row['tahun_anggaran']) ?></td>
                                <td class="num"><?= (int) $row['jml_rincian'] ?></td>
                                <td><?= e($row['keterangan']) ?></td>
                                <?php if (canManage()): ?>
                                    <td>
                                        <div class="actions">
                                            <a
                                                class="btn btn-light btn-sm"
                                                href="<?= e(url('pages/sub_kegiatan.php?edit=' . (int) $row['id'])) ?>"
                                            >Ubah</a>

                                            <form
                                                method="post"
                                                data-confirm="Hapus sub kegiatan &quot;<?= e($row['nama_sub_kegiatan']) ?>&quot;?"
                                            >
                                                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                                <input type="hidden" name="aksi" value="hapus">
                                                <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                            </form>
                                        </div>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
