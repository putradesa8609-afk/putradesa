<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/rekap_belanja_data.php';

requireLogin();

$pageTitle = 'Rekap Belanja';
$currentPage = 'rekap_belanja';

$tahunList = array_map(
    'intval',
    $pdo->query('SELECT DISTINCT tahun_anggaran FROM kegiatan ORDER BY tahun_anggaran DESC')
        ->fetchAll(PDO::FETCH_COLUMN)
);

$tahunFilter = filter_input(INPUT_GET, 'tahun', FILTER_VALIDATE_INT);
$tahunFilter = is_int($tahunFilter) && in_array($tahunFilter, $tahunList, true)
    ? $tahunFilter
    : 0;

$kategoriOptions = kategoriBelanjaOptions();
$kategoriInput = (string) ($_GET['kategori'] ?? '');
$kategoriFilter = '';

if ($kategoriInput === 'NONE' || array_key_exists($kategoriInput, $kategoriOptions)) {
    $kategoriFilter = $kategoriInput;
}

$rekap = ambilRekapBelanja($pdo, $tahunFilter, $kategoriFilter);
$dataBelanja = $rekap['rows'];
$ringkasanKategori = $rekap['ringkasan'];
$totalItem = $rekap['total_item'];
$totalPagu = $rekap['total_pagu'];
$totalRealisasi = $rekap['total_realisasi'];
$totalDibayar = $rekap['total_dibayar'];
$totalSisa = $rekap['total_sisa'];

$ringkasanTampil = array_filter(
    $ringkasanKategori,
    static fn (array $baris): bool => $baris['jumlah'] > 0
);

$persenSerapan = $totalPagu > 0 ? $totalRealisasi / $totalPagu * 100 : 0.0;

$parameterExport = [];

if ($tahunFilter > 0) {
    $parameterExport['tahun'] = $tahunFilter;
}

if ($kategoriFilter !== '') {
    $parameterExport['kategori'] = $kategoriFilter;
}

$queryExport = http_build_query($parameterExport);
$tautanExport = url('pages/rekap_belanja_export.php')
    . ($queryExport !== '' ? '?' . $queryExport : '');

$labelFilterTahun = $tahunFilter > 0 ? (string) $tahunFilter : 'Semua Tahun';
$labelFilterKategori = $kategoriFilter === ''
    ? 'Semua Kategori'
    : ($kategoriFilter === 'NONE' ? 'Belum Ditentukan' : $kategoriOptions[$kategoriFilter]);

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<main class="main-content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Rekap Belanja</h2>
            <p class="page-description">
                Rekapitulasi seluruh transaksi belanja berdasarkan kategori, lengkap dengan
                realisasi, pembayaran, dan sisa pagu.
            </p>
        </div>
        <div class="page-actions">
            <a class="btn btn-success" href="<?= e($tautanExport) ?>">Unduh Excel</a>
        </div>
    </div>

    <div class="kpi-grid">
        <div class="kpi">
            <span class="kpi-label">Jumlah Transaksi</span>
            <span class="kpi-value"><?= number_format($totalItem, 0, ',', '.') ?></span>
            <span class="kpi-sub"><?= e($labelFilterKategori) ?></span>
        </div>

        <div class="kpi kpi--accent">
            <span class="kpi-label">Total Pagu</span>
            <span class="kpi-value" title="<?= e(rupiah($totalPagu)) ?>">
                <?= e(rupiahRingkas($totalPagu)) ?>
            </span>
            <span class="kpi-sub">Tahun <?= e($labelFilterTahun) ?></span>
        </div>

        <div class="kpi kpi--info">
            <span class="kpi-label">Total Realisasi</span>
            <span class="kpi-value" title="<?= e(rupiah($totalRealisasi)) ?>">
                <?= e(rupiahRingkas($totalRealisasi)) ?>
            </span>
            <span class="kpi-sub">
                Serapan <strong><?= e(persen($persenSerapan)) ?></strong>
            </span>
        </div>

        <div class="kpi <?= $totalSisa < 0 ? 'kpi--danger' : 'kpi--warning' ?>">
            <span class="kpi-label">Sisa Pagu</span>
            <span class="kpi-value" title="<?= e(rupiah($totalSisa)) ?>">
                <?= e(rupiahRingkas($totalSisa)) ?>
            </span>
            <span class="kpi-sub">
                Dibayar <strong><?= e(rupiahRingkas($totalDibayar)) ?></strong>
            </span>
        </div>
    </div>

    <section class="card">
        <div class="card-header">
            <div>
                <h3>Ringkasan per Kategori Belanja</h3>
                <p class="card-subtitle">
                    Tahun <?= e($labelFilterTahun) ?> &middot; <?= e($labelFilterKategori) ?>
                </p>
            </div>
            <span class="text-muted"><?= count($ringkasanTampil) ?> kategori</span>
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Kategori Belanja</th>
                        <th class="num">Jumlah Item</th>
                        <th class="num">Total Pagu</th>
                        <th class="num">Realisasi</th>
                        <th class="num">Dibayar</th>
                        <th class="num">Sisa Pagu</th>
                        <th class="num">Serapan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($ringkasanTampil)): ?>
                        <tr>
                            <td colspan="7" class="text-center">Belum ada transaksi belanja.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($ringkasanTampil as $ringkasan): ?>
                            <?php
                            $serapan = $ringkasan['pagu'] > 0
                                ? $ringkasan['realisasi'] / $ringkasan['pagu'] * 100
                                : 0.0;
                            ?>
                            <tr>
                                <td><strong><?= e($ringkasan['label']) ?></strong></td>
                                <td class="num"><?= number_format($ringkasan['jumlah'], 0, ',', '.') ?></td>
                                <td class="num"><?= rupiah($ringkasan['pagu']) ?></td>
                                <td class="num"><?= rupiah($ringkasan['realisasi']) ?></td>
                                <td class="num"><?= rupiah($ringkasan['dibayar']) ?></td>
                                <td class="num <?= $ringkasan['sisa'] < 0 ? 'text-danger' : '' ?>">
                                    <?= rupiah($ringkasan['sisa']) ?>
                                </td>
                                <td class="num"><?= e(persen($serapan)) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
                <?php if (!empty($ringkasanTampil)): ?>
                    <tfoot>
                        <tr>
                            <th>Total</th>
                            <th class="num"><?= number_format($totalItem, 0, ',', '.') ?></th>
                            <th class="num"><?= rupiah($totalPagu) ?></th>
                            <th class="num"><?= rupiah($totalRealisasi) ?></th>
                            <th class="num"><?= rupiah($totalDibayar) ?></th>
                            <th class="num <?= $totalSisa < 0 ? 'text-danger' : '' ?>">
                                <?= rupiah($totalSisa) ?>
                            </th>
                            <th class="num"><?= e(persen($persenSerapan)) ?></th>
                        </tr>
                    </tfoot>
                <?php endif; ?>
            </table>
        </div>
    </section>

    <section class="card">
        <div class="card-header">
            <h3>Seluruh Transaksi</h3>
            <span class="text-muted"><?= count($dataBelanja) ?> data</span>
        </div>

        <form method="get" class="filter-bar" action="<?= e(url('pages/rekap_belanja.php')) ?>">
            <div class="form-group">
                <label for="filter_tahun">Tahun Anggaran</label>
                <select id="filter_tahun" name="tahun" data-auto-submit>
                    <option value="0">Semua tahun</option>
                    <?php foreach ($tahunList as $th): ?>
                        <option value="<?= $th ?>" <?= $tahunFilter === $th ? 'selected' : '' ?>>
                            <?= $th ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="filter_kategori">Kategori Belanja</label>
                <select id="filter_kategori" name="kategori" data-auto-submit>
                    <option value="">Semua kategori</option>
                    <?php foreach ($kategoriOptions as $kode => $label): ?>
                        <option value="<?= e($kode) ?>" <?= $kategoriFilter === $kode ? 'selected' : '' ?>>
                            <?= e($label) ?>
                        </option>
                    <?php endforeach; ?>
                    <option value="NONE" <?= $kategoriFilter === 'NONE' ? 'selected' : '' ?>>
                        Belum Ditentukan
                    </option>
                </select>
            </div>

            <button type="submit" class="btn btn-sm">Terapkan</button>
            <a class="btn btn-outline-dark btn-sm" href="<?= e(url('pages/rekap_belanja.php')) ?>">Reset</a>
            <a class="btn btn-success btn-sm" href="<?= e($tautanExport) ?>">Unduh Excel</a>
        </form>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Tahun</th>
                        <th>Kategori</th>
                        <th>Kode RUP</th>
                        <th>Uraian Belanja</th>
                        <th>Sub Kegiatan</th>
                        <th>Rekening</th>
                        <th class="num">Volume</th>
                        <th class="num">Harga</th>
                        <th class="num">PPN</th>
                        <th class="num">Total Pagu</th>
                        <th class="num">Realisasi</th>
                        <th class="num">Dibayar</th>
                        <th class="num">Sisa</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($dataBelanja)): ?>
                        <tr>
                            <td colspan="15" class="text-center">Belum ada transaksi belanja.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($dataBelanja as $i => $row): ?>
                            <?php
                            $kodeKategori = $row['kategori_belanja'] ?? '';
                            $labelKategori = kategoriBelanjaLabel($kodeKategori);
                            $sisa = (float) $row['sisa_pagu'];
                            ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td><?= e($row['tahun_anggaran']) ?></td>
                                <td class="nowrap">
                                    <?php if ($kodeKategori === ''): ?>
                                        <span class="text-muted">Belum ditentukan</span>
                                    <?php else: ?>
                                        <?= e($labelKategori) ?>
                                    <?php endif; ?>
                                </td>
                                <td class="nowrap"><?= e($row['kode_rup']) ?></td>
                                <td><?= e($row['uraian']) ?></td>
                                <td>
                                    <strong><?= e($row['kode_sub_kegiatan']) ?></strong><br>
                                    <span class="text-muted"><?= e($row['nama_sub_kegiatan']) ?></span>
                                </td>
                                <td>
                                    <?= e($row['kode_rekening']) ?><br>
                                    <span class="text-muted"><?= e($row['nama_rekening']) ?></span>
                                </td>
                                <td class="num">
                                    <?= e(rtrim(rtrim(number_format((float) $row['volume'], 4, ',', '.'), '0'), ',')) ?>
                                    <?= e($row['nama_satuan']) ?>
                                </td>
                                <td class="num"><?= rupiah($row['harga_satuan']) ?></td>
                                <td class="num">
                                    <?php if ((int) ($row['nilai_ppn'] ?? 0) > 0): ?>
                                        <?= rupiah($row['nilai_ppn']) ?>
                                    <?php else: ?>
                                        <span class="text-muted">Tidak</span>
                                    <?php endif; ?>
                                </td>
                                <td class="num"><strong><?= rupiah($row['total_pagu']) ?></strong></td>
                                <td class="num"><?= rupiah($row['total_realisasi']) ?></td>
                                <td class="num"><?= rupiah($row['total_dibayar']) ?></td>
                                <td class="num <?= $sisa < 0 ? 'text-danger' : '' ?>">
                                    <?= rupiah($sisa) ?>
                                </td>
                                <td><?= statusBadge($row['status']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
