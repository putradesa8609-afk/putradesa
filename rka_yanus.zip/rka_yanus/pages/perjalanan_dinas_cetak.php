<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

requireLogin();

$currentPage = 'perjalanan_dinas';

$tahunList = array_map(
    'intval',
    $pdo->query('SELECT DISTINCT tahun_anggaran FROM kegiatan ORDER BY tahun_anggaran DESC')
        ->fetchAll(PDO::FETCH_COLUMN)
);

$tahun = filter_input(INPUT_GET, 'tahun', FILTER_VALIDATE_INT);
$tahun = is_int($tahun) && in_array($tahun, $tahunList, true) ? $tahun : 0;

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$id = is_int($id) && $id > 0 ? $id : 0;

$sql = 'SELECT
        pd.id,
        pd.nomor_st,
        pd.tanggal_st,
        pd.maksud,
        pd.tujuan,
        pd.lama_hari,
        pd.tanggal_berangkat,
        pd.tanggal_kembali,
        sk.kode_sub_kegiatan,
        sk.nama_sub_kegiatan,
        k.kode_kegiatan,
        k.nama_kegiatan,
        k.tahun_anggaran,
        mr.kode_rekening,
        mr.nama_rekening,
        COALESCE(vp.total_biaya, 0) AS total_biaya
    FROM perjalanan_dinas AS pd
    INNER JOIN sub_kegiatan AS sk ON sk.id = pd.sub_kegiatan_id
    INNER JOIN kegiatan AS k ON k.id = sk.kegiatan_id
    INNER JOIN master_rekening AS mr ON mr.id = pd.rekening_id
    LEFT JOIN v_perjalanan_ringkasan AS vp ON vp.perjalanan_id = pd.id';

$where = [];
$params = [];

if ($id > 0) {
    $where[] = 'pd.id = :id';
    $params[':id'] = $id;
} elseif ($tahun > 0) {
    $where[] = 'k.tahun_anggaran = :tahun';
    $params[':tahun'] = $tahun;
}

if (!empty($where)) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}

$sql .= ' ORDER BY pd.tanggal_berangkat ASC, pd.id ASC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$daftar = $stmt->fetchAll();

if ($id > 0 && empty($daftar)) {
    setFlash('warning', 'Perjalanan dinas yang ingin dicetak tidak ditemukan.');
    redirect(url('pages/perjalanan_dinas.php'));
}

$pesertaGrup = [];

if (!empty($daftar)) {
    $ids = array_map('intval', array_column($daftar, 'id'));
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare(
        'SELECT *
        FROM perjalanan_dinas_peserta
        WHERE perjalanan_id IN (' . $placeholders . ')
        ORDER BY perjalanan_id ASC, id ASC'
    );
    $stmt->execute($ids);

    foreach ($stmt->fetchAll() as $p) {
        $pesertaGrup[(int) $p['perjalanan_id']][] = $p;
    }
}

$tahunCetak = $tahun;

if ($id > 0 && !empty($daftar)) {
    $tahunCetak = (int) $daftar[0]['tahun_anggaran'];
}

$judulTahun = $tahunCetak > 0 ? (string) $tahunCetak : 'SEMUA TAHUN';

$pageTitle = 'Rekap Perjalanan Dinas ' . $judulTahun;

$totalKeseluruhan = 0.0;
$totalPeserta = 0;

foreach ($daftar as $row) {
    $totalKeseluruhan += (float) $row['total_biaya'];
    $totalPeserta += count($pesertaGrup[(int) $row['id']] ?? []);
}

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<main class="main-content">
    <div class="page-header no-print">
        <div>
            <h2 class="page-title">Rekap Perjalanan Dinas</h2>
            <p class="page-description">
                Tampilan mengikuti Form Rekap Perjalanan Dinas.
                Gunakan Cetak / Simpan PDF untuk hasil landscape.
            </p>
        </div>

        <div class="page-actions">
            <a class="btn btn-light" href="<?= e(url('pages/perjalanan_dinas.php?tahun=' . $tahunCetak)) ?>">
                Kembali
            </a>
            <a
                class="btn btn-light"
                href="<?= e(url('pages/perjalanan_dinas_export.php?tahun=' . $tahunCetak . ($id > 0 ? '&id=' . $id : ''))) ?>"
            >Ekspor CSV</a>
            <button type="button" class="btn btn-success" onclick="window.print()">
                Cetak / Simpan PDF
            </button>
        </div>
    </div>

    <section class="card no-print">
        <form method="get" class="filter-bar" action="<?= e(url('pages/perjalanan_dinas_cetak.php')) ?>">
            <div class="form-group">
                <label for="filter_tahun">Tahun Anggaran</label>
                <select id="filter_tahun" name="tahun" data-auto-submit>
                    <option value="0">Semua tahun</option>
                    <?php foreach ($tahunList as $th): ?>
                        <option value="<?= $th ?>" <?= $tahunCetak === $th ? 'selected' : '' ?>>
                            <?= $th ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <?php if ($id > 0): ?>
                <span class="chip">Hanya surat tugas terpilih</span>
            <?php endif; ?>

            <button type="submit" class="btn btn-sm">Terapkan</button>
        </form>

        <p class="text-muted mb-0">
            <?= count($daftar) ?> surat tugas &middot;
            <?= $totalPeserta ?> peserta &middot;
            total <?= rupiah($totalKeseluruhan) ?>
        </p>
    </section>

    <section class="card rekap-card">
        <div class="rekap-doc">
            <div class="rekap-title">
                <h2>REKAP PERJALANAN DINAS DALAM DAERAH</h2>
                <h3>TAHUN ANGGARAN <?= e($judulTahun) ?></h3>
            </div>

            <div class="rekap-meta">
                <div><span>NAMA SKPD</span>: DINAS PERIKANAN DAN PETERNAKAN KABUPATEN BOGOR</div>
                <div><span>BIDANG</span>: PENGUATAN DAYA SAING PRODUK PERIKANAN</div>
                <div><span>TIM</span>: TIM PELAYANAN USAHA DAN PEMASARAN HASIL PERIKANAN</div>
            </div>

            <div class="table-wrapper rekap-wrapper">
                <table class="rekap-table">
                    <thead>
                        <tr>
                            <th rowspan="2">No</th>
                            <th rowspan="2">Kode Rekening</th>
                            <th rowspan="2">Kegiatan</th>
                            <th rowspan="2">Sub Kegiatan</th>
                            <th rowspan="2">Nama</th>
                            <th rowspan="2">NIP</th>
                            <th rowspan="2">Pangkat</th>
                            <th rowspan="2">Golongan Ruang</th>
                            <th rowspan="2">Nomor/tgl Surat Tugas</th>
                            <th rowspan="2">Jumlah Hari</th>
                            <th rowspan="2">Tanggal Berangkat</th>
                            <th rowspan="2">Tanggal Kembali</th>
                            <th rowspan="2">Maksud Perjalanan Dinas<br>(Sesuai Surat Tugas)</th>
                            <th rowspan="2">Tempat Tujuan</th>
                            <th rowspan="2">Nama Hotel/<br>Penginapan</th>
                            <th colspan="2">Tanggal Menginap</th>
                            <th colspan="7">BIAYA PERJALANAN DINAS</th>
                            <th rowspan="2">Total Biaya</th>
                        </tr>
                        <tr>
                            <th>Check In</th>
                            <th>Check Out</th>
                            <th>Uang Harian (Rp)</th>
                            <th>Penginapan/Hotel (Rp)</th>
                            <th>Representasi/<br>Biaya Lain2 (Rp)</th>
                            <th>Biaya Transport Lokal (Rp)</th>
                            <th>Taksi/Sewa Mobil (Rp)</th>
                            <th>Biaya BBM</th>
                            <th>Biaya Lain-lain</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if (empty($daftar)): ?>
                            <tr>
                                <td colspan="25" class="text-center">
                                    Belum ada data perjalanan dinas pada tahun ini.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $nomor = 0; ?>

                            <?php foreach ($daftar as $row): ?>
                                <?php
                                $nomor++;
                                $pesertaRows = $pesertaGrup[(int) $row['id']] ?? [];
                                $span = max(1, count($pesertaRows));
                                $subtotal = (float) $row['total_biaya'];
                                ?>
                                <?php if (empty($pesertaRows)): ?>
                                    <tr>
                                        <td><?= $nomor ?></td>
                                        <td><?= e($row['kode_rekening']) ?></td>
                                        <td><?= e($row['nama_kegiatan']) ?></td>
                                        <td><?= e($row['nama_sub_kegiatan']) ?></td>
                                        <td colspan="20" class="text-center">Tidak ada peserta</td>
                                        <td class="num"><?= rupiah(0) ?></td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($pesertaRows as $index => $p): ?>
                                        <tr>
                                            <?php if ($index === 0): ?>
                                                <td rowspan="<?= $span ?>"><?= $nomor ?></td>
                                                <td rowspan="<?= $span ?>"><?= e($row['kode_rekening']) ?></td>
                                                <td rowspan="<?= $span ?>">
                                                    <strong><?= e($row['kode_kegiatan']) ?></strong><br>
                                                    <?= e($row['nama_kegiatan']) ?>
                                                </td>
                                                <td rowspan="<?= $span ?>">
                                                    <strong><?= e($row['kode_sub_kegiatan']) ?></strong><br>
                                                    <?= e($row['nama_sub_kegiatan']) ?>
                                                </td>
                                            <?php endif; ?>

                                            <td><?= e($p['nama']) ?></td>
                                            <td><?= e($p['nip'] ?: '-') ?></td>
                                            <td><?= e($p['pangkat'] ?: '-') ?></td>
                                            <td><?= e($p['golongan_ruang'] ?: '-') ?></td>

                                            <?php if ($index === 0): ?>
                                                <td rowspan="<?= $span ?>">
                                                    <?= e($row['nomor_st']) ?><br>
                                                    <?= e(tanggalIndo($row['tanggal_st'])) ?>
                                                </td>
                                                <td rowspan="<?= $span ?>"><?= (int) $row['lama_hari'] ?></td>
                                                <td rowspan="<?= $span ?>">
                                                    <?= e(tanggalIndo($row['tanggal_berangkat'])) ?>
                                                </td>
                                                <td rowspan="<?= $span ?>">
                                                    <?= e(tanggalIndo($row['tanggal_kembali'])) ?>
                                                </td>
                                                <td rowspan="<?= $span ?>"><?= e($row['maksud']) ?></td>
                                                <td rowspan="<?= $span ?>"><?= e($row['tujuan']) ?></td>
                                            <?php endif; ?>

                                            <td><?= e($p['nama_hotel'] ?: '-') ?></td>
                                            <td class="nowrap"><?= e(tanggalIndo($p['tanggal_check_in'])) ?></td>
                                            <td class="nowrap"><?= e(tanggalIndo($p['tanggal_check_out'])) ?></td>
                                            <td class="num"><?= rupiah($p['uang_harian']) ?></td>
                                            <td class="num"><?= rupiah($p['penginapan']) ?></td>
                                            <td class="num"><?= rupiah($p['representasi']) ?></td>
                                            <td class="num"><?= rupiah($p['transport_lokal']) ?></td>
                                            <td class="num"><?= rupiah($p['taksi_sewa']) ?></td>
                                            <td class="num"><?= rupiah($p['bbm']) ?></td>
                                            <td class="num"><?= rupiah($p['biaya_lain']) ?></td>
                                            <td class="num"><strong><?= rupiah($p['total_biaya']) ?></strong></td>
                                        </tr>
                                    <?php endforeach; ?>

                                    <tr class="subtotal-row">
                                        <td colspan="24" class="num">
                                            Subtotal Surat Tugas <?= e($row['nomor_st']) ?>
                                        </td>
                                        <td class="num"><strong><?= rupiah($subtotal) ?></strong></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; ?>

                            <tr class="grand-total-row">
                                <td colspan="24" class="num">JUMLAH</td>
                                <td class="num"><strong><?= rupiah($totalKeseluruhan) ?></strong></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="rekap-sign">
                <div class="rekap-sign-col">
                    <p>
                        Mengetahui,<br>
                        Kepala Dinas Perikanan dan Peternakan<br>
                        Kabupaten Bogor
                    </p>
                    <div class="rekap-sign-space"></div>
                    <p class="rekap-sign-name">
                        ..................................................<br>
                        NIP. ............................................
                    </p>
                </div>

                <div class="rekap-sign-col">
                    <p>
                        Bogor, ................................ <?= e($tahunCetak > 0 ? (string) $tahunCetak : date('Y')) ?><br>
                        Bendahara Pengeluaran
                    </p>
                    <div class="rekap-sign-space"></div>
                    <p class="rekap-sign-name">
                        ..................................................<br>
                        NIP. ............................................
                    </p>
                </div>
            </div>
        </div>
    </section>
</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
