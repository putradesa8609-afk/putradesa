<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

requireLogin();

$pageTitle = 'Detail Rincian Anggaran';
$currentPage = 'anggaran';

$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);

if (!is_int($id) || $id < 1) {
    setFlash('warning', 'Rincian anggaran yang ingin dibuka tidak valid.');
    redirect(url('pages/anggaran.php'));
}

$stmt = $pdo->prepare(
    'SELECT
        ra.id,
        ra.kode_rup,
        ra.uraian,
        ra.kategori_belanja,
        ra.volume,
        ra.harga_satuan,
        ra.total_pagu,
        ra.kena_ppn,
        ra.tarif_ppn,
        ra.status,
        ra.catatan,
        sk.kode_sub_kegiatan,
        sk.nama_sub_kegiatan,
        k.kode_kegiatan,
        k.nama_kegiatan,
        k.tahun_anggaran,
        mr.kode_rekening,
        mr.nama_rekening,
        ms.nama_satuan
    FROM rincian_anggaran AS ra
    INNER JOIN sub_kegiatan AS sk ON sk.id = ra.sub_kegiatan_id
    INNER JOIN kegiatan AS k ON k.id = sk.kegiatan_id
    INNER JOIN master_rekening AS mr ON mr.id = ra.rekening_id
    LEFT JOIN master_satuan AS ms ON ms.id = ra.satuan_id
    WHERE ra.id = :id'
);
$stmt->execute([':id' => $id]);
$rincian = $stmt->fetch();

if (!$rincian) {
    setFlash('warning', 'Rincian anggaran tidak ditemukan.');
    redirect(url('pages/anggaran.php'));
}

// Daftar realisasi + total dibayar per realisasi
$stmt = $pdo->prepare(
    'SELECT
        r.*,
        mp.nama_penyedia,
        mp.nama_pimpinan,
        mp.npwp,
        COALESCE(p.total_dibayar, 0) AS total_dibayar
    FROM realisasi_anggaran AS r
    LEFT JOIN master_penyedia AS mp ON mp.id = r.penyedia_id
    LEFT JOIN (
        SELECT realisasi_id, SUM(jumlah_dibayar) AS total_dibayar
        FROM realisasi_pembayaran
        GROUP BY realisasi_id
    ) AS p ON p.realisasi_id = r.id
    WHERE r.rincian_anggaran_id = :id
    ORDER BY r.id ASC'
);
$stmt->execute([':id' => $id]);
$realisasiList = $stmt->fetchAll();

// Riwayat pembayaran, dikelompokkan per realisasi
$pembayaranMap = [];
$kumulatifMap = [];

if (!empty($realisasiList)) {
    $ids = array_column($realisasiList, 'id');
    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    $stmt = $pdo->prepare(
        'SELECT *
        FROM realisasi_pembayaran
        WHERE realisasi_id IN (' . $placeholders . ')
        ORDER BY tanggal_bayar ASC, id ASC'
    );
    $stmt->execute($ids);

    foreach ($stmt->fetchAll() as $bayar) {
        $pembayaranMap[$bayar['realisasi_id']][] = $bayar;
    }
}

foreach ($pembayaranMap as $rid => $daftar) {
    $jalan = 0.0;

    foreach ($daftar as $bayar) {
        $jalan += (float) $bayar['jumlah_dibayar'];
        $kumulatifMap[$rid][(int) $bayar['id']] = $jalan;
    }
}

// Total (realisasi berstatus DIBATALKAN tidak dihitung)
$pagu = (float) $rincian['total_pagu'];
$totalRealisasi = 0.0;
$totalDibayar = 0.0;

foreach ($realisasiList as $r) {
    if ($r['status'] !== 'DIBATALKAN') {
        $totalRealisasi += (float) $r['nilai_realisasi'];
        $totalDibayar += (float) $r['total_dibayar'];
    }
}

$ringkasan = ringkasRealisasi($pagu, $totalRealisasi);
$sisaAnggaran = $ringkasan['sisa'];
$belumDibayar = round($totalRealisasi - $totalDibayar, 2);
$persenDibayar = $totalRealisasi > 0 ? round($totalDibayar / $totalRealisasi * 100, 2) : 0.0;
$lebarRealisasi = max(0.0, min(100.0, $ringkasan['persen']));
$adaPeringatan = false;

foreach ($realisasiList as $r) {
    if (!empty(peringatanRealisasi($r))) {
        $adaPeringatan = true;
        break;
    }
}

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<main class="main-content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Detail Rincian Anggaran</h2>
            <p class="page-description">
                <?= e($rincian['kode_rup']) ?> &middot; <?= e($rincian['uraian']) ?>
            </p>
        </div>

        <div class="page-actions">
            <a class="btn btn-light" href="<?= e(url('pages/anggaran.php')) ?>">
                &larr; Kembali
            </a>

            <?php if (canManage()): ?>
                <a
                    class="btn btn-outline-dark"
                    href="<?= e(url('pages/anggaran.php?edit=' . (int) $rincian['id'])) ?>"
                >Ubah Rincian</a>

                <a
                    class="btn btn-success"
                    href="<?= e(url('pages/realisasi.php')) ?>"
                >Catat Realisasi</a>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($sisaAnggaran < 0): ?>
        <div class="alert alert-danger">
            Total realisasi melebihi pagu anggaran sebesar
            <?= e(rupiah(abs($sisaAnggaran))) ?>.
        </div>
    <?php endif; ?>

    <div class="kpi-grid">
        <div class="kpi">
            <span class="kpi-label">Total Pagu</span>
            <span class="kpi-value" title="<?= e(rupiah($pagu)) ?>">
                <?= e(rupiahRingkas($pagu)) ?>
            </span>
            <span class="kpi-sub">
                <?= e(number_format((float) $rincian['volume'], 2, ',', '.')) ?>
                <?= e($rincian['nama_satuan'] ?? 'satuan') ?>
                &times; <?= e(rupiah($rincian['harga_satuan'])) ?>
            </span>
        </div>

        <div class="kpi kpi--accent">
            <span class="kpi-label">Total Realisasi</span>
            <span class="kpi-value" title="<?= e(rupiah($totalRealisasi)) ?>">
                <?= e(rupiahRingkas($totalRealisasi)) ?>
            </span>
            <span class="kpi-sub">
                <strong><?= e(persen($ringkasan['persen'])) ?></strong> dari pagu
            </span>
        </div>

        <div class="kpi <?= $sisaAnggaran < 0 ? 'kpi--danger' : 'kpi--info' ?>">
            <span class="kpi-label">Sisa Pagu</span>
            <span class="kpi-value" title="<?= e(rupiah($sisaAnggaran)) ?>">
                <?= e(rupiahRingkas($sisaAnggaran)) ?>
            </span>
            <span class="kpi-sub"><?= e($ringkasan['label']) ?></span>
        </div>

        <div class="kpi <?= $belumDibayar > 0 ? 'kpi--warning' : '' ?>">
            <span class="kpi-label">Belum Dibayar</span>
            <span class="kpi-value" title="<?= e(rupiah($belumDibayar)) ?>">
                <?= e(rupiahRingkas($belumDibayar)) ?>
            </span>
            <span class="kpi-sub">
                Dibayar <strong><?= e(persen($persenDibayar)) ?></strong>
                dari nilai realisasi
            </span>
        </div>
    </div>

    <section class="card">
        <div class="card-header">
            <h3>Informasi Rincian</h3>
            <?= statusBadge($rincian['status']) ?>
        </div>

        <div class="card-body">
            <div class="form-grid">
                <div class="form-group">
                    <label>Kegiatan</label>
                    <p>
                        <?= e($rincian['kode_kegiatan']) ?> &mdash;
                        <?= e($rincian['nama_kegiatan']) ?>
                        (<?= e($rincian['tahun_anggaran']) ?>)
                    </p>
                </div>

                <div class="form-group">
                    <label>Sub Kegiatan</label>
                    <p>
                        <?= e($rincian['kode_sub_kegiatan']) ?> &mdash;
                        <?= e($rincian['nama_sub_kegiatan']) ?>
                    </p>
                </div>

                <div class="form-group">
                    <label>Rekening</label>
                    <p>
                        <?= e($rincian['kode_rekening']) ?> &mdash;
                        <?= e($rincian['nama_rekening']) ?>
                    </p>
                </div>

                <div class="form-group">
                    <label>Kategori Belanja</label>
                    <p><?= e(kategoriBelanjaLabel($rincian['kategori_belanja'])) ?></p>
                </div>

                <div class="form-group">
                    <label>PPN</label>
                    <p>
                        <?php if ((int) $rincian['kena_ppn'] === 1): ?>
                            Dikenakan <?= e(persen($rincian['tarif_ppn'])) ?>
                        <?php else: ?>
                            Tidak dikenakan PPN
                        <?php endif; ?>
                    </p>
                </div>

                <?php if (!empty($rincian['catatan'])): ?>
                    <div class="form-group full">
                        <label>Catatan</label>
                        <p><?= nl2br(e($rincian['catatan'])) ?></p>
                    </div>
                <?php endif; ?>
            </div>

            <div class="progress">
                <div class="progress-bar" style="width: <?= e((string) $lebarRealisasi) ?>%"></div>
            </div>
            <div class="progress-meta">
                <span>Realisasi <?= e(persen($ringkasan['persen'])) ?></span>
                <span>Sisa <?= e(rupiah($sisaAnggaran)) ?></span>
            </div>
        </div>
    </section>

    <?php if (empty($realisasiList)): ?>
        <section class="card">
            <div class="card-body">
                <p class="text-muted">
                    Belum ada data realisasi untuk rincian anggaran ini.
                </p>

                <?php if (canManage()): ?>
                    <a class="btn btn-success" href="<?= e(url('pages/realisasi.php')) ?>">
                        Catat Realisasi Pertama
                    </a>
                <?php endif; ?>
            </div>
        </section>
    <?php else: ?>
        <?php foreach ($realisasiList as $no => $r): ?>
            <?php
            $nilai = (float) $r['nilai_realisasi'];
            $dibayar = (float) $r['total_dibayar'];
            $persenBayar = $nilai > 0 ? round($dibayar / $nilai * 100, 2) : 0.0;
            $lebarBayar = max(0.0, min(100.0, $persenBayar));
            $peringatan = peringatanRealisasi($r);
            $bayarList = $pembayaranMap[$r['id']] ?? [];
            ?>
            <section class="card">
                <div class="card-header">
                    <h3>
                        Realisasi <?= $no + 1 ?> &middot;
                        <?= $r['metode'] === 'PENYEDIA' ? 'Penyedia' : 'Swakelola' ?>
                    </h3>
                    <?= statusBadge($r['status']) ?>
                </div>

                <div class="card-body">
                    <?php foreach ($peringatan as $p): ?>
                        <div class="alert <?= 'alert-' . e($p['level']) ?>">
                            <?= e($p['teks']) ?>
                        </div>
                    <?php endforeach; ?>

                    <div class="stat-list">
                        <div class="stat-row">
                            <span class="label">Nilai Realisasi</span>
                            <span class="value"><?= e(rupiah($nilai)) ?></span>
                        </div>
                        <div class="stat-row">
                            <span class="label">Sudah Dibayar</span>
                            <span class="value"><?= e(rupiah($dibayar)) ?></span>
                        </div>
                        <div class="stat-row">
                            <span class="label">Sisa Belum Dibayar</span>
                            <span class="value"><?= e(rupiah($nilai - $dibayar)) ?></span>
                        </div>
                        <div class="stat-row">
                            <span class="label">Progres Pembayaran</span>
                            <span class="value"><?= e(persen($persenBayar)) ?></span>
                        </div>
                    </div>

                    <div class="progress">
                        <div
                            class="progress-bar progress-bar--accent"
                            style="width: <?= e((string) $lebarBayar) ?>%"
                        ></div>
                    </div>

                    <div class="table-wrapper">
                        <table>
                            <tbody>
                                <?php if ($r['metode'] === 'PENYEDIA'): ?>
                                    <tr>
                                        <th>Penyedia</th>
                                        <td>
                                            <?= e($r['nama_penyedia'] ?? '-') ?>
                                            <?php if (!empty($r['nama_pimpinan'])): ?>
                                                <br><small>Pimpinan: <?= e($r['nama_pimpinan']) ?></small>
                                            <?php endif; ?>
                                            <?php if (!empty($r['npwp'])): ?>
                                                <br><small>NPWP: <?= e($r['npwp']) ?></small>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Nomor Kontrak</th>
                                        <td>
                                            <?= e($r['nomor_kontrak'] ?? '-') ?>
                                            (<?= e(tanggalIndo($r['tanggal_kontrak'])) ?>)
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Surat Pesanan</th>
                                        <td>
                                            <?= e($r['nomor_surat_pesanan'] ?? '-') ?>
                                            (<?= e(tanggalIndo($r['tanggal_surat_pesanan'])) ?>)
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>SPK</th>
                                        <td>
                                            <?= e($r['nomor_spk'] ?? '-') ?>
                                            (<?= e(tanggalIndo($r['tanggal_spk'])) ?>)
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <tr>
                                        <th>Tipe Swakelola</th>
                                        <td><?= e($r['tipe_swakelola'] ?? '-') ?></td>
                                    </tr>
                                    <tr>
                                        <th>Pelaksana</th>
                                        <td><?= e($r['pelaksana_swakelola'] ?? '-') ?></td>
                                    </tr>
                                    <tr>
                                        <th>SK Tim</th>
                                        <td>
                                            <?= e($r['nomor_sk_tim'] ?? '-') ?>
                                            (<?= e(tanggalIndo($r['tanggal_sk_tim'])) ?>)
                                        </td>
                                    </tr>
                                <?php endif; ?>

                                <tr>
                                    <th>Pelaksanaan</th>
                                    <td>
                                        <?= e(tanggalIndo($r['tanggal_mulai'])) ?>
                                        s/d
                                        <?= e(tanggalIndo($r['tanggal_selesai'])) ?>
                                        <?php if (!empty($r['lama_hari'])): ?>
                                            (<?= e($r['lama_hari']) ?> hari)
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>BAST</th>
                                    <td>
                                        <?= e($r['nomor_bast'] ?? '-') ?>
                                        (<?= e(tanggalIndo($r['tanggal_bast'])) ?>)
                                    </td>
                                </tr>
                                <?php if (!empty($r['catatan'])): ?>
                                    <tr>
                                        <th>Catatan</th>
                                        <td><?= nl2br(e($r['catatan'])) ?></td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <h4>Riwayat Pembayaran</h4>

                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th class="num">No.</th>
                                    <th>Tanggal</th>
                                    <th>Jenis</th>
                                    <th>No. SPM</th>
                                    <th>No. SP2D</th>
                                    <th class="num">Jumlah Dibayar</th>
                                    <th class="num">Kumulatif</th>
                                    <th class="num">Progres Fisik</th>
                                    <th>Catatan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($bayarList)): ?>
                                    <tr>
                                        <td colspan="9" class="text-center text-muted">
                                            Belum ada pembayaran.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($bayarList as $j => $b): ?>
                                        <tr>
                                            <td class="num"><?= $j + 1 ?></td>
                                            <td><?= e(tanggalIndo($b['tanggal_bayar'])) ?></td>
                                            <td><?= e(ucwords(strtolower(str_replace('_', ' ', $b['jenis'])))) ?></td>
                                            <td><?= e($b['nomor_spm'] ?? '-') ?></td>
                                            <td><?= e($b['nomor_sp2d'] ?? '-') ?></td>
                                            <td class="num"><?= e(rupiah($b['jumlah_dibayar'])) ?></td>
                                            <td class="num">
                                                <?= e(rupiah($kumulatifMap[(int) $r['id']][(int) $b['id']] ?? $b['jumlah_dibayar'])) ?>
                                            </td>
                                            <td class="num">
                                                <?= $b['persentase_fisik'] !== null
                                                    ? e(persen($b['persentase_fisik']))
                                                    : '-' ?>
                                            </td>
                                            <td><?= e($b['catatan'] ?? '-') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if (canManage()): ?>
                        <div class="form-actions">
                            <a
                                class="btn btn-light btn-sm"
                                href="<?= e(url('pages/realisasi.php?edit=' . (int) $r['id'])) ?>"
                            >Ubah Realisasi</a>

                            <a
                                class="btn btn-outline-dark btn-sm"
                                href="<?= e(url('pages/pembayaran.php')) ?>"
                            >Catat Pembayaran</a>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        <?php endforeach; ?>
    <?php endif; ?>

    <?php if ($adaPeringatan): ?>
        <p class="text-muted">
            Peringatan di atas dihitung dari tanggal pelaksanaan, BAST, dan
            posisi pembayaran saat halaman ini dibuka.
        </p>
    <?php endif; ?>
</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
