<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

requireLogin();

$pageTitle = 'Detail Perjalanan Dinas';
$currentPage = 'perjalanan_dinas';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!is_int($id) || $id < 1) {
    setFlash('warning', 'Data perjalanan dinas tidak valid.');
    redirect(url('pages/perjalanan_dinas.php'));
}

$stmt = $pdo->prepare(
    'SELECT
        pd.id,
        pd.nomor_st,
        pd.tanggal_st,
        pd.maksud,
        pd.tujuan,
        pd.lama_hari,
        pd.tanggal_berangkat,
        pd.tanggal_kembali,
        pd.catatan,
        sk.kode_sub_kegiatan,
        sk.nama_sub_kegiatan,
        k.kode_kegiatan,
        k.nama_kegiatan,
        k.tahun_anggaran,
        mr.kode_rekening,
        mr.nama_rekening
    FROM perjalanan_dinas AS pd
    INNER JOIN sub_kegiatan AS sk ON sk.id = pd.sub_kegiatan_id
    INNER JOIN kegiatan AS k ON k.id = sk.kegiatan_id
    INNER JOIN master_rekening AS mr ON mr.id = pd.rekening_id
    WHERE pd.id = :id'
);
$stmt->execute([':id' => $id]);
$perjadin = $stmt->fetch();

if (!$perjadin) {
    setFlash('warning', 'Perjalanan dinas tidak ditemukan.');
    redirect(url('pages/perjalanan_dinas.php'));
}

$stmt = $pdo->prepare(
    'SELECT *
    FROM perjalanan_dinas_peserta
    WHERE perjalanan_id = :id
    ORDER BY id ASC'
);
$stmt->execute([':id' => $id]);
$pesertaList = $stmt->fetchAll();

$totalBiaya = 0.0;

foreach ($pesertaList as $p) {
    $totalBiaya += (float) $p['total_biaya'];
}

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<main class="main-content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Detail Perjalanan Dinas</h2>
            <p class="page-description">
                <?= e($perjadin['nomor_st']) ?>
                &middot; <?= e(tanggalIndo($perjadin['tanggal_st'])) ?>
            </p>
        </div>

        <div class="page-actions">
            <a class="btn btn-light" href="<?= e(url('pages/perjalanan_dinas.php')) ?>">Kembali</a>
            <a
                class="btn btn-light"
                href="<?= e(url('pages/perjalanan_dinas_cetak.php?tahun=' . (int) $perjadin['tahun_anggaran'] . '&id=' . (int) $perjadin['id'])) ?>"
            >Cetak Rekap</a>
            <?php if (canManage()): ?>
                <a
                    class="btn btn-success"
                    href="<?= e(url('pages/perjalanan_dinas.php?edit=' . (int) $perjadin['id'])) ?>"
                >Ubah</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="kpi-grid kpi-grid--3">
        <article class="kpi">
            <span class="kpi-label">Peserta</span>
            <span class="kpi-value"><?= count($pesertaList) ?></span>
            <span class="kpi-sub">Orang dalam surat tugas ini</span>
        </article>

        <article class="kpi kpi--info">
            <span class="kpi-label">Lama Perjalanan</span>
            <span class="kpi-value"><?= (int) $perjadin['lama_hari'] ?> hari</span>
            <span class="kpi-sub">
                <?= e(tanggalIndo($perjadin['tanggal_berangkat'])) ?>
                s.d. <?= e(tanggalIndo($perjadin['tanggal_kembali'])) ?>
            </span>
        </article>

        <article class="kpi kpi--accent">
            <span class="kpi-label">Total Biaya</span>
            <span class="kpi-value" title="<?= e(rupiah($totalBiaya)) ?>">
                <?= e(rupiahRingkas($totalBiaya)) ?>
            </span>
            <span class="kpi-sub"><?= e(rupiah($totalBiaya)) ?></span>
        </article>
    </div>

    <section class="card">
        <div class="card-header">
            <h3>Informasi Surat Tugas</h3>
            <span class="chip"><?= e($perjadin['tahun_anggaran']) ?></span>
        </div>

        <div class="form-grid">
            <div class="form-group">
                <label>Nomor Surat Tugas</label>
                <input type="text" value="<?= e($perjadin['nomor_st']) ?>" readonly>
            </div>

            <div class="form-group">
                <label>Tanggal Surat Tugas</label>
                <input type="text" value="<?= e(tanggalIndo($perjadin['tanggal_st'])) ?>" readonly>
            </div>

            <div class="form-group full">
                <label>Kegiatan</label>
                <input
                    type="text"
                    value="<?= e($perjadin['kode_kegiatan'] . ' - ' . $perjadin['nama_kegiatan']) ?>"
                    readonly
                >
            </div>

            <div class="form-group full">
                <label>Sub Kegiatan</label>
                <input
                    type="text"
                    value="<?= e($perjadin['kode_sub_kegiatan'] . ' - ' . $perjadin['nama_sub_kegiatan']) ?>"
                    readonly
                >
            </div>

            <div class="form-group full">
                <label>Kode Rekening</label>
                <input
                    type="text"
                    value="<?= e($perjadin['kode_rekening'] . ' - ' . $perjadin['nama_rekening']) ?>"
                    readonly
                >
            </div>

            <div class="form-group full">
                <label>Maksud Perjalanan Dinas</label>
                <textarea readonly><?= e($perjadin['maksud']) ?></textarea>
            </div>

            <div class="form-group">
                <label>Tempat Tujuan</label>
                <input type="text" value="<?= e($perjadin['tujuan']) ?>" readonly>
            </div>

            <div class="form-group">
                <label>Jumlah Hari</label>
                <input type="text" value="<?= (int) $perjadin['lama_hari'] ?> hari" readonly>
            </div>

            <div class="form-group">
                <label>Tanggal Berangkat</label>
                <input type="text" value="<?= e(tanggalIndo($perjadin['tanggal_berangkat'])) ?>" readonly>
            </div>

            <div class="form-group">
                <label>Tanggal Kembali</label>
                <input type="text" value="<?= e(tanggalIndo($perjadin['tanggal_kembali'])) ?>" readonly>
            </div>

            <?php if (!empty($perjadin['catatan'])): ?>
                <div class="form-group full">
                    <label>Catatan</label>
                    <textarea readonly><?= e($perjadin['catatan']) ?></textarea>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="card">
        <div class="card-header">
            <h3>Rincian Peserta dan Biaya</h3>
            <span class="text-muted"><?= count($pesertaList) ?> peserta</span>
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama / NIP</th>
                        <th>Pangkat / Golongan</th>
                        <th>Hotel</th>
                        <th>Check In</th>
                        <th>Check Out</th>
                        <th class="num">Uang Harian</th>
                        <th class="num">Penginapan</th>
                        <th class="num">Representasi</th>
                        <th class="num">Transport</th>
                        <th class="num">Taksi/Sewa</th>
                        <th class="num">BBM</th>
                        <th class="num">Lain-lain</th>
                        <th class="num">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($pesertaList)): ?>
                        <tr>
                            <td colspan="14" class="text-center">Belum ada peserta.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($pesertaList as $i => $p): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td>
                                    <strong><?= e($p['nama']) ?></strong><br>
                                    <span class="text-muted">NIP <?= e($p['nip'] ?: '-') ?></span>
                                </td>
                                <td>
                                    <?= e($p['pangkat'] ?: '-') ?><br>
                                    <span class="text-muted"><?= e($p['golongan_ruang'] ?: '-') ?></span>
                                    <?php if (!empty($p['jabatan'])): ?>
                                        <br>
                                        <span class="text-muted">Jabatan: <?= e($p['jabatan']) ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?= e($p['nama_hotel'] ?: '-') ?></td>
                                <td class="nowrap"><?= e(tanggalIndo($p['tanggal_check_in'])) ?></td>
                                <td class="nowrap"><?= e(tanggalIndo($p['tanggal_check_out'])) ?></td>
                                <td class="num"><?= rupiah($p['uang_harian']) ?></td>
                                <td class="num"><?= rupiah($p['penginapan']) ?></td>
                                <td class="num"><?= rupiah($p['representasi']) ?></td>
                                <td class="num"><?= rupiah($p['transport_lokal']) ?></td>
                                <td class="num"><?= rupiah($p['taksi_sewa']) ?></td>
                                <td class="num"><?= rupiah($p['bbm']) ?></td>
                                <td class="num"><?= rupiah($p['biaya_lain']) ?></td>
                                <td class="num"><strong><?= rupiah($p['total_biaya']) ?></strong></td>
                            </tr>
                        <?php endforeach; ?>
                        <tr class="total-row">
                            <td colspan="13" class="num"><strong>Total Biaya</strong></td>
                            <td class="num"><strong><?= rupiah($totalBiaya) ?></strong></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
