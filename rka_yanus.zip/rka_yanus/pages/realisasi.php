<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

requireLogin();

$pageTitle = 'Realisasi Anggaran';
$currentPage = 'realisasi';

$errors = [];
$edit = null;
$totalDibayarEdit = 0.0;

function tanggalValid(string $nilai): string|false
{
    $d = DateTime::createFromFormat('!Y-m-d', $nilai);

    return ($d !== false && $d->format('Y-m-d') === $nilai) ? $nilai : false;
}

// ID dari ?edit= atau dari POST (agar nilai form tidak hilang saat validasi gagal)
$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);

if (!is_int($editId) || $editId < 1) {
    $idPost = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    $editId = (is_int($idPost) && $idPost > 0) ? $idPost : null;
}

if ($editId !== null) {
    $stmt = $pdo->prepare('SELECT * FROM realisasi_anggaran WHERE id = :id');
    $stmt->execute([':id' => $editId]);
    $edit = $stmt->fetch() ?: null;

    if ($edit === null) {
        setFlash('warning', 'Data realisasi yang ingin diubah tidak ditemukan.');
        redirect(url('pages/realisasi.php'));
    }

    $stmt = $pdo->prepare(
        'SELECT COALESCE(SUM(jumlah_dibayar), 0)
        FROM realisasi_pembayaran
        WHERE realisasi_id = :id'
    );
    $stmt->execute([':id' => $editId]);
    $totalDibayarEdit = (float) $stmt->fetchColumn();

    if ($edit['status'] === 'DIBATALKAN' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
        setFlash('warning', 'Realisasi yang sudah dibatalkan tidak dapat diubah.');
        redirect(url('pages/realisasi.php'));
    }
}

$kunciRincian = $edit !== null && $totalDibayarEdit > 0.005;

// Nilai lama form: POST lebih dulu, lalu data yang sedang diubah
$old = static function (string $key) use ($edit): string {
    if (array_key_exists($key, $_POST)) {
        $v = $_POST[$key];

        return e(is_string($v) ? $v : '');
    }

    return e($edit[$key] ?? '');
};

$selected = static function (string $key, string $value) use ($edit): string {
    $current = array_key_exists($key, $_POST) ? $_POST[$key] : ($edit[$key] ?? '');

    if (!is_scalar($current)) {
        return '';
    }

    return (string) $current === $value ? 'selected' : '';
};

// =====================================================================
// PROSES POST
// =====================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf($_POST['csrf_token'] ?? null);
    requireManage();

    $aksi = (string) ($_POST['aksi'] ?? 'realisasi');

    // -----------------------------------------------------------------
    // A. Tambah penyedia baru
    // -----------------------------------------------------------------
    if ($aksi === 'penyedia') {
        $namaPenyedia = trim((string) ($_POST['nama_penyedia'] ?? ''));
        $npwp = trim((string) ($_POST['npwp'] ?? ''));
        $alamat = trim((string) ($_POST['alamat'] ?? ''));
        $pimpinan = trim((string) ($_POST['nama_pimpinan'] ?? ''));

        if ($namaPenyedia === '' || mb_strlen($namaPenyedia) > 200) {
            setFlash('danger', 'Nama penyedia wajib diisi (maksimal 200 karakter).');
        } elseif (mb_strlen($npwp) > 30 || mb_strlen($pimpinan) > 150) {
            setFlash('danger', 'NPWP atau nama pimpinan melebihi panjang yang diizinkan.');
        } else {
            try {
                $stmt = $pdo->prepare(
                    'INSERT INTO master_penyedia
                    (nama_penyedia, npwp, alamat, nama_pimpinan)
                    VALUES (:nama, :npwp, :alamat, :pimpinan)'
                );

                $stmt->execute([
                    ':nama' => $namaPenyedia,
                    ':npwp' => $npwp !== '' ? $npwp : null,
                    ':alamat' => $alamat !== '' ? $alamat : null,
                    ':pimpinan' => $pimpinan !== '' ? $pimpinan : null,
                ]);

                setFlash('success', 'Penyedia ' . $namaPenyedia . ' berhasil ditambahkan.');
            } catch (PDOException $e) {
                error_log($e->getMessage());
                setFlash(
                    'danger',
                    $e->getCode() === '23000'
                        ? 'Nama penyedia sudah terdaftar.'
                        : 'Penyedia gagal disimpan. Periksa log PHP.'
                );
            }
        }

        redirect(url('pages/realisasi.php'));
    }

    // -----------------------------------------------------------------
    // B. Hapus / batalkan realisasi
    // -----------------------------------------------------------------
    if ($aksi === 'hapus' || $aksi === 'batal') {
        $targetId = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);

        if (!is_int($targetId) || $targetId < 1) {
            setFlash('danger', 'Data realisasi tidak valid.');
            redirect(url('pages/realisasi.php'));
        }

        $stmt = $pdo->prepare(
            'SELECT r.status, ra.kode_rup
            FROM realisasi_anggaran AS r
            INNER JOIN rincian_anggaran AS ra ON ra.id = r.rincian_anggaran_id
            WHERE r.id = :id'
        );
        $stmt->execute([':id' => $targetId]);
        $target = $stmt->fetch();

        $stmt = $pdo->prepare(
            'SELECT COUNT(*) FROM realisasi_pembayaran WHERE realisasi_id = :id'
        );
        $stmt->execute([':id' => $targetId]);
        $jumlahBayar = (int) $stmt->fetchColumn();

        if (!$target) {
            setFlash('warning', 'Realisasi tidak ditemukan.');
        } elseif ($jumlahBayar > 0) {
            setFlash(
                'danger',
                'Realisasi ' . $target['kode_rup'] . ' tidak dapat '
                . ($aksi === 'hapus' ? 'dihapus' : 'dibatalkan')
                . ' karena sudah memiliki ' . $jumlahBayar . ' pembayaran.'
            );
        } elseif ($aksi === 'hapus') {
            $stmt = $pdo->prepare('DELETE FROM realisasi_anggaran WHERE id = :id');
            $stmt->execute([':id' => $targetId]);
            setFlash('success', 'Realisasi ' . $target['kode_rup'] . ' berhasil dihapus.');
        } elseif ($target['status'] === 'DIBATALKAN') {
            setFlash('info', 'Realisasi tersebut sudah berstatus dibatalkan.');
        } else {
            $stmt = $pdo->prepare(
                "UPDATE realisasi_anggaran SET status = 'DIBATALKAN' WHERE id = :id"
            );
            $stmt->execute([':id' => $targetId]);
            setFlash('success', 'Realisasi ' . $target['kode_rup'] . ' telah dibatalkan.');
        }

        redirect(url('pages/realisasi.php'));
    }

    // -----------------------------------------------------------------
    // C. Simpan / ubah realisasi anggaran
    // -----------------------------------------------------------------
    if ($edit !== null && $edit['status'] === 'DIBATALKAN') {
        setFlash('warning', 'Realisasi yang sudah dibatalkan tidak dapat diubah.');
        redirect(url('pages/realisasi.php'));
    }

    $rincianId = filter_var($_POST['rincian_anggaran_id'] ?? null, FILTER_VALIDATE_INT);
    $metode = (string) ($_POST['metode'] ?? '');
    $penyediaId = filter_var($_POST['penyedia_id'] ?? null, FILTER_VALIDATE_INT);

    $tipeSwakelola = (string) ($_POST['tipe_swakelola'] ?? '');
    $pelaksanaSwakelola = trim((string) ($_POST['pelaksana_swakelola'] ?? ''));
    $nomorSkTim = trim((string) ($_POST['nomor_sk_tim'] ?? ''));

    $nomorKontrak = trim((string) ($_POST['nomor_kontrak'] ?? ''));
    $nomorSp = trim((string) ($_POST['nomor_surat_pesanan'] ?? ''));
    $nomorSpk = trim((string) ($_POST['nomor_spk'] ?? ''));
    $nomorBast = trim((string) ($_POST['nomor_bast'] ?? ''));

    $nilaiInput = trim((string) ($_POST['nilai_realisasi'] ?? ''));
    $status = (string) ($_POST['status'] ?? '');
    $catatan = trim((string) ($_POST['catatan'] ?? ''));

    // Parsing tanggal: null = kosong, false = format salah
    $tgl = [];
    $labelTanggal = [
        'tanggal_sk_tim'        => 'SK Tim',
        'tanggal_kontrak'       => 'kontrak',
        'tanggal_surat_pesanan' => 'surat pesanan',
        'tanggal_spk'           => 'SPK',
        'tanggal_mulai'         => 'mulai',
        'tanggal_selesai'       => 'berakhir',
        'tanggal_bast'          => 'BAST',
    ];

    foreach ($labelTanggal as $field => $label) {
        $raw = trim((string) ($_POST[$field] ?? ''));
        $tgl[$field] = $raw === '' ? null : tanggalValid($raw);

        if ($tgl[$field] === false) {
            $errors[] = 'Format tanggal ' . $label . ' tidak valid.';
        }
    }

    $nilaiValid = $nilaiInput !== '' && is_numeric($nilaiInput);
    $nilai = $nilaiValid ? (float) $nilaiInput : 0.0;

    // Validasi umum
    if (!is_int($rincianId) || $rincianId < 1) {
        $errors[] = 'Rincian anggaran wajib dipilih.';
    }

    if (!in_array($metode, ['PENYEDIA', 'SWAKELOLA'], true)) {
        $errors[] = 'Metode pelaksanaan tidak valid.';
    }

    if (!$nilaiValid || $nilai <= 0 || $nilai > 99_999_999_999_999.99) {
        $errors[] = 'Nilai realisasi harus berupa angka lebih besar dari nol.';
    }

    if (!in_array($status, ['DRAFT', 'BERJALAN', 'SELESAI'], true)) {
        $errors[] = 'Status tidak valid.';
    }

    if ($tgl['tanggal_mulai'] === null || $tgl['tanggal_selesai'] === null) {
        $errors[] = 'Tanggal mulai dan tanggal selesai pekerjaan wajib diisi.';
    } elseif (
        $tgl['tanggal_mulai'] !== false
        && $tgl['tanggal_selesai'] !== false
        && $tgl['tanggal_selesai'] < $tgl['tanggal_mulai']
    ) {
        $errors[] = 'Tanggal selesai tidak boleh lebih awal dari tanggal mulai.';
    }

    // Pasangan nomor & tanggal harus lengkap
    $pasangan = [
        'Kontrak'       => [$nomorKontrak, $tgl['tanggal_kontrak']],
        'Surat Pesanan' => [$nomorSp, $tgl['tanggal_surat_pesanan']],
        'SPK'           => [$nomorSpk, $tgl['tanggal_spk']],
        'SK Tim'        => [$nomorSkTim, $tgl['tanggal_sk_tim']],
        'BAST'          => [$nomorBast, $tgl['tanggal_bast']],
    ];

    foreach ($pasangan as $label => [$nomor, $tanggal]) {
        if (($nomor === '') !== ($tanggal === null) && $tanggal !== false) {
            $errors[] = 'Nomor dan tanggal ' . $label . ' harus diisi berpasangan.';
        }
    }

    // Validasi per metode
    if ($metode === 'PENYEDIA') {
        if (!is_int($penyediaId) || $penyediaId < 1) {
            $errors[] = 'Nama penyedia wajib dipilih.';
        }

        if ($nomorKontrak === '' && $nomorSp === '' && $nomorSpk === '') {
            $errors[] = 'Isi minimal satu dokumen: kontrak, surat pesanan, atau SPK.';
        }

        $tipeSwakelola = '';
        $pelaksanaSwakelola = '';
        $nomorSkTim = '';
        $tgl['tanggal_sk_tim'] = null;
    } elseif ($metode === 'SWAKELOLA') {
        if (!in_array($tipeSwakelola, ['I', 'II', 'III', 'IV'], true)) {
            $errors[] = 'Tipe swakelola wajib dipilih.';
        }

        if ($pelaksanaSwakelola === '' || mb_strlen($pelaksanaSwakelola) > 200) {
            $errors[] = 'Pelaksana swakelola wajib diisi (maksimal 200 karakter).';
        }

        $penyediaId = null;
        $nomorKontrak = $nomorSp = $nomorSpk = '';
        $tgl['tanggal_kontrak'] = null;
        $tgl['tanggal_surat_pesanan'] = null;
        $tgl['tanggal_spk'] = null;
    }

    if ($status === 'SELESAI' && $nomorBast === '') {
        $errors[] = 'Status Selesai mensyaratkan nomor dan tanggal BAST.';
    }

    if ($nomorBast !== '' && $status !== 'SELESAI') {
        $errors[] = 'BAST sudah diisi, ubah status menjadi Selesai.';
    }

    // Urutan tanggal dokumen terhadap tanggal mulai
    $mulai = $tgl['tanggal_mulai'];

    if (is_string($mulai)) {
        foreach ([
            'tanggal_kontrak'       => 'Tanggal kontrak',
            'tanggal_surat_pesanan' => 'Tanggal surat pesanan',
            'tanggal_spk'           => 'Tanggal SPK',
        ] as $field => $label) {
            if (is_string($tgl[$field]) && $tgl[$field] > $mulai) {
                $errors[] = $label . ' tidak boleh setelah tanggal mulai pekerjaan.';
            }
        }

        if (is_string($tgl['tanggal_bast']) && $tgl['tanggal_bast'] < $mulai) {
            $errors[] = 'Tanggal BAST tidak boleh sebelum tanggal mulai pekerjaan.';
        }
    }

    // Aturan saat mengubah data yang sudah memiliki pembayaran
    if ($edit !== null) {
        if (
            $kunciRincian
            && is_int($rincianId)
            && $rincianId !== (int) $edit['rincian_anggaran_id']
        ) {
            $errors[] = 'Rincian anggaran tidak dapat dipindah karena realisasi ini '
                . 'sudah memiliki pembayaran.';
        }

        if ($nilaiValid && $nilai + 0.005 < $totalDibayarEdit) {
            $errors[] = 'Nilai realisasi tidak boleh lebih kecil dari total pembayaran ('
                . rupiah($totalDibayarEdit) . ').';
        }
    }

    // Simpan
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            // Kunci baris rincian agar pengecekan sisa pagu aman
            $stmt = $pdo->prepare(
                'SELECT id, kode_rup, total_pagu, status
                FROM rincian_anggaran
                WHERE id = :id
                FOR UPDATE'
            );
            $stmt->execute([':id' => $rincianId]);
            $rincian = $stmt->fetch();

            if (!$rincian || $rincian['status'] === 'DIBATALKAN') {
                throw new RuntimeException(
                    'Rincian anggaran tidak ditemukan atau sudah dibatalkan.'
                );
            }

            $sqlRealisasi = "SELECT COALESCE(SUM(nilai_realisasi), 0)
                FROM realisasi_anggaran
                WHERE rincian_anggaran_id = :id
                AND status <> 'DIBATALKAN'";
            $paramsRealisasi = [':id' => $rincianId];

            if ($edit !== null) {
                $sqlRealisasi .= ' AND id <> :exclude';
                $paramsRealisasi[':exclude'] = $editId;
            }

            $stmt = $pdo->prepare($sqlRealisasi);
            $stmt->execute($paramsRealisasi);
            $sudahRealisasi = (float) $stmt->fetchColumn();

            $sisaPagu = (float) $rincian['total_pagu'] - $sudahRealisasi;

            if ($nilai > $sisaPagu + 0.005) {
                throw new RuntimeException(
                    'Nilai realisasi melebihi sisa pagu rincian ('
                    . rupiah($sisaPagu) . ').'
                );
            }

            if ($metode === 'PENYEDIA') {
                $stmt = $pdo->prepare(
                    'SELECT COUNT(*) FROM master_penyedia
                    WHERE id = :id AND aktif = 1'
                );
                $stmt->execute([':id' => $penyediaId]);

                if ((int) $stmt->fetchColumn() === 0) {
                    throw new RuntimeException(
                        'Penyedia tidak ditemukan atau sudah tidak aktif.'
                    );
                }
            }

            // Satu kode RUP = satu dokumen (kontrak/SP/SPK). Nomor yang sama
            // boleh dipakai banyak item dalam RUP tersebut, tetapi tidak boleh
            // dipakai RUP lain. BAST dikecualikan karena mengikuti termin.
            $dokumenRup = $metode === 'PENYEDIA'
                ? [
                    'nomor_kontrak'       => ['label' => 'Nomor kontrak', 'nilai' => $nomorKontrak],
                    'nomor_surat_pesanan' => ['label' => 'Nomor surat pesanan', 'nilai' => $nomorSp],
                    'nomor_spk'           => ['label' => 'Nomor SPK', 'nilai' => $nomorSpk],
                ]
                : [
                    'nomor_sk_tim' => ['label' => 'Nomor SK Tim', 'nilai' => $nomorSkTim],
                ];

            $kodeRup = (string) $rincian['kode_rup'];
            $syaratExclude = $edit !== null ? ' AND r.id <> :exclude' : '';

            foreach ($dokumenRup as $kolom => $dokumen) {
                if ($dokumen['nilai'] === '') {
                    continue;
                }

                $stmt = $pdo->prepare(
                    'SELECT DISTINCT r.' . $kolom . '
                    FROM realisasi_anggaran AS r
                    INNER JOIN rincian_anggaran AS ra ON ra.id = r.rincian_anggaran_id
                    WHERE ra.kode_rup = :rup
                    AND r.metode = :metode
                    AND r.status <> \'DIBATALKAN\'
                    AND r.' . $kolom . ' IS NOT NULL
                    AND r.' . $kolom . ' <> \'\'' . $syaratExclude
                );
                $params = [':rup' => $kodeRup, ':metode' => $metode];

                if ($edit !== null) {
                    $params[':exclude'] = $editId;
                }

                $stmt->execute($params);
                $nomorPadaRup = $stmt->fetchAll(PDO::FETCH_COLUMN);

                if ($nomorPadaRup !== [] && !in_array($dokumen['nilai'], $nomorPadaRup, true)) {
                    throw new RuntimeException(
                        $dokumen['label'] . ' untuk kode RUP ' . $kodeRup
                        . ' harus sama dengan yang sudah tercatat ('
                        . implode(', ', $nomorPadaRup) . ').'
                    );
                }

                $stmt = $pdo->prepare(
                    'SELECT DISTINCT ra.kode_rup
                    FROM realisasi_anggaran AS r
                    INNER JOIN rincian_anggaran AS ra ON ra.id = r.rincian_anggaran_id
                    WHERE r.' . $kolom . ' = :nomor
                    AND ra.kode_rup <> :rup
                    AND r.status <> \'DIBATALKAN\'' . $syaratExclude
                );
                $params = [':nomor' => $dokumen['nilai'], ':rup' => $kodeRup];

                if ($edit !== null) {
                    $params[':exclude'] = $editId;
                }

                $stmt->execute($params);
                $rupLain = $stmt->fetchAll(PDO::FETCH_COLUMN);

                if ($rupLain !== []) {
                    throw new RuntimeException(
                        $dokumen['label'] . ' ' . $dokumen['nilai']
                        . ' sudah dipakai pada kode RUP lain (' . implode(', ', $rupLain) . '). '
                        . 'Satu nomor hanya boleh digunakan untuk satu kode RUP.'
                    );
                }
            }

            $data = [
                ':rincian_id' => $rincianId,
                ':metode' => $metode,
                ':penyedia_id' => $penyediaId,
                ':tipe_swakelola' => $tipeSwakelola !== '' ? $tipeSwakelola : null,
                ':pelaksana_swakelola' => $pelaksanaSwakelola !== '' ? $pelaksanaSwakelola : null,
                ':nomor_sk_tim' => $nomorSkTim !== '' ? $nomorSkTim : null,
                ':tanggal_sk_tim' => $tgl['tanggal_sk_tim'],
                ':nomor_kontrak' => $nomorKontrak !== '' ? $nomorKontrak : null,
                ':tanggal_kontrak' => $tgl['tanggal_kontrak'],
                ':nomor_sp' => $nomorSp !== '' ? $nomorSp : null,
                ':tanggal_sp' => $tgl['tanggal_surat_pesanan'],
                ':nomor_spk' => $nomorSpk !== '' ? $nomorSpk : null,
                ':tanggal_spk' => $tgl['tanggal_spk'],
                ':nilai' => $nilaiInput,
                ':tanggal_mulai' => $tgl['tanggal_mulai'],
                ':tanggal_selesai' => $tgl['tanggal_selesai'],
                ':nomor_bast' => $nomorBast !== '' ? $nomorBast : null,
                ':tanggal_bast' => $tgl['tanggal_bast'],
                ':status' => $status,
                ':catatan' => $catatan !== '' ? $catatan : null,
            ];

            if ($edit === null) {
                $stmt = $pdo->prepare(
                    'INSERT INTO realisasi_anggaran (
                    rincian_anggaran_id, metode, penyedia_id,
                    tipe_swakelola, pelaksana_swakelola,
                    nomor_sk_tim, tanggal_sk_tim,
                    nomor_kontrak, tanggal_kontrak,
                    nomor_surat_pesanan, tanggal_surat_pesanan,
                    nomor_spk, tanggal_spk,
                    nilai_realisasi,
                    tanggal_mulai, tanggal_selesai,
                    nomor_bast, tanggal_bast,
                    status, catatan
                    ) VALUES (
                    :rincian_id, :metode, :penyedia_id,
                    :tipe_swakelola, :pelaksana_swakelola,
                    :nomor_sk_tim, :tanggal_sk_tim,
                    :nomor_kontrak, :tanggal_kontrak,
                    :nomor_sp, :tanggal_sp,
                    :nomor_spk, :tanggal_spk,
                    :nilai,
                    :tanggal_mulai, :tanggal_selesai,
                    :nomor_bast, :tanggal_bast,
                    :status, :catatan
                    )'
                );
                $stmt->execute($data);

                $pesan = 'Realisasi anggaran berhasil disimpan.';
            } else {
                $stmt = $pdo->prepare(
                    'UPDATE realisasi_anggaran SET
                    rincian_anggaran_id = :rincian_id,
                    metode = :metode,
                    penyedia_id = :penyedia_id,
                    tipe_swakelola = :tipe_swakelola,
                    pelaksana_swakelola = :pelaksana_swakelola,
                    nomor_sk_tim = :nomor_sk_tim,
                    tanggal_sk_tim = :tanggal_sk_tim,
                    nomor_kontrak = :nomor_kontrak,
                    tanggal_kontrak = :tanggal_kontrak,
                    nomor_surat_pesanan = :nomor_sp,
                    tanggal_surat_pesanan = :tanggal_sp,
                    nomor_spk = :nomor_spk,
                    tanggal_spk = :tanggal_spk,
                    nilai_realisasi = :nilai,
                    tanggal_mulai = :tanggal_mulai,
                    tanggal_selesai = :tanggal_selesai,
                    nomor_bast = :nomor_bast,
                    tanggal_bast = :tanggal_bast,
                    status = :status,
                    catatan = :catatan
                    WHERE id = :id'
                );
                $stmt->execute($data + [':id' => $editId]);

                $pesan = 'Realisasi anggaran berhasil diperbarui.';
            }

            $pdo->commit();

            setFlash('success', $pesan);
            redirect(url('pages/realisasi.php'));
        } catch (RuntimeException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = $e->getMessage();
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log($e->getMessage());
            $errors[] = $e->getCode() === '23000'
                ? 'Data tidak valid (relasi atau aturan data dilanggar).'
                : 'Realisasi anggaran gagal disimpan. Periksa log PHP.';
        }
    }
}

// =====================================================================
// DATA PENDUKUNG
// =====================================================================

// Rincian anggaran + sisa pagu. Item hanya boleh dipilih bila belum
// direalisasikan, atau realisasi terakhirnya sudah dibayar uang muka/termin
// dan belum dilunasi. Item yang sudah lunas tidak ditampilkan lagi.
$rincianSemua = $pdo->query(
    "SELECT
    ra.id,
    ra.kode_rup,
    ra.uraian,
    ra.total_pagu,
    ra.total_pagu - COALESCE((
        SELECT SUM(r.nilai_realisasi)
        FROM realisasi_anggaran AS r
        WHERE r.rincian_anggaran_id = ra.id
        AND r.status <> 'DIBATALKAN'
    ), 0) AS sisa_pagu,
    sk.kode_sub_kegiatan,
    CASE
        WHEN NOT EXISTS (
            SELECT 1 FROM realisasi_anggaran AS rx
            WHERE rx.rincian_anggaran_id = ra.id
            AND rx.status <> 'DIBATALKAN'
        ) THEN 1
        WHEN EXISTS (
            SELECT 1
            FROM realisasi_anggaran AS rl
            INNER JOIN realisasi_pembayaran AS pl ON pl.realisasi_id = rl.id
            WHERE rl.id = (
                SELECT MAX(r2.id)
                FROM realisasi_anggaran AS r2
                WHERE r2.rincian_anggaran_id = ra.id
                AND r2.status <> 'DIBATALKAN'
            )
            AND pl.jenis IN ('UANG_MUKA', 'TERMIN')
        )
        AND NOT EXISTS (
            SELECT 1
            FROM realisasi_anggaran AS rp
            INNER JOIN realisasi_pembayaran AS pp ON pp.realisasi_id = rp.id
            WHERE rp.rincian_anggaran_id = ra.id
            AND rp.status <> 'DIBATALKAN'
            AND pp.jenis = 'PELUNASAN'
        ) THEN 1
        ELSE 0
    END AS boleh_dipilih
    FROM rincian_anggaran AS ra
    INNER JOIN sub_kegiatan AS sk ON sk.id = ra.sub_kegiatan_id
    WHERE ra.status <> 'DIBATALKAN'
    ORDER BY ra.kode_rup ASC, ra.id ASC"
)->fetchAll();

$rincianList = array_values(array_filter(
    $rincianSemua,
    static function (array $r) use ($edit): bool {
        if ($edit !== null && (int) $r['id'] === (int) $edit['rincian_anggaran_id']) {
            return true;
        }

        return (int) $r['boleh_dipilih'] === 1 && (float) $r['sisa_pagu'] > 0.005;
    }
));

// Dokumen kontrak terakhir per kode RUP, untuk mengisi otomatis formulir
$dokumenRup = [];

$stmt = $pdo->query(
    "SELECT
    ra.kode_rup,
    r.nomor_kontrak, r.tanggal_kontrak,
    r.nomor_surat_pesanan, r.tanggal_surat_pesanan,
    r.nomor_spk, r.tanggal_spk,
    r.nomor_sk_tim, r.tanggal_sk_tim
    FROM realisasi_anggaran AS r
    INNER JOIN rincian_anggaran AS ra ON ra.id = r.rincian_anggaran_id
    WHERE r.status <> 'DIBATALKAN'
    ORDER BY r.id ASC"
);

foreach ($stmt as $dok) {
    $dokumenRup[$dok['kode_rup']] = $dok;
}

// Penyedia aktif
$penyediaList = $pdo->query(
    'SELECT id, nama_penyedia, npwp
    FROM master_penyedia
    WHERE aktif = 1
    ORDER BY nama_penyedia ASC'
)->fetchAll();

// Filter daftar realisasi
$cari = trim((string) ($_GET['q'] ?? ''));
$filterStatus = (string) ($_GET['status'] ?? '');

if (!in_array($filterStatus, ['DRAFT', 'BERJALAN', 'SELESAI', 'DIBATALKAN'], true)) {
    $filterStatus = '';
}

$sqlDaftar = "SELECT
    r.*,
    ra.kode_rup,
    ra.uraian,
    p.nama_penyedia,
    COALESCE(b.total_dibayar, 0) AS total_dibayar
    FROM realisasi_anggaran AS r
    INNER JOIN rincian_anggaran AS ra ON ra.id = r.rincian_anggaran_id
    LEFT JOIN master_penyedia AS p ON p.id = r.penyedia_id
    LEFT JOIN (
        SELECT realisasi_id, SUM(jumlah_dibayar) AS total_dibayar
        FROM realisasi_pembayaran
        GROUP BY realisasi_id
    ) AS b ON b.realisasi_id = r.id
    WHERE 1 = 1";

$paramsDaftar = [];

if ($cari !== '') {
    $sqlDaftar .= ' AND (
        ra.kode_rup LIKE :cari1
        OR ra.uraian LIKE :cari2
        OR p.nama_penyedia LIKE :cari3
        OR r.nomor_kontrak LIKE :cari4
    )';

    for ($i = 1; $i <= 4; $i++) {
        $paramsDaftar[':cari' . $i] = '%' . $cari . '%';
    }
}

if ($filterStatus !== '') {
    $sqlDaftar .= ' AND r.status = :status';
    $paramsDaftar[':status'] = $filterStatus;
}

$sqlDaftar .= ' ORDER BY r.id DESC';

$stmt = $pdo->prepare($sqlDaftar);
$stmt->execute($paramsDaftar);
$dataRealisasi = $stmt->fetchAll();

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<main class="main-content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Realisasi Anggaran</h2>
            <p class="page-description">
                Catat pelaksanaan belanja melalui penyedia atau swakelola,
                lengkap dengan dokumen kontrak, jangka waktu, dan serah terima.
            </p>
        </div>

        <?php if ($edit !== null): ?>
            <div class="page-actions">
                <a class="btn btn-light" href="<?= e(url('pages/realisasi.php')) ?>">
                    Batal Ubah
                </a>
            </div>
        <?php endif; ?>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $msg): ?>
                <div><?= e($msg) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!canManage()): ?>
        <div class="alert alert-info">
            Peran Anda hanya dapat melihat data. Penambahan dan perubahan
            realisasi memerlukan peran Administrator atau Operator.
        </div>
    <?php endif; ?>

    <?php if (canManage()): ?>
        <!-- ================= FORM PENYEDIA ================= -->
        <section class="card">
            <div class="card-header">
                <h3>Tambah Penyedia</h3>
            </div>

            <div class="card-body">
                <form method="post" action="<?= e(url('pages/realisasi.php')) ?>">
                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                    <input type="hidden" name="aksi" value="penyedia">

                    <div class="form-grid">
                        <div class="form-group full">
                            <label for="nama_penyedia">Nama Penyedia *</label>
                            <input
                                type="text"
                                id="nama_penyedia"
                                name="nama_penyedia"
                                maxlength="200"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="npwp">NPWP</label>
                            <input type="text" id="npwp" name="npwp" maxlength="30">
                        </div>

                        <div class="form-group">
                            <label for="nama_pimpinan">Nama Pimpinan</label>
                            <input
                                type="text"
                                id="nama_pimpinan"
                                name="nama_pimpinan"
                                maxlength="150"
                            >
                        </div>

                        <div class="form-group full">
                            <label for="alamat">Alamat</label>
                            <textarea id="alamat" name="alamat"></textarea>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Simpan Penyedia</button>
                    </div>
                </form>
            </div>
        </section>
    <?php endif; ?>

    <!-- ================= FORM REALISASI ================= -->
    <section class="card">
        <div class="card-header">
            <h3>
                <?= $edit !== null
                    ? 'Ubah Realisasi Anggaran'
                    : 'Formulir Realisasi Anggaran' ?>
            </h3>

            <?php if ($edit !== null): ?>
                <?= statusBadge($edit['status']) ?>
            <?php endif; ?>
        </div>

        <div class="card-body">
            <?php if (!$edit && empty($rincianList)): ?>
                <p class="text-muted">
                    Belum ada rincian anggaran yang dapat direalisasikan. Item yang
                    sudah lunas, atau sudah direalisasikan tetapi belum dibayar
                    uang muka/termin, tidak ditampilkan.
                </p>
            <?php elseif (!canManage()): ?>
                <p class="text-muted">
                    Hanya Administrator dan Operator yang dapat menambah atau
                    mengubah realisasi.
                </p>
            <?php else: ?>
                <?php if ($edit === null): ?>
                    <p class="text-muted">
                        Untuk menambah penyedia baru, gunakan formulir Tambah Penyedia
                        di atas.
                    </p>
                <?php elseif ($kunciRincian): ?>
                    <div class="alert alert-info">
                        Realisasi ini sudah memiliki pembayaran. Rincian anggaran
                        dikunci dan nilai realisasi tidak boleh lebih kecil dari
                        total pembayaran (<?= e(rupiah($totalDibayarEdit)) ?>).
                    </div>
                <?php endif; ?>

                <form
                    method="post"
                    action="<?= e(url('pages/realisasi.php')) ?>"
                    id="formRealisasi"
                >
                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                    <input type="hidden" name="aksi" value="realisasi">

                    <?php if ($edit !== null): ?>
                        <input type="hidden" name="id" value="<?= (int) $edit['id'] ?>">
                    <?php endif; ?>

                    <div class="form-grid">
                        <div class="form-group full">
                            <label for="rincian_anggaran_id">Rincian Anggaran (Kode RUP) *</label>

                            <?php if ($kunciRincian): ?>
                                <input
                                    type="hidden"
                                    name="rincian_anggaran_id"
                                    value="<?= (int) $edit['rincian_anggaran_id'] ?>"
                                >
                            <?php endif; ?>

                            <select
                                id="rincian_anggaran_id"
                                name="rincian_anggaran_id"
                                required
                                <?= $kunciRincian ? 'disabled' : '' ?>
                            >
                                <option value="">-- Pilih Rincian Anggaran --</option>

                                <?php foreach ($rincianList as $r): ?>
                                    <?php $dok = $dokumenRup[$r['kode_rup']] ?? []; ?>
                                    <option
                                        value="<?= e($r['id']) ?>"
                                        data-kontrak="<?= e((string) ($dok['nomor_kontrak'] ?? '')) ?>"
                                        data-tanggal-kontrak="<?= e((string) ($dok['tanggal_kontrak'] ?? '')) ?>"
                                        data-sp="<?= e((string) ($dok['nomor_surat_pesanan'] ?? '')) ?>"
                                        data-tanggal-sp="<?= e((string) ($dok['tanggal_surat_pesanan'] ?? '')) ?>"
                                        data-spk="<?= e((string) ($dok['nomor_spk'] ?? '')) ?>"
                                        data-tanggal-spk="<?= e((string) ($dok['tanggal_spk'] ?? '')) ?>"
                                        data-sk-tim="<?= e((string) ($dok['nomor_sk_tim'] ?? '')) ?>"
                                        data-tanggal-sk-tim="<?= e((string) ($dok['tanggal_sk_tim'] ?? '')) ?>"
                                        <?= $selected('rincian_anggaran_id', (string) $r['id']) ?>
                                    >
                                        <?= e($r['kode_rup']) ?>
                                        - <?= e($r['uraian']) ?>
                                        | Sisa pagu: <?= e(rupiah($r['sisa_pagu'])) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                            <small>
                                Hanya item yang belum direalisasikan atau sudah dibayar
                                uang muka/termin yang ditampilkan. Item yang sudah lunas
                                tidak muncul lagi.
                            </small>

                            <?php if ($kunciRincian): ?>
                                <small>Rincian terkunci karena sudah ada pembayaran.</small>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="metode">Metode Pelaksanaan *</label>

                            <select id="metode" name="metode" required>
                                <option value="">-- Pilih Metode --</option>
                                <option value="PENYEDIA" <?= $selected('metode', 'PENYEDIA') ?>>Penyedia</option>
                                <option value="SWAKELOLA" <?= $selected('metode', 'SWAKELOLA') ?>>Swakelola</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="nilai_realisasi">Nilai Realisasi (termasuk pajak) *</label>
                            <input
                                type="number"
                                id="nilai_realisasi"
                                name="nilai_realisasi"
                                min="0.01"
                                step="0.01"
                                value="<?= $old('nilai_realisasi') ?>"
                                required
                            >
                        </div>

                        <!-- ====== BLOK PENYEDIA ====== -->
                        <div class="form-group full" id="blokPenyedia" style="display:none">
                            <div class="form-grid">
                                <div class="form-group full">
                                    <label for="penyedia_id">Nama Penyedia *</label>

                                    <select id="penyedia_id" name="penyedia_id">
                                        <option value="">-- Pilih Penyedia --</option>

                                        <?php foreach ($penyediaList as $p): ?>
                                            <option
                                                value="<?= e($p['id']) ?>"
                                                <?= $selected('penyedia_id', (string) $p['id']) ?>
                                            >
                                                <?= e($p['nama_penyedia']) ?>
                                                <?= $p['npwp'] ? '(' . e($p['npwp']) . ')' : '' ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <small>
                                        Isi minimal satu dokumen di bawah (kontrak,
                                        surat pesanan, atau SPK).
                                    </small>
                                </div>

                                <div class="form-group">
                                    <label for="nomor_kontrak">Nomor Kontrak</label>
                                    <input
                                        type="text"
                                        id="nomor_kontrak"
                                        name="nomor_kontrak"
                                        maxlength="100"
                                        value="<?= $old('nomor_kontrak') ?>"
                                    >
                                    <small>
                                        Satu nomor kontrak untuk satu kode RUP dan harus
                                        sama untuk semua item dalam RUP tersebut.
                                    </small>
                                </div>

                                <div class="form-group">
                                    <label for="tanggal_kontrak">Tanggal Kontrak</label>
                                    <input
                                        type="date"
                                        id="tanggal_kontrak"
                                        name="tanggal_kontrak"
                                        value="<?= $old('tanggal_kontrak') ?>"
                                    >
                                </div>

                                <div class="form-group">
                                    <label for="nomor_surat_pesanan">Nomor Surat Pesanan</label>
                                    <input
                                        type="text"
                                        id="nomor_surat_pesanan"
                                        name="nomor_surat_pesanan"
                                        maxlength="100"
                                        value="<?= $old('nomor_surat_pesanan') ?>"
                                    >
                                </div>

                                <div class="form-group">
                                    <label for="tanggal_surat_pesanan">Tanggal Surat Pesanan</label>
                                    <input
                                        type="date"
                                        id="tanggal_surat_pesanan"
                                        name="tanggal_surat_pesanan"
                                        value="<?= $old('tanggal_surat_pesanan') ?>"
                                    >
                                </div>

                                <div class="form-group">
                                    <label for="nomor_spk">Nomor SPK</label>
                                    <input
                                        type="text"
                                        id="nomor_spk"
                                        name="nomor_spk"
                                        maxlength="100"
                                        value="<?= $old('nomor_spk') ?>"
                                    >
                                </div>

                                <div class="form-group">
                                    <label for="tanggal_spk">Tanggal SPK</label>
                                    <input
                                        type="date"
                                        id="tanggal_spk"
                                        name="tanggal_spk"
                                        value="<?= $old('tanggal_spk') ?>"
                                    >
                                </div>
                            </div>
                        </div>

                        <!-- ====== BLOK SWAKELOLA ====== -->
                        <div class="form-group full" id="blokSwakelola" style="display:none">
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="tipe_swakelola">Tipe Swakelola *</label>

                                    <select id="tipe_swakelola" name="tipe_swakelola">
                                        <option value="">-- Pilih Tipe --</option>
                                        <option value="I" <?= $selected('tipe_swakelola', 'I') ?>>Tipe I - K/L/PD sendiri</option>
                                        <option value="II" <?= $selected('tipe_swakelola', 'II') ?>>Tipe II - K/L/PD lain</option>
                                        <option value="III" <?= $selected('tipe_swakelola', 'III') ?>>Tipe III - Ormas</option>
                                        <option value="IV" <?= $selected('tipe_swakelola', 'IV') ?>>Tipe IV - Kelompok masyarakat</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="pelaksana_swakelola">Pelaksana Swakelola *</label>
                                    <input
                                        type="text"
                                        id="pelaksana_swakelola"
                                        name="pelaksana_swakelola"
                                        maxlength="200"
                                        value="<?= $old('pelaksana_swakelola') ?>"
                                    >
                                </div>

                                <div class="form-group">
                                    <label for="nomor_sk_tim">Nomor SK Tim Swakelola</label>
                                    <input
                                        type="text"
                                        id="nomor_sk_tim"
                                        name="nomor_sk_tim"
                                        maxlength="100"
                                        value="<?= $old('nomor_sk_tim') ?>"
                                    >
                                </div>

                                <div class="form-group">
                                    <label for="tanggal_sk_tim">Tanggal SK Tim</label>
                                    <input
                                        type="date"
                                        id="tanggal_sk_tim"
                                        name="tanggal_sk_tim"
                                        value="<?= $old('tanggal_sk_tim') ?>"
                                    >
                                </div>
                            </div>
                        </div>

                        <!-- ====== JANGKA WAKTU ====== -->
                        <div class="form-group">
                            <label for="tanggal_mulai">Tanggal Mulai *</label>
                            <input
                                type="date"
                                id="tanggal_mulai"
                                name="tanggal_mulai"
                                value="<?= $old('tanggal_mulai') ?>"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="tanggal_selesai">Tanggal Berakhir *</label>
                            <input
                                type="date"
                                id="tanggal_selesai"
                                name="tanggal_selesai"
                                value="<?= $old('tanggal_selesai') ?>"
                                required
                            >
                        </div>

                        <div class="form-group full">
                            <label for="lama_hari">Lama Pekerjaan (hari kalender)</label>
                            <input
                                type="text"
                                id="lama_hari"
                                readonly
                                placeholder="Terisi otomatis"
                            >
                        </div>

                        <!-- ====== BAST ====== -->
                        <div class="form-group">
                            <label for="nomor_bast">Nomor BAST</label>
                            <input
                                type="text"
                                id="nomor_bast"
                                name="nomor_bast"
                                maxlength="100"
                                value="<?= $old('nomor_bast') ?>"
                            >
                        </div>

                        <div class="form-group">
                            <label for="tanggal_bast">Tanggal BAST</label>
                            <input
                                type="date"
                                id="tanggal_bast"
                                name="tanggal_bast"
                                value="<?= $old('tanggal_bast') ?>"
                            >
                        </div>

                        <div class="form-group">
                            <label for="status">Status *</label>

                            <select id="status" name="status" required>
                                <option value="BERJALAN" <?= $selected('status', 'BERJALAN') ?>>Berjalan</option>
                                <option value="DRAFT" <?= $selected('status', 'DRAFT') ?>>Draft</option>
                                <option value="SELESAI" <?= $selected('status', 'SELESAI') ?>>Selesai (wajib BAST)</option>
                            </select>
                        </div>

                        <div class="form-group full">
                            <label for="catatan">Catatan</label>
                            <textarea id="catatan" name="catatan"><?= $old('catatan') ?></textarea>
                        </div>
                    </div>

                    <p class="text-muted">* Wajib diisi.</p>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">
                            <?= $edit !== null
                                ? 'Simpan Perubahan'
                                : 'Simpan Realisasi Anggaran' ?>
                        </button>

                        <?php if ($edit !== null): ?>
                            <a class="btn btn-light" href="<?= e(url('pages/realisasi.php')) ?>">
                                Batal
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </section>

    <!-- ================= DAFTAR ================= -->
    <section class="card">
        <div class="card-header">
            <h3>Daftar Realisasi Anggaran</h3>
            <span><?= count($dataRealisasi) ?> data</span>
        </div>

        <div class="card-body">
            <form method="get" action="<?= e(url('pages/realisasi.php')) ?>" class="filter-bar">
                <div class="form-group">
                    <label for="q">Cari</label>
                    <input
                        type="text"
                        id="q"
                        name="q"
                        value="<?= e($cari) ?>"
                        placeholder="Kode RUP, uraian, penyedia, atau nomor kontrak"
                    >
                </div>

                <div class="form-group">
                    <label for="filter_status">Status</label>
                    <select id="filter_status" name="status" data-auto-submit>
                        <option value="">Semua Status</option>
                        <?php foreach (['DRAFT' => 'Draft', 'BERJALAN' => 'Berjalan', 'SELESAI' => 'Selesai', 'DIBATALKAN' => 'Dibatalkan'] as $kode => $label): ?>
                            <option value="<?= e($kode) ?>" <?= $filterStatus === $kode ? 'selected' : '' ?>>
                                <?= e($label) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <button type="submit" class="btn btn-sm">Cari</button>
                <a class="btn btn-outline-dark btn-sm" href="<?= e(url('pages/realisasi.php')) ?>">Reset</a>
            </form>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Kode RUP</th>
                            <th>Uraian</th>
                            <th>Metode</th>
                            <th>Pelaksana</th>
                            <th>Periode</th>
                            <th class="num">Nilai Realisasi</th>
                            <th class="num">Dibayar</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if (empty($dataRealisasi)): ?>
                            <tr>
                                <td colspan="10" class="text-center text-muted">
                                    Belum ada realisasi anggaran yang cocok.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($dataRealisasi as $i => $row): ?>
                                <tr>
                                    <td><?= $i + 1 ?></td>
                                    <td><?= e($row['kode_rup']) ?></td>
                                    <td><?= e($row['uraian']) ?></td>
                                    <td><?= e($row['metode'] === 'PENYEDIA' ? 'Penyedia' : 'Swakelola') ?></td>
                                    <td>
                                        <?php if ($row['metode'] === 'PENYEDIA'): ?>
                                            <?= e($row['nama_penyedia'] ?? '-') ?>
                                        <?php else: ?>
                                            <?= e($row['pelaksana_swakelola'] ?? '-') ?>
                                            (Tipe <?= e($row['tipe_swakelola'] ?? '-') ?>)
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?= e(tanggalIndo($row['tanggal_mulai'])) ?>
                                        s.d.
                                        <?= e(tanggalIndo($row['tanggal_selesai'])) ?>
                                        <?php if (!empty($row['lama_hari'])): ?>
                                            <br><small><?= e($row['lama_hari']) ?> hari</small>
                                        <?php endif; ?>
                                    </td>
                                    <td class="num"><?= e(rupiah($row['nilai_realisasi'])) ?></td>
                                    <td class="num"><?= e(rupiah($row['total_dibayar'])) ?></td>
                                    <td><?= statusBadge($row['status']) ?></td>
                                    <td>
                                        <div class="actions">
                                            <a
                                                class="btn btn-light btn-sm"
                                                href="<?= e(url('pages/anggaran_detail.php?id=' . (int) $row['rincian_anggaran_id'])) ?>"
                                            >Detail</a>

                                            <?php if (canManage() && $row['status'] !== 'DIBATALKAN'): ?>
                                                <a
                                                    class="btn btn-light btn-sm"
                                                    href="<?= e(url('pages/realisasi.php?edit=' . (int) $row['id'])) ?>"
                                                >Ubah</a>

                                                <form
                                                    method="post"
                                                    action="<?= e(url('pages/realisasi.php')) ?>"
                                                    data-confirm="Batalkan realisasi ini? Data tetap tersimpan dengan status Dibatalkan."
                                                >
                                                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                                    <input type="hidden" name="aksi" value="batal">
                                                    <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                                                    <button type="submit" class="btn btn-outline-dark btn-sm">Batalkan</button>
                                                </form>
                                            <?php endif; ?>

                                            <?php if (canManage() && (float) $row['total_dibayar'] <= 0): ?>
                                                <form
                                                    method="post"
                                                    action="<?= e(url('pages/realisasi.php')) ?>"
                                                    data-confirm="Hapus realisasi ini permanen? Tindakan tidak dapat dibatalkan."
                                                >
                                                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                                    <input type="hidden" name="aksi" value="hapus">
                                                    <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <script>
    (function () {
        var metode = document.getElementById('metode');

        if (!metode) { return; }

        var blokPenyedia = document.getElementById('blokPenyedia');
        var blokSwakelola = document.getElementById('blokSwakelola');
        var mulai = document.getElementById('tanggal_mulai');
        var selesai = document.getElementById('tanggal_selesai');
        var lama = document.getElementById('lama_hari');
        var rincian = document.getElementById('rincian_anggaran_id');

        function updateDokumen() {
            if (!rincian || rincian.disabled) { return; }

            var opt = rincian.options[rincian.selectedIndex];

            if (!opt || opt.value === '') { return; }

            var fields = {
                nomor_kontrak: opt.getAttribute('data-kontrak') || '',
                tanggal_kontrak: opt.getAttribute('data-tanggal-kontrak') || '',
                nomor_surat_pesanan: opt.getAttribute('data-sp') || '',
                tanggal_surat_pesanan: opt.getAttribute('data-tanggal-sp') || '',
                nomor_spk: opt.getAttribute('data-spk') || '',
                tanggal_spk: opt.getAttribute('data-tanggal-spk') || '',
                nomor_sk_tim: opt.getAttribute('data-sk-tim') || '',
                tanggal_sk_tim: opt.getAttribute('data-tanggal-sk-tim') || ''
            };

            Object.keys(fields).forEach(function (id) {
                var el = document.getElementById(id);

                if (el) {
                    el.value = fields[id];
                }
            });
        }

        function toggleBlok(blok, aktif) {
            blok.style.display = aktif ? '' : 'none';
            blok.querySelectorAll('input, select, textarea').forEach(function (el) {
                el.disabled = !aktif;
            });
        }

        function updateMetode() {
            toggleBlok(blokPenyedia, metode.value === 'PENYEDIA');
            toggleBlok(blokSwakelola, metode.value === 'SWAKELOLA');

            document.getElementById('penyedia_id').required = metode.value === 'PENYEDIA';
            document.getElementById('tipe_swakelola').required = metode.value === 'SWAKELOLA';
            document.getElementById('pelaksana_swakelola').required = metode.value === 'SWAKELOLA';
        }

        function updateLama() {
            if (!mulai.value || !selesai.value) {
                lama.value = '';
                return;
            }

            var a = new Date(mulai.value + 'T00:00:00');
            var b = new Date(selesai.value + 'T00:00:00');
            var hari = Math.round((b - a) / 86400000) + 1;

            lama.value = hari > 0 ? hari + ' hari kalender' : 'Tanggal tidak valid';
        }

        metode.addEventListener('change', updateMetode);
        mulai.addEventListener('change', updateLama);
        selesai.addEventListener('change', updateLama);

        if (rincian) {
            rincian.addEventListener('change', updateDokumen);
        }

        updateMetode();
        updateLama();
    })();
    </script>
</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
