<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

requireLogin();

$pageTitle = 'Rincian Anggaran';
$currentPage = 'anggaran';

$errors = [];
$edit = null;

$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);

if (is_int($editId) && $editId > 0) {
    $stmt = $pdo->prepare(
        'SELECT id, sub_kegiatan_id, rekening_id, satuan_id, kode_rup, uraian,
                kategori_belanja, volume, harga_satuan, kena_ppn, tarif_ppn,
                status, catatan
        FROM rincian_anggaran
        WHERE id = :id'
    );
    $stmt->execute([':id' => $editId]);
    $edit = $stmt->fetch() ?: null;

    if ($edit === null) {
        setFlash('warning', 'Rincian anggaran yang ingin diubah tidak ditemukan.');
        redirect(url('pages/anggaran.php'));
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf($_POST['csrf_token'] ?? null);
    requireManage();

    $aksi = (string) ($_POST['aksi'] ?? 'simpan');

    if ($aksi === 'hapus') {
        $hapusId = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);

        if (!is_int($hapusId) || $hapusId < 1) {
            setFlash('danger', 'Data rincian anggaran tidak valid.');
        } else {
            $stmt = $pdo->prepare('SELECT kode_rup FROM rincian_anggaran WHERE id = :id');
            $stmt->execute([':id' => $hapusId]);
            $kodeRup = $stmt->fetchColumn();

            $stmt = $pdo->prepare(
                'SELECT COUNT(*) FROM realisasi_anggaran WHERE rincian_anggaran_id = :id'
            );
            $stmt->execute([':id' => $hapusId]);
            $jumlahRealisasi = (int) $stmt->fetchColumn();

            if ($kodeRup === false) {
                setFlash('warning', 'Rincian anggaran tidak ditemukan.');
            } elseif ($jumlahRealisasi > 0) {
                setFlash(
                    'danger',
                    'Rincian anggaran tidak dapat dihapus karena memiliki '
                    . $jumlahRealisasi . ' data realisasi.'
                );
            } else {
                $stmt = $pdo->prepare('DELETE FROM rincian_anggaran WHERE id = :id');
                $stmt->execute([':id' => $hapusId]);
                setFlash('success', 'Rincian anggaran ' . $kodeRup . ' berhasil dihapus.');
            }
        }

        redirect(url('pages/anggaran.php'));
    }

    $subKegiatanId = filter_var($_POST['sub_kegiatan_id'] ?? null, FILTER_VALIDATE_INT);
    $rekeningId = filter_var($_POST['rekening_id'] ?? null, FILTER_VALIDATE_INT);
    $satuanId = filter_var($_POST['satuan_id'] ?? null, FILTER_VALIDATE_INT);
    $status = (string) ($_POST['status'] ?? 'DRAFT');

    $kodeRup = trim((string) ($_POST['kode_rup'] ?? ''));
    $uraian = trim((string) ($_POST['uraian'] ?? ''));
    $kategoriBelanja = (string) ($_POST['kategori_belanja'] ?? '');
    $volumeInput = trim((string) ($_POST['volume'] ?? ''));
    $hargaInput = trim((string) ($_POST['harga_satuan'] ?? ''));
    $kenaPpnInput = $_POST['kena_ppn'] ?? '';
    $tarifInput = trim((string) ($_POST['tarif_ppn'] ?? '11'));
    $catatan = trim((string) ($_POST['catatan'] ?? ''));

    $volumeValid = $volumeInput !== '' && is_numeric($volumeInput);
    $hargaValid = $hargaInput !== '' && is_numeric($hargaInput);
    $tarifValid = $tarifInput !== '' && is_numeric($tarifInput);

    $volume = $volumeValid ? (float) $volumeInput : 0.0;
    $hargaSatuan = $hargaValid ? (float) $hargaInput : 0.0;
    $tarifPpn = $tarifValid ? (float) $tarifInput : 0.0;
    $kenaPpn = filter_var($kenaPpnInput, FILTER_VALIDATE_INT);

    if (
        !is_int($subKegiatanId) || $subKegiatanId < 1 ||
        !is_int($rekeningId) || $rekeningId < 1 ||
        !is_int($satuanId) || $satuanId < 1
    ) {
        $errors[] = 'Sub kegiatan, rekening, dan satuan wajib dipilih.';
    }

    if ($kodeRup === '' || mb_strlen($kodeRup) > 60) {
        $errors[] = 'Kode RUP wajib diisi (maksimal 60 karakter).';
    }

    if ($uraian === '' || mb_strlen($uraian) > 500) {
        $errors[] = 'Uraian belanja wajib diisi (maksimal 500 karakter).';
    }

    if (!array_key_exists($kategoriBelanja, kategoriBelanjaOptions())) {
        $errors[] = 'Kategori belanja wajib dipilih.';
    }

    if (!$volumeValid || $volume <= 0 || $volume > 99_999_999_999_999.9999) {
        $errors[] = 'Volume harus berupa angka lebih besar dari nol.';
    }

    if (!$hargaValid || $hargaSatuan < 0) {
        $errors[] = 'Harga satuan harus berupa angka nol atau lebih.';
    }

    if ($kenaPpn !== 0 && $kenaPpn !== 1) {
        $errors[] = 'Pilihan PPN tidak valid.';
    }

    if (!$tarifValid || $tarifPpn < 0 || $tarifPpn > 100) {
        $errors[] = 'Tarif PPN harus berada antara 0 dan 100 persen.';
    }

    if (!in_array($status, ['DRAFT', 'AKTIF', 'DIBATALKAN'], true)) {
        $errors[] = 'Status rincian tidak valid.';
    }

    if (empty($errors)) {
        $totalDasar = round($volume * $hargaSatuan, 2);
        $nilaiPpn = $kenaPpn === 1 ? round($totalDasar * $tarifPpn / 100, 2) : 0.0;
        $totalPagu = round($totalDasar + $nilaiPpn, 2);

        try {
            $realisasiLama = 0.0;

            if ($edit !== null) {
                $stmt = $pdo->prepare(
                    "SELECT COALESCE(SUM(nilai_realisasi), 0)
                    FROM realisasi_anggaran
                    WHERE rincian_anggaran_id = :id AND status <> 'DIBATALKAN'"
                );
                $stmt->execute([':id' => (int) $edit['id']]);
                $realisasiLama = (float) $stmt->fetchColumn();

                if ($totalPagu + 0.005 < $realisasiLama) {
                    $errors[] = 'Total pagu baru (' . rupiah($totalPagu)
                        . ') lebih kecil dari realisasi yang sudah tercatat ('
                        . rupiah($realisasiLama) . ').';
                }

                if ($status === 'DIBATALKAN' && $realisasiLama > 0) {
                    $errors[] = 'Rincian tidak dapat dibatalkan karena sudah memiliki realisasi.';
                }
            }
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $errors[] = 'Gagal memeriksa data realisasi terkait.';
        }

        if (empty($errors)) {
            try {
                if ($edit === null) {
                    $stmt = $pdo->prepare(
                        'INSERT INTO rincian_anggaran (
                            sub_kegiatan_id, rekening_id, satuan_id,
                            kode_rup, uraian, kategori_belanja,
                            volume, harga_satuan, kena_ppn, tarif_ppn,
                            status, catatan
                        ) VALUES (
                            :sub_kegiatan_id, :rekening_id, :satuan_id,
                            :kode_rup, :uraian, :kategori_belanja,
                            :volume, :harga_satuan, :kena_ppn, :tarif_ppn,
                            :status, :catatan
                        )'
                    );
                    $stmt->execute([
                        ':sub_kegiatan_id' => $subKegiatanId,
                        ':rekening_id'     => $rekeningId,
                        ':satuan_id'       => $satuanId,
                        ':kode_rup'         => $kodeRup,
                        ':uraian'           => $uraian,
                        ':kategori_belanja' => $kategoriBelanja,
                        ':volume'           => $volumeInput,
                        ':harga_satuan'     => $hargaInput,
                        ':kena_ppn'         => $kenaPpn,
                        ':tarif_ppn'        => $tarifInput,
                        ':status'           => $status,
                        ':catatan'          => $catatan !== '' ? $catatan : null,
                    ]);

                    setFlash('success', 'Rincian anggaran berhasil disimpan.');
                } else {
                    $stmt = $pdo->prepare(
                        'UPDATE rincian_anggaran SET
                            sub_kegiatan_id = :sub_kegiatan_id,
                            rekening_id = :rekening_id,
                            satuan_id = :satuan_id,
                            kode_rup = :kode_rup,
                            uraian = :uraian,
                            kategori_belanja = :kategori_belanja,
                            volume = :volume,
                            harga_satuan = :harga_satuan,
                            kena_ppn = :kena_ppn,
                            tarif_ppn = :tarif_ppn,
                            status = :status,
                            catatan = :catatan
                        WHERE id = :id'
                    );
                    $stmt->execute([
                        ':sub_kegiatan_id' => $subKegiatanId,
                        ':rekening_id'     => $rekeningId,
                        ':satuan_id'       => $satuanId,
                        ':kode_rup'         => $kodeRup,
                        ':uraian'           => $uraian,
                        ':kategori_belanja' => $kategoriBelanja,
                        ':volume'           => $volumeInput,
                        ':harga_satuan'     => $hargaInput,
                        ':kena_ppn'         => $kenaPpn,
                        ':tarif_ppn'        => $tarifInput,
                        ':status'           => $status,
                        ':catatan'          => $catatan !== '' ? $catatan : null,
                        ':id'               => (int) $edit['id'],
                    ]);

                    setFlash('success', 'Rincian anggaran berhasil diperbarui.');
                }

                redirect(url('pages/anggaran.php'));
            } catch (PDOException $e) {
                error_log($e->getMessage());

                $errors[] = $e->getCode() === '23000'
                    ? 'Terdapat relasi data yang tidak valid (sub kegiatan, rekening, atau satuan).'
                    : 'Rincian anggaran gagal disimpan. Periksa log PHP.';
            }
        }
    }
}

/* ---------------------------------------------------------------------
 * Data pendukung
 * ------------------------------------------------------------------- */

$subKegiatanList = $pdo->query(
    'SELECT
        sk.id,
        sk.kode_sub_kegiatan,
        sk.nama_sub_kegiatan,
        k.kode_kegiatan,
        k.nama_kegiatan,
        k.tahun_anggaran
    FROM sub_kegiatan AS sk
    INNER JOIN kegiatan AS k ON k.id = sk.kegiatan_id
    ORDER BY k.tahun_anggaran DESC, sk.nama_sub_kegiatan ASC'
)->fetchAll();

$rekeningList = $pdo->query(
    'SELECT id, kode_rekening, nama_rekening
    FROM master_rekening
    ORDER BY kode_rekening ASC'
)->fetchAll();

$satuanList = $pdo->query(
    'SELECT id, kode_satuan, nama_satuan
    FROM master_satuan
    ORDER BY nama_satuan ASC'
)->fetchAll();

$tahunList = array_map(
    'intval',
    $pdo->query('SELECT DISTINCT tahun_anggaran FROM kegiatan ORDER BY tahun_anggaran DESC')
        ->fetchAll(PDO::FETCH_COLUMN)
);

$tahunFilter = filter_input(INPUT_GET, 'tahun', FILTER_VALIDATE_INT);
$tahunFilter = is_int($tahunFilter) && in_array($tahunFilter, $tahunList, true)
    ? $tahunFilter
    : 0;
$cari = trim((string) ($_GET['q'] ?? ''));

$sql = 'SELECT
        ra.id,
        ra.kode_rup,
        ra.uraian,
        ra.kategori_belanja,
        ra.volume,
        ra.harga_satuan,
        ra.kena_ppn,
        ra.tarif_ppn,
        ra.total_dasar,
        ra.nilai_ppn,
        ra.total_pagu,
        ra.status,
        COALESCE(vr.total_realisasi, 0) AS total_realisasi,
        sk.kode_sub_kegiatan,
        sk.nama_sub_kegiatan,
        mr.kode_rekening,
        mr.nama_rekening,
        ms.nama_satuan,
        k.tahun_anggaran
    FROM rincian_anggaran AS ra
    INNER JOIN sub_kegiatan AS sk ON sk.id = ra.sub_kegiatan_id
    INNER JOIN kegiatan AS k ON k.id = sk.kegiatan_id
    INNER JOIN master_rekening AS mr ON mr.id = ra.rekening_id
    INNER JOIN master_satuan AS ms ON ms.id = ra.satuan_id
    LEFT JOIN v_rincian_ringkasan vr ON vr.rincian_id = ra.id';

$where = [];
$params = [];

if ($tahunFilter > 0) {
    $where[] = 'k.tahun_anggaran = :tahun';
    $params[':tahun'] = $tahunFilter;
}

if ($cari !== '') {
    $where[] = '(ra.kode_rup LIKE :cari1 OR ra.uraian LIKE :cari2)';
    $params[':cari1'] = '%' . $cari . '%';
    $params[':cari2'] = '%' . $cari . '%';
}

if (!empty($where)) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}

$sql .= ' ORDER BY k.tahun_anggaran DESC, ra.id DESC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$dataRincian = $stmt->fetchAll();

$nilai = static function (string $key, string $bawaan = '') use ($edit): string {
    if (array_key_exists($key, $_POST)) {
        return (string) $_POST[$key];
    }

    return $edit !== null ? (string) ($edit[$key] ?? $bawaan) : $bawaan;
};

$masterLengkap = !empty($subKegiatanList)
    && !empty($rekeningList)
    && !empty($satuanList);

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<main class="main-content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Rincian Anggaran</h2>
            <p class="page-description">
                Kelola rincian belanja, harga dasar, pajak, dan total pagu anggaran.
            </p>
        </div>
        <?php if ($edit !== null): ?>
            <div class="page-actions">
                <a class="btn btn-light" href="<?= e(url('pages/anggaran.php')) ?>">Batal Ubah</a>
            </div>
        <?php endif; ?>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $msg): ?>
                <div><?= e($msg) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!canManage()): ?>
        <div class="alert alert-info">
            Peran Anda hanya dapat melihat data. Perubahan data dilakukan oleh
            Administrator atau Operator.
        </div>
    <?php endif; ?>

    <?php if (canManage()): ?>
        <section class="card">
            <div class="card-header">
                <div>
                    <h3><?= $edit !== null ? 'Formulir Ubah Rincian Anggaran' : 'Formulir Tambah Rincian Anggaran' ?></h3>
                    <p class="card-subtitle">Total dasar dan PPN dihitung otomatis oleh database.</p>
                </div>
            </div>

            <?php if (!$masterLengkap): ?>
                <div class="empty-state">
                    <strong>Data master belum lengkap.</strong>
                    Pastikan sudah ada sub kegiatan, kode rekening, dan satuan.
                </div>
            <?php else: ?>
                <form method="post" data-once>
                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                    <input type="hidden" name="aksi" value="simpan">

                    <div class="form-grid">
                        <div class="form-group full">
                            <label for="sub_kegiatan_id">Sub Kegiatan *</label>
                            <select id="sub_kegiatan_id" name="sub_kegiatan_id" required>
                                <option value="">-- Pilih Sub Kegiatan --</option>
                                <?php foreach ($subKegiatanList as $sk): ?>
                                    <option
                                        value="<?= (int) $sk['id'] ?>"
                                        title="<?= e($sk['kode_sub_kegiatan'] . ' - ' . $sk['nama_sub_kegiatan'] . ' | ' . $sk['nama_kegiatan'] . ' (' . $sk['tahun_anggaran'] . ')') ?>"
                                        <?= $nilai('sub_kegiatan_id') === (string) $sk['id'] ? 'selected' : '' ?>
                                    >
                                        <?= e($sk['kode_sub_kegiatan']) ?>
                                        - <?= e(ringkasTeks($sk['nama_sub_kegiatan'], 60)) ?>
                                        | <?= e(ringkasTeks($sk['nama_kegiatan'], 30)) ?>
                                        (<?= e($sk['tahun_anggaran']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group full">
                            <label for="rekening_id">Kode Rekening *</label>
                            <select id="rekening_id" name="rekening_id" required>
                                <option value="">-- Pilih Rekening --</option>
                                <?php foreach ($rekeningList as $rek): ?>
                                    <option
                                        value="<?= (int) $rek['id'] ?>"
                                        <?= $nilai('rekening_id') === (string) $rek['id'] ? 'selected' : '' ?>
                                    >
                                        <?= e($rek['kode_rekening']) ?> - <?= e($rek['nama_rekening']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="kode_rup">Kode RUP *</label>
                            <input
                                type="text"
                                id="kode_rup"
                                name="kode_rup"
                                maxlength="60"
                                value="<?= e($nilai('kode_rup')) ?>"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="status">Status *</label>
                            <?php $statusTerpilih = $nilai('status', 'DRAFT'); ?>
                            <select id="status" name="status" required>
                                <option value="DRAFT" <?= $statusTerpilih === 'DRAFT' ? 'selected' : '' ?>>Draft</option>
                                <option value="AKTIF" <?= $statusTerpilih === 'AKTIF' ? 'selected' : '' ?>>Aktif</option>
                                <option value="DIBATALKAN" <?= $statusTerpilih === 'DIBATALKAN' ? 'selected' : '' ?>>Dibatalkan</option>
                            </select>
                        </div>

                        <div class="form-group full">
                            <label for="uraian">Uraian Belanja *</label>
                            <input
                                type="text"
                                id="uraian"
                                name="uraian"
                                maxlength="500"
                                value="<?= e($nilai('uraian')) ?>"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="kategori_belanja">Kategori Belanja *</label>
                            <?php $kategoriTerpilih = $nilai('kategori_belanja'); ?>
                            <select id="kategori_belanja" name="kategori_belanja" required>
                                <option value="">-- Pilih Kategori --</option>
                                <?php foreach (kategoriBelanjaOptions() as $kodeKategori => $labelKategori): ?>
                                    <option
                                        value="<?= e($kodeKategori) ?>"
                                        <?= $kategoriTerpilih === $kodeKategori ? 'selected' : '' ?>
                                    >
                                        <?= e($labelKategori) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="volume">Volume *</label>
                            <input
                                type="number"
                                id="volume"
                                name="volume"
                                min="0.0001"
                                max="99999999999999.9999"
                                step="0.0001"
                                value="<?= e($nilai('volume')) ?>"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="satuan_id">Satuan *</label>
                            <select id="satuan_id" name="satuan_id" required>
                                <option value="">-- Pilih Satuan --</option>
                                <?php foreach ($satuanList as $satuan): ?>
                                    <option
                                        value="<?= (int) $satuan['id'] ?>"
                                        <?= $nilai('satuan_id') === (string) $satuan['id'] ? 'selected' : '' ?>
                                    >
                                        <?= e($satuan['nama_satuan']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="harga_satuan">Harga Satuan Sebelum Pajak *</label>
                            <input
                                type="number"
                                id="harga_satuan"
                                name="harga_satuan"
                                min="0"
                                step="0.01"
                                value="<?= e($nilai('harga_satuan')) ?>"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="kena_ppn">Dikenakan PPN? *</label>
                            <?php $ppnTerpilih = $nilai('kena_ppn', '1'); ?>
                            <select id="kena_ppn" name="kena_ppn" required>
                                <option value="1" <?= $ppnTerpilih === '1' ? 'selected' : '' ?>>Ya</option>
                                <option value="0" <?= $ppnTerpilih === '0' ? 'selected' : '' ?>>Tidak</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="tarif_ppn">Tarif PPN (%) *</label>
                            <input
                                type="number"
                                id="tarif_ppn"
                                name="tarif_ppn"
                                min="0"
                                max="100"
                                step="0.01"
                                value="<?= e($nilai('tarif_ppn', '11')) ?>"
                                required
                            >
                            <small>Nilai awal 11%. Sesuaikan dengan ketentuan yang berlaku.</small>
                        </div>

                        <div class="form-group">
                            <label for="catatan">Catatan</label>
                            <textarea id="catatan" name="catatan" rows="3"><?= e($nilai('catatan')) ?></textarea>
                        </div>
                    </div>

                    <p class="text-muted">* Wajib diisi.</p>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">
                            <?= $edit !== null ? 'Simpan Perubahan' : 'Simpan Rincian Anggaran' ?>
                        </button>
                        <a class="btn btn-light" href="<?= e(url('pages/anggaran.php')) ?>">Reset</a>
                    </div>
                </form>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <section class="card">
        <div class="card-header">
            <h3>Daftar Rincian Anggaran</h3>
            <span class="text-muted"><?= count($dataRincian) ?> data</span>
        </div>

        <form method="get" class="filter-bar" action="<?= e(url('pages/anggaran.php')) ?>">
            <div class="form-group">
                <label for="filter_tahun">Tahun Anggaran</label>
                <select id="filter_tahun" name="tahun" data-auto-submit>
                    <option value="0">Semua tahun</option>
                    <?php foreach ($tahunList as $th): ?>
                        <option value="<?= $th ?>" <?= $tahunFilter === $th ? 'selected' : '' ?>>
                            <?= $th ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="q">Cari Kode RUP / Uraian</label>
                <input type="text" id="q" name="q" value="<?= e($cari) ?>">
            </div>

            <button type="submit" class="btn btn-sm">Cari</button>
            <a class="btn btn-outline-dark btn-sm" href="<?= e(url('pages/anggaran.php')) ?>">Reset</a>
        </form>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Kode RUP</th>
                        <th>Sub Kegiatan</th>
                        <th>Rekening</th>
                        <th>Uraian Belanja</th>
                        <th>Kategori Belanja</th>
                        <th class="num">Volume</th>
                        <th class="num">Harga</th>
                        <th class="num">PPN</th>
                        <th class="num">Total Pagu</th>
                        <th class="num">Realisasi</th>
                        <th class="num">Sisa</th>
                        <th style="min-width:130px">Serapan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($dataRincian)): ?>
                        <tr>
                            <td colspan="15" class="text-center">Belum ada rincian anggaran.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($dataRincian as $i => $row): ?>
                            <?php $rz = ringkasRealisasi($row['total_pagu'], $row['total_realisasi']); ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td class="nowrap">
                                    <?= e($row['kode_rup']) ?><br>
                                    <small class="text-muted"><?= e($row['tahun_anggaran']) ?></small>
                                </td>
                                <td>
                                    <strong><?= e($row['kode_sub_kegiatan']) ?></strong><br>
                                    <span class="text-muted"><?= e($row['nama_sub_kegiatan']) ?></span>
                                </td>
                                <td>
                                    <?= e($row['kode_rekening']) ?><br>
                                    <span class="text-muted"><?= e($row['nama_rekening']) ?></span>
                                </td>
                                <td><?= e($row['uraian']) ?></td>
                                <td>
                                    <?php if ($row['kategori_belanja'] === null): ?>
                                        <span class="text-muted">Belum ditentukan</span>
                                    <?php else: ?>
                                        <?= e(kategoriBelanjaLabel($row['kategori_belanja'])) ?>
                                    <?php endif; ?>
                                </td>
                                <td class="num">
                                    <?= e(rtrim(rtrim(number_format((float) $row['volume'], 4, ',', '.'), '0'), ',')) ?>
                                    <?= e($row['nama_satuan']) ?>
                                </td>
                                <td class="num"><?= rupiah($row['harga_satuan']) ?></td>
                                <td class="num">
                                    <?php if ((int) $row['kena_ppn'] === 1): ?>
                                        <?= e(persen($row['tarif_ppn'])) ?><br>
                                        <small class="text-muted"><?= rupiah($row['nilai_ppn']) ?></small>
                                    <?php else: ?>
                                        <span class="text-muted">Tidak</span>
                                    <?php endif; ?>
                                </td>
                                <td class="num"><strong><?= rupiah($row['total_pagu']) ?></strong></td>
                                <td class="num"><?= rupiah($rz['realisasi']) ?></td>
                                <td class="num <?= $rz['sisa'] < 0 ? 'text-danger' : '' ?>">
                                    <?= rupiah($rz['sisa']) ?>
                                </td>
                                <td>
                                    <div class="progress">
                                        <div
                                            class="progress-bar"
                                            style="width:<?= e((string) min(100, max(0, $rz['persen']))) ?>%;background:<?= e($rz['warna']) ?>"
                                        ></div>
                                    </div>
                                    <div class="progress-meta">
                                        <span><?= e(persen($rz['persen'])) ?></span>
                                        <span><?= e($rz['label']) ?></span>
                                    </div>
                                </td>
                                <td><?= statusBadge($row['status']) ?></td>
                                <td>
                                    <div class="actions">
                                        <a
                                            class="btn btn-light btn-sm"
                                            href="<?= e(url('pages/anggaran_detail.php?id=' . (int) $row['id'])) ?>"
                                        >Detail</a>

                                        <?php if (canManage()): ?>
                                            <a
                                                class="btn btn-light btn-sm"
                                                href="<?= e(url('pages/anggaran.php?edit=' . (int) $row['id'])) ?>"
                                            >Ubah</a>

                                            <form
                                                method="post"
                                                data-confirm="Hapus rincian anggaran <?= e($row['kode_rup']) ?>?"
                                            >
                                                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                                <input type="hidden" name="aksi" value="hapus">
                                                <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
