<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

requireLogin();

$user = currentUser();
$pageTitle = 'Profil Saya';
$currentPage = 'profil';

$errors = [];

$stmt = $pdo->prepare(
    'SELECT id, nama, username, peran, status, dibuat_pada, diperbarui_pada
    FROM pengguna
    WHERE id = :id'
);
$stmt->execute([':id' => $user['id']]);
$akun = $stmt->fetch();

if (!$akun) {
    logoutUser();
    redirect(url('login.php'));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf($_POST['csrf_token'] ?? null);

    $aksi = (string) ($_POST['aksi'] ?? '');

    if ($aksi === 'profil') {
        $nama = trim((string) ($_POST['nama'] ?? ''));

        if (mb_strlen($nama) < 3) {
            $errors[] = 'Nama minimal 3 karakter.';
        } elseif (mb_strlen($nama) > 150) {
            $errors[] = 'Nama maksimal 150 karakter.';
        } else {
            $stmt = $pdo->prepare(
                'UPDATE pengguna SET nama = :nama WHERE id = :id'
            );
            $stmt->execute([':nama' => $nama, ':id' => $akun['id']]);

            $_SESSION['rka_user_nama'] = $nama;
            setFlash('success', 'Profil berhasil diperbarui.');
            redirect(url('pages/profil.php'));
        }
    } elseif ($aksi === 'password') {
        $lama = (string) ($_POST['password_lama'] ?? '');
        $baru = (string) ($_POST['password_baru'] ?? '');
        $ulang = (string) ($_POST['password_ulang'] ?? '');

        $stmt = $pdo->prepare('SELECT password_hash FROM pengguna WHERE id = :id');
        $stmt->execute([':id' => $akun['id']]);
        $hashLama = (string) $stmt->fetchColumn();

        if ($lama === '' || $baru === '' || $ulang === '') {
            $errors[] = 'Semua kolom kata sandi wajib diisi.';
        } elseif (!password_verify($lama, $hashLama)) {
            $errors[] = 'Kata sandi saat ini tidak sesuai.';
        } elseif (mb_strlen($baru) < 8) {
            $errors[] = 'Kata sandi baru minimal 8 karakter.';
        } elseif ($baru !== $ulang) {
            $errors[] = 'Konfirmasi kata sandi baru tidak sama.';
        } elseif ($baru === $lama) {
            $errors[] = 'Kata sandi baru harus berbeda dari kata sandi lama.';
        } else {
            $stmt = $pdo->prepare(
                'UPDATE pengguna SET password_hash = :hash WHERE id = :id'
            );
            $stmt->execute([
                ':hash' => password_hash($baru, PASSWORD_DEFAULT),
                ':id'   => $akun['id'],
            ]);

            session_regenerate_id(true);
            setFlash('success', 'Kata sandi berhasil diubah.');
            redirect(url('pages/profil.php'));
        }
    }
}

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<main class="main-content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Profil Saya</h2>
            <p class="page-description">
                Perbarui nama tampilan dan kata sandi akun Anda.
            </p>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $msg): ?>
                <div><?= e($msg) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="grid-2">
        <section class="card">
            <div class="card-header">
                <div>
                    <h3>Informasi Akun</h3>
                    <p class="card-subtitle">Identitas akun yang sedang digunakan.</p>
                </div>
            </div>

            <div class="stat-list mb-16">
                <div class="stat-row">
                    <span class="label">Nama pengguna</span>
                    <span class="value"><?= e($akun['username']) ?></span>
                </div>
                <div class="stat-row">
                    <span class="label">Peran</span>
                    <span class="value"><?= e(peranLabel($akun['peran'])) ?></span>
                </div>
                <div class="stat-row">
                    <span class="label">Status akun</span>
                    <span class="value"><?= statusBadge($akun['status']) ?></span>
                </div>
                <div class="stat-row">
                    <span class="label">Terdaftar</span>
                    <span class="value"><?= e(tanggalIndo($akun['dibuat_pada'])) ?></span>
                </div>
            </div>

            <form method="post" data-once>
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <input type="hidden" name="aksi" value="profil">

                <div class="form-group">
                    <label for="nama">Nama Tampilan</label>
                    <input
                        type="text"
                        id="nama"
                        name="nama"
                        maxlength="150"
                        value="<?= e($_POST['nama'] ?? $akun['nama']) ?>"
                        required
                    >
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-success">Simpan Profil</button>
                </div>
            </form>
        </section>

        <section class="card">
            <div class="card-header">
                <div>
                    <h3>Ubah Kata Sandi</h3>
                    <p class="card-subtitle">Gunakan minimal 8 karakter.</p>
                </div>
            </div>

            <form method="post" data-once>
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <input type="hidden" name="aksi" value="password">

                <div class="form-group mb-16">
                    <label for="password_lama">Kata Sandi Saat Ini</label>
                    <input
                        type="password"
                        id="password_lama"
                        name="password_lama"
                        autocomplete="current-password"
                        required
                    >
                </div>

                <div class="form-group mb-16">
                    <label for="password_baru">Kata Sandi Baru</label>
                    <input
                        type="password"
                        id="password_baru"
                        name="password_baru"
                        minlength="8"
                        autocomplete="new-password"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="password_ulang">Ulangi Kata Sandi Baru</label>
                    <input
                        type="password"
                        id="password_ulang"
                        name="password_ulang"
                        minlength="8"
                        autocomplete="new-password"
                        required
                    >
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn">Ubah Kata Sandi</button>
                </div>
            </form>
        </section>
    </div>
</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
