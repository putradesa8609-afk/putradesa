<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/rekap_belanja_data.php';
require __DIR__ . '/../includes/xlsx_writer.php';

requireLogin();

$tahunList = array_map(
    'intval',
    $pdo->query('SELECT DISTINCT tahun_anggaran FROM kegiatan ORDER BY tahun_anggaran DESC')
        ->fetchAll(PDO::FETCH_COLUMN)
);

$tahunFilter = filter_input(INPUT_GET, 'tahun', FILTER_VALIDATE_INT);
$tahunFilter = is_int($tahunFilter) && in_array($tahunFilter, $tahunList, true)
    ? $tahunFilter
    : 0;

$kategoriOptions = kategoriBelanjaOptions();
$kategoriInput = (string) ($_GET['kategori'] ?? '');
$kategoriFilter = '';

if ($kategoriInput === 'NONE' || array_key_exists($kategoriInput, $kategoriOptions)) {
    $kategoriFilter = $kategoriInput;
}

$rekap = ambilRekapBelanja($pdo, $tahunFilter, $kategoriFilter);
$dataBelanja = $rekap['rows'];
$ringkasanKategori = $rekap['ringkasan'];
$totalItem = $rekap['total_item'];
$totalPagu = $rekap['total_pagu'];
$totalRealisasi = $rekap['total_realisasi'];
$totalDibayar = $rekap['total_dibayar'];
$totalSisa = $rekap['total_sisa'];
$persenSerapan = $totalPagu > 0 ? $totalRealisasi / $totalPagu * 100 : 0.0;

$ringkasanTampil = array_filter(
    $ringkasanKategori,
    static fn (array $baris): bool => $baris['jumlah'] > 0
);

$labelTahun = $tahunFilter > 0 ? (string) $tahunFilter : 'Semua Tahun';
$labelKategori = $kategoriFilter === ''
    ? 'Semua Kategori'
    : ($kategoriFilter === 'NONE' ? 'Belum Ditentukan' : $kategoriOptions[$kategoriFilter]);

$namaFile = 'rekap-belanja-'
    . ($tahunFilter > 0 ? $tahunFilter : 'semua-tahun')
    . '-'
    . ($kategoriFilter === '' ? 'semua-kategori' : strtolower($kategoriFilter))
    . '.xlsx';

$workbook = new XlsxWorkbook();

/* ---------------------------------------------------------------------
 * Lembar 1: Ringkasan per kategori
 * ------------------------------------------------------------------- */

$ringkasan = new XlsxSheet('Ringkasan', [28, 12, 18, 18, 18, 18, 12]);

$ringkasan->addMergedRow('REKAP BELANJA', 7, XlsxWorkbook::STYLE_TITLE);
$ringkasan->addMergedRow(
    'DINAS PERIKANAN DAN PETERNAKAN KABUPATEN BOGOR',
    7,
    XlsxWorkbook::STYLE_SUBTITLE
);
$ringkasan->addMergedRow('Tahun Anggaran: ' . $labelTahun, 7, XlsxWorkbook::STYLE_SUBTITLE);
$ringkasan->addMergedRow('Kategori: ' . $labelKategori, 7, XlsxWorkbook::STYLE_SUBTITLE);
$ringkasan->addMergedRow('Dicetak: ' . date('d-m-Y H:i:s'), 7, XlsxWorkbook::STYLE_SUBTITLE);
$ringkasan->addEmptyRow();

$ringkasan->startRow();

foreach (
    ['Kategori Belanja', 'Jumlah Item', 'Total Pagu', 'Realisasi', 'Dibayar', 'Sisa Pagu', 'Serapan (%)']
    as $judul
) {
    $ringkasan->string($judul, XlsxWorkbook::STYLE_HEADER);
}

$ringkasan->endRow();

if (empty($ringkasanTampil)) {
    $ringkasan->startRow();
    $ringkasan->string('Belum ada transaksi belanja.', XlsxWorkbook::STYLE_TEXT);
    $ringkasan->endRow();
} else {
    foreach ($ringkasanTampil as $baris) {
        $serapan = $baris['pagu'] > 0 ? $baris['realisasi'] / $baris['pagu'] * 100 : 0.0;

        $ringkasan->startRow();
        $ringkasan->string($baris['label'], XlsxWorkbook::STYLE_TEXT_BOLD);
        $ringkasan->number($baris['jumlah'], XlsxWorkbook::STYLE_INTEGER);
        $ringkasan->number($baris['pagu'], XlsxWorkbook::STYLE_NUMBER);
        $ringkasan->number($baris['realisasi'], XlsxWorkbook::STYLE_NUMBER);
        $ringkasan->number($baris['dibayar'], XlsxWorkbook::STYLE_NUMBER);
        $ringkasan->number($baris['sisa'], XlsxWorkbook::STYLE_NUMBER);
        $ringkasan->number($serapan, XlsxWorkbook::STYLE_NUMBER);
        $ringkasan->endRow();
    }

    $ringkasan->startRow();
    $ringkasan->string('TOTAL', XlsxWorkbook::STYLE_TOTAL_TEXT);
    $ringkasan->number($totalItem, XlsxWorkbook::STYLE_TOTAL_INTEGER);
    $ringkasan->number($totalPagu, XlsxWorkbook::STYLE_TOTAL_INTEGER);
    $ringkasan->number($totalRealisasi, XlsxWorkbook::STYLE_TOTAL_INTEGER);
    $ringkasan->number($totalDibayar, XlsxWorkbook::STYLE_TOTAL_INTEGER);
    $ringkasan->number($totalSisa, XlsxWorkbook::STYLE_TOTAL_INTEGER);
    $ringkasan->number($persenSerapan, XlsxWorkbook::STYLE_TOTAL_DECIMAL);
    $ringkasan->endRow();
}

$workbook->addSheet($ringkasan);

/* ---------------------------------------------------------------------
 * Lembar 2: Seluruh transaksi
 * ------------------------------------------------------------------- */

$kolomTransaksi = [
    'No.',
    'Tahun',
    'Kategori Belanja',
    'Kode RUP',
    'Uraian Belanja',
    'Sub Kegiatan',
    'Kode Rekening',
    'Volume',
    'Satuan',
    'Harga Satuan',
    'PPN (%)',
    'Nilai PPN',
    'Total Dasar',
    'Total Pagu',
    'Realisasi',
    'Dibayar',
    'Sisa Pagu',
    'Jml Realisasi',
    'Status',
];

$transaksi = new XlsxSheet(
    'Transaksi',
    [5, 8, 20, 16, 40, 30, 25, 8, 8, 14, 8, 14, 16, 16, 16, 16, 16, 10, 12]
);

$transaksi->addMergedRow('SELURUH TRANSAKSI BELANJA', 19, XlsxWorkbook::STYLE_TITLE);
$transaksi->addMergedRow(
    'Tahun Anggaran: ' . $labelTahun . ' | Kategori: ' . $labelKategori
        . ' | Jumlah data: ' . number_format($totalItem, 0, ',', '.'),
    19,
    XlsxWorkbook::STYLE_SUBTITLE
);
$transaksi->addEmptyRow();

$transaksi->startRow();

foreach ($kolomTransaksi as $judul) {
    $transaksi->string($judul, XlsxWorkbook::STYLE_HEADER);
}

$transaksi->endRow();

if (empty($dataBelanja)) {
    $transaksi->startRow();
    $transaksi->string('Belum ada transaksi belanja.', XlsxWorkbook::STYLE_TEXT);
    $transaksi->endRow();
} else {
    foreach ($dataBelanja as $i => $row) {
        $kenaPpn = (int) $row['kena_ppn'] === 1;

        $transaksi->startRow();
        $transaksi->number($i + 1, XlsxWorkbook::STYLE_INTEGER);
        $transaksi->string((string) $row['tahun_anggaran'], XlsxWorkbook::STYLE_TEXT);
        $transaksi->string(kategoriBelanjaLabel($row['kategori_belanja']), XlsxWorkbook::STYLE_TEXT);
        $transaksi->string((string) $row['kode_rup'], XlsxWorkbook::STYLE_TEXT);
        $transaksi->string((string) $row['uraian'], XlsxWorkbook::STYLE_TEXT);
        $transaksi->string($row['kode_sub_kegiatan'] . ' - ' . $row['nama_sub_kegiatan'], XlsxWorkbook::STYLE_TEXT);
        $transaksi->string($row['kode_rekening'] . ' - ' . $row['nama_rekening'], XlsxWorkbook::STYLE_TEXT);
        $transaksi->number($row['volume'], XlsxWorkbook::STYLE_NUMBER);
        $transaksi->string((string) $row['nama_satuan'], XlsxWorkbook::STYLE_TEXT);
        $transaksi->number($row['harga_satuan'], XlsxWorkbook::STYLE_NUMBER);
        $transaksi->number($kenaPpn ? $row['tarif_ppn'] : 0, XlsxWorkbook::STYLE_NUMBER);
        $transaksi->number($row['nilai_ppn'], XlsxWorkbook::STYLE_NUMBER);
        $transaksi->number($row['total_dasar'], XlsxWorkbook::STYLE_NUMBER);
        $transaksi->number($row['total_pagu'], XlsxWorkbook::STYLE_NUMBER);
        $transaksi->number($row['total_realisasi'], XlsxWorkbook::STYLE_NUMBER);
        $transaksi->number($row['total_dibayar'], XlsxWorkbook::STYLE_NUMBER);
        $transaksi->number($row['sisa_pagu'], XlsxWorkbook::STYLE_NUMBER);
        $transaksi->number($row['jumlah_realisasi'], XlsxWorkbook::STYLE_INTEGER);
        $transaksi->string(
            ucwords(strtolower(str_replace('_', ' ', (string) $row['status']))),
            XlsxWorkbook::STYLE_TEXT
        );
        $transaksi->endRow();
    }
}

$transaksi->freezeRows(4);
$workbook->addSheet($transaksi);

$isi = $workbook->build();

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $namaFile . '"');
header('Content-Length: ' . strlen($isi));
header('Cache-Control: no-store, no-cache, must-revalidate');

echo $isi;
