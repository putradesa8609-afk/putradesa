<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

requireLogin();

$pageTitle = 'Kode Rekening';
$currentPage = 'rekening';

$errors = [];
$edit = null;

$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);
$cari = trim((string) ($_GET['q'] ?? ''));

if (is_int($editId) && $editId > 0) {
    $stmt = $pdo->prepare(
        'SELECT id, kode_rekening, nama_rekening
        FROM master_rekening
        WHERE id = :id'
    );
    $stmt->execute([':id' => $editId]);
    $edit = $stmt->fetch() ?: null;

    if ($edit === null) {
        setFlash('warning', 'Kode rekening yang ingin diubah tidak ditemukan.');
        redirect(url('pages/rekening.php'));
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf($_POST['csrf_token'] ?? null);
    requireManage();

    $aksi = (string) ($_POST['aksi'] ?? 'simpan');

    if ($aksi === 'hapus') {
        $hapusId = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);

        if (!is_int($hapusId) || $hapusId < 1) {
            setFlash('danger', 'Data rekening tidak valid.');
        } else {
            $stmt = $pdo->prepare('SELECT kode_rekening FROM master_rekening WHERE id = :id');
            $stmt->execute([':id' => $hapusId]);
            $kode = $stmt->fetchColumn();

            $stmt = $pdo->prepare(
                'SELECT COUNT(*) FROM rincian_anggaran WHERE rekening_id = :id'
            );
            $stmt->execute([':id' => $hapusId]);
            $jumlahPakai = (int) $stmt->fetchColumn();

            if ($kode === false) {
                setFlash('warning', 'Kode rekening tidak ditemukan.');
            } elseif ($jumlahPakai > 0) {
                setFlash(
                    'danger',
                    'Kode rekening tidak dapat dihapus karena dipakai pada '
                    . $jumlahPakai . ' rincian anggaran.'
                );
            } else {
                $stmt = $pdo->prepare('DELETE FROM master_rekening WHERE id = :id');
                $stmt->execute([':id' => $hapusId]);
                setFlash('success', 'Kode rekening ' . $kode . ' berhasil dihapus.');
            }
        }

        redirect(url('pages/rekening.php'));
    }

    $kode = trim((string) ($_POST['kode_rekening'] ?? ''));
    $nama = trim((string) ($_POST['nama_rekening'] ?? ''));

    if ($kode === '' || mb_strlen($kode) > 80) {
        $errors[] = 'Kode rekening wajib diisi (maksimal 80 karakter).';
    }

    if ($nama === '' || mb_strlen($nama) > 255) {
        $errors[] = 'Nama rekening wajib diisi (maksimal 255 karakter).';
    }

    if (empty($errors)) {
        try {
            $cek = $pdo->prepare(
                'SELECT COUNT(*) FROM master_rekening
                WHERE kode_rekening = :kode AND id <> :id'
            );
            $cek->execute([
                ':kode' => $kode,
                ':id'   => $edit !== null ? (int) $edit['id'] : 0,
            ]);

            if ((int) $cek->fetchColumn() > 0) {
                $errors[] = 'Kode rekening sudah terdaftar.';
            } else {
                if ($edit === null) {
                    $stmt = $pdo->prepare(
                        'INSERT INTO master_rekening (kode_rekening, nama_rekening)
                        VALUES (:kode, :nama)'
                    );
                    $stmt->execute([':kode' => $kode, ':nama' => $nama]);

                    setFlash('success', 'Kode rekening berhasil disimpan.');
                } else {
                    $stmt = $pdo->prepare(
                        'UPDATE master_rekening
                        SET kode_rekening = :kode, nama_rekening = :nama
                        WHERE id = :id'
                    );
                    $stmt->execute([
                        ':kode' => $kode,
                        ':nama' => $nama,
                        ':id'   => (int) $edit['id'],
                    ]);

                    setFlash('success', 'Kode rekening berhasil diperbarui.');
                }

                redirect(url('pages/rekening.php'));
            }
        } catch (PDOException $e) {
            error_log($e->getMessage());

            $errors[] = $e->getCode() === '23000'
                ? 'Kode rekening sudah terdaftar atau data melanggar aturan database.'
                : 'Kode rekening gagal disimpan. Periksa log PHP.';
        }
    }
}

$sql = 'SELECT
        mr.id,
        mr.kode_rekening,
        mr.nama_rekening,
        (SELECT COUNT(*) FROM rincian_anggaran ra WHERE ra.rekening_id = mr.id) AS jml_rincian,
        (SELECT COALESCE(SUM(ra.total_pagu), 0) FROM rincian_anggaran ra WHERE ra.rekening_id = mr.id) AS total_pagu
    FROM master_rekening AS mr';

$params = [];

if ($cari !== '') {
    $sql .= ' WHERE mr.kode_rekening LIKE :cari1 OR mr.nama_rekening LIKE :cari2';
    $params[':cari1'] = '%' . $cari . '%';
    $params[':cari2'] = '%' . $cari . '%';
}

$sql .= ' ORDER BY mr.kode_rekening ASC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$dataRekening = $stmt->fetchAll();

$nilai = static function (string $key, string $bawaan = '') use ($edit): string {
    if (array_key_exists($key, $_POST)) {
        return (string) $_POST[$key];
    }

    return $edit !== null ? (string) ($edit[$key] ?? $bawaan) : $bawaan;
};

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<main class="main-content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Kode Rekening</h2>
            <p class="page-description">
                Kelola master kode rekening untuk kebutuhan penganggaran RKA Yanus.
            </p>
        </div>
        <?php if ($edit !== null): ?>
            <div class="page-actions">
                <a class="btn btn-light" href="<?= e(url('pages/rekening.php')) ?>">Batal Ubah</a>
            </div>
        <?php endif; ?>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $msg): ?>
                <div><?= e($msg) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!canManage()): ?>
        <div class="alert alert-info">
            Peran Anda hanya dapat melihat data. Perubahan data dilakukan oleh
            Administrator atau Operator.
        </div>
    <?php endif; ?>

    <?php if (canManage()): ?>
        <section class="card">
            <div class="card-header">
                <div>
                    <h3><?= $edit !== null ? 'Formulir Ubah Kode Rekening' : 'Formulir Tambah Kode Rekening' ?></h3>
                    <p class="card-subtitle">Kode rekening harus unik.</p>
                </div>
            </div>

            <form method="post" data-once>
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <input type="hidden" name="aksi" value="simpan">

                <div class="form-grid">
                    <div class="form-group">
                        <label for="kode_rekening">Kode Rekening *</label>
                        <input
                            type="text"
                            id="kode_rekening"
                            name="kode_rekening"
                            maxlength="80"
                            value="<?= e($nilai('kode_rekening')) ?>"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="nama_rekening">Nama Rekening *</label>
                        <input
                            type="text"
                            id="nama_rekening"
                            name="nama_rekening"
                            maxlength="255"
                            value="<?= e($nilai('nama_rekening')) ?>"
                            required
                        >
                    </div>
                </div>

                <p class="text-muted">* Wajib diisi.</p>

                <div class="form-actions">
                    <button type="submit" class="btn btn-success">
                        <?= $edit !== null ? 'Simpan Perubahan' : 'Simpan Kode Rekening' ?>
                    </button>
                    <a class="btn btn-light" href="<?= e(url('pages/rekening.php')) ?>">Reset</a>
                </div>
            </form>
        </section>
    <?php endif; ?>

    <section class="card">
        <div class="card-header">
            <h3>Daftar Kode Rekening</h3>
            <span class="text-muted"><?= count($dataRekening) ?> data</span>
        </div>

        <form method="get" class="filter-bar" action="<?= e(url('pages/rekening.php')) ?>">
            <div class="form-group">
                <label for="q">Cari Kode / Nama Rekening</label>
                <input type="text" id="q" name="q" value="<?= e($cari) ?>" placeholder="Contoh: 5.1.02">
            </div>
            <button type="submit" class="btn btn-sm">Cari</button>
            <a class="btn btn-outline-dark btn-sm" href="<?= e(url('pages/rekening.php')) ?>">Reset</a>
        </form>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Kode Rekening</th>
                        <th>Nama Rekening</th>
                        <th class="num">Dipakai</th>
                        <th class="num">Total Pagu</th>
                        <?php if (canManage()): ?>
                            <th>Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($dataRekening)): ?>
                        <tr>
                            <td colspan="<?= canManage() ? 6 : 5 ?>" class="text-center">
                                <?= $cari !== '' ? 'Tidak ada rekening yang cocok.' : 'Belum ada kode rekening.' ?>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($dataRekening as $i => $row): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td class="nowrap"><?= e($row['kode_rekening']) ?></td>
                                <td><?= e($row['nama_rekening']) ?></td>
                                <td class="num"><?= (int) $row['jml_rincian'] ?></td>
                                <td class="num"><?= rupiah($row['total_pagu']) ?></td>
                                <?php if (canManage()): ?>
                                    <td>
                                        <div class="actions">
                                            <a
                                                class="btn btn-light btn-sm"
                                                href="<?= e(url('pages/rekening.php?edit=' . (int) $row['id'])) ?>"
                                            >Ubah</a>

                                            <form
                                                method="post"
                                                data-confirm="Hapus kode rekening &quot;<?= e($row['kode_rekening']) ?>&quot;?"
                                            >
                                                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                                <input type="hidden" name="aksi" value="hapus">
                                                <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                            </form>
                                        </div>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
