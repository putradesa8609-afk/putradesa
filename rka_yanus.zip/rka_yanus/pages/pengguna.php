<?php
declare(strict_types=1);

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

requireRole('ADMIN');

$user = currentUser();
$pageTitle = 'Kelola Pengguna';
$currentPage = 'pengguna';

$errors = [];
$peranValid = ['ADMIN', 'OPERATOR', 'VERIFIKATOR', 'PIMPINAN'];
$statusValid = ['AKTIF', 'NONAKTIF'];

$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);
$edit = null;

if (is_int($editId) && $editId > 0) {
    $stmt = $pdo->prepare(
        'SELECT id, nama, username, peran, status, dibuat_pada
        FROM pengguna
        WHERE id = :id'
    );
    $stmt->execute([':id' => $editId]);
    $edit = $stmt->fetch() ?: null;

    if ($edit === null) {
        setFlash('warning', 'Pengguna yang ingin diubah tidak ditemukan.');
        redirect(url('pages/pengguna.php'));
    }
}

function jumlahAdminAktif(PDO $pdo): int
{
    return (int) $pdo->query(
        "SELECT COUNT(*) FROM pengguna WHERE peran = 'ADMIN' AND status = 'AKTIF'"
    )->fetchColumn();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf($_POST['csrf_token'] ?? null);

    $aksi = (string) ($_POST['aksi'] ?? 'simpan');
    $idPost = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);

    if ($aksi === 'hapus') {
        $targetId = is_int($idPost) ? $idPost : 0;

        $stmt = $pdo->prepare('SELECT id, nama, peran, status FROM pengguna WHERE id = :id');
        $stmt->execute([':id' => $targetId]);
        $target = $stmt->fetch();

        if (!$target) {
            setFlash('warning', 'Pengguna tidak ditemukan.');
        } elseif ($targetId === (int) $user['id']) {
            setFlash('danger', 'Anda tidak dapat menghapus akun sendiri.');
        } elseif (
            $target['peran'] === 'ADMIN' &&
            $target['status'] === 'AKTIF' &&
            jumlahAdminAktif($pdo) <= 1
        ) {
            setFlash('danger', 'Minimal harus ada satu Administrator aktif.');
        } else {
            $stmt = $pdo->prepare('DELETE FROM pengguna WHERE id = :id');
            $stmt->execute([':id' => $targetId]);
            setFlash('success', 'Pengguna "' . $target['nama'] . '" berhasil dihapus.');
        }

        redirect(url('pages/pengguna.php'));
    }

    $nama = trim((string) ($_POST['nama'] ?? ''));
    $username = trim((string) ($_POST['username'] ?? ''));
    $peran = (string) ($_POST['peran'] ?? '');
    $status = (string) ($_POST['status'] ?? 'AKTIF');
    $password = (string) ($_POST['password'] ?? '');

    if (mb_strlen($nama) < 3 || mb_strlen($nama) > 150) {
        $errors[] = 'Nama harus terdiri dari 3 sampai 150 karakter.';
    }

    if (preg_match('/^[A-Za-z0-9._-]{3,80}$/', $username) !== 1) {
        $errors[] = 'Username 3-80 karakter, hanya huruf, angka, titik, garis bawah, atau strip.';
    }

    if (!in_array($peran, $peranValid, true)) {
        $errors[] = 'Peran tidak valid.';
    }

    if (!in_array($status, $statusValid, true)) {
        $errors[] = 'Status tidak valid.';
    }

    if ($edit === null && $password === '') {
        $errors[] = 'Kata sandi wajib diisi untuk pengguna baru.';
    }

    if ($password !== '' && mb_strlen($password) < 8) {
        $errors[] = 'Kata sandi minimal 8 karakter.';
    }

    if ($edit !== null) {
        $targetId = (int) $edit['id'];

        if ($targetId === (int) $user['id'] && $status !== 'AKTIF') {
            $errors[] = 'Anda tidak dapat menonaktifkan akun sendiri.';
        }

        if (
            $targetId === (int) $user['id'] &&
            $peran !== $user['peran']
        ) {
            $errors[] = 'Anda tidak dapat mengubah peran akun sendiri.';
        }

        if (
            $edit['peran'] === 'ADMIN' &&
            $edit['status'] === 'AKTIF' &&
            ($peran !== 'ADMIN' || $status !== 'AKTIF') &&
            jumlahAdminAktif($pdo) <= 1
        ) {
            $errors[] = 'Minimal harus ada satu Administrator aktif.';
        }
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare(
            'SELECT COUNT(*) FROM pengguna
            WHERE username = :username AND id <> :id'
        );
        $stmt->execute([
            ':username' => $username,
            ':id'       => $edit !== null ? (int) $edit['id'] : 0,
        ]);

        if ((int) $stmt->fetchColumn() > 0) {
            $errors[] = 'Username sudah digunakan pengguna lain.';
        }
    }

    if (empty($errors)) {
        try {
            if ($edit === null) {
                $stmt = $pdo->prepare(
                    'INSERT INTO pengguna (nama, username, password_hash, peran, status)
                    VALUES (:nama, :username, :hash, :peran, :status)'
                );
                $stmt->execute([
                    ':nama'     => $nama,
                    ':username' => $username,
                    ':hash'     => password_hash($password, PASSWORD_DEFAULT),
                    ':peran'    => $peran,
                    ':status'   => $status,
                ]);

                setFlash('success', 'Pengguna "' . $nama . '" berhasil ditambahkan.');
            } else {
                if ($password !== '') {
                    $stmt = $pdo->prepare(
                        'UPDATE pengguna
                        SET nama = :nama,
                            username = :username,
                            peran = :peran,
                            status = :status,
                            password_hash = :hash
                        WHERE id = :id'
                    );
                    $stmt->execute([
                        ':nama'     => $nama,
                        ':username' => $username,
                        ':peran'    => $peran,
                        ':status'   => $status,
                        ':hash'     => password_hash($password, PASSWORD_DEFAULT),
                        ':id'       => (int) $edit['id'],
                    ]);
                } else {
                    $stmt = $pdo->prepare(
                        'UPDATE pengguna
                        SET nama = :nama,
                            username = :username,
                            peran = :peran,
                            status = :status
                        WHERE id = :id'
                    );
                    $stmt->execute([
                        ':nama'     => $nama,
                        ':username' => $username,
                        ':peran'    => $peran,
                        ':status'   => $status,
                        ':id'       => (int) $edit['id'],
                    ]);
                }

                setFlash('success', 'Data pengguna "' . $nama . '" berhasil diperbarui.');
            }

            redirect(url('pages/pengguna.php'));
        } catch (PDOException $e) {
            error_log($e->getMessage());

            $errors[] = $e->getCode() === '23000'
                ? 'Username sudah digunakan atau data melanggar aturan database.'
                : 'Data pengguna gagal disimpan. Periksa log PHP.';
        }
    }
}

$daftarPengguna = $pdo->query(
    'SELECT id, nama, username, peran, status, dibuat_pada, diperbarui_pada
    FROM pengguna
    ORDER BY FIELD(peran, \'ADMIN\', \'OPERATOR\', \'VERIFIKATOR\', \'PIMPINAN\'), nama ASC'
)->fetchAll();

$nilai = static function (string $key, string $bawaan = '') use ($edit): string {
    if (array_key_exists($key, $_POST)) {
        return (string) $_POST[$key];
    }

    return $edit !== null ? (string) ($edit[$key] ?? $bawaan) : $bawaan;
};

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<main class="main-content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Kelola Pengguna</h2>
            <p class="page-description">
                Atur akun, peran, dan status akses aplikasi RKA Yanus.
            </p>
        </div>
        <?php if ($edit !== null): ?>
            <div class="page-actions">
                <a class="btn btn-light" href="<?= e(url('pages/pengguna.php')) ?>">
                    Batal Ubah
                </a>
            </div>
        <?php endif; ?>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $msg): ?>
                <div><?= e($msg) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <section class="card">
        <div class="card-header">
            <div>
                <h3><?= $edit !== null ? 'Ubah Pengguna' : 'Tambah Pengguna' ?></h3>
                <p class="card-subtitle">
                    <?= $edit !== null
                        ? 'Kosongkan kata sandi bila tidak ingin menggantinya.'
                        : 'Kata sandi minimal 8 karakter.' ?>
                </p>
            </div>
        </div>

        <form method="post" data-once>
            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
            <input type="hidden" name="aksi" value="simpan">
            <?php if ($edit !== null): ?>
                <input type="hidden" name="id" value="<?= (int) $edit['id'] ?>">
            <?php endif; ?>

            <div class="form-grid">
                <div class="form-group">
                    <label for="nama">Nama Lengkap *</label>
                    <input
                        type="text"
                        id="nama"
                        name="nama"
                        maxlength="150"
                        value="<?= e($nilai('nama')) ?>"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="username">Username *</label>
                    <input
                        type="text"
                        id="username"
                        name="username"
                        maxlength="80"
                        pattern="[A-Za-z0-9._-]{3,80}"
                        value="<?= e($nilai('username')) ?>"
                        required
                    >
                    <small>Huruf, angka, titik, garis bawah, atau strip.</small>
                </div>

                <div class="form-group">
                    <label for="peran">Peran *</label>
                    <?php $peranTerpilih = $nilai('peran', 'OPERATOR'); ?>
                    <select id="peran" name="peran" required>
                        <?php foreach ($peranValid as $p): ?>
                            <option value="<?= e($p) ?>" <?= $peranTerpilih === $p ? 'selected' : '' ?>>
                                <?= e(peranLabel($p)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="status">Status *</label>
                    <?php $statusTerpilih = $nilai('status', 'AKTIF'); ?>
                    <select id="status" name="status" required>
                        <option value="AKTIF" <?= $statusTerpilih === 'AKTIF' ? 'selected' : '' ?>>
                            Aktif
                        </option>
                        <option value="NONAKTIF" <?= $statusTerpilih === 'NONAKTIF' ? 'selected' : '' ?>>
                            Nonaktif
                        </option>
                    </select>
                </div>

                <div class="form-group full">
                    <label for="password">
                        <?= $edit !== null ? 'Kata Sandi Baru (opsional)' : 'Kata Sandi *' ?>
                    </label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        minlength="8"
                        autocomplete="new-password"
                        <?= $edit === null ? 'required' : '' ?>
                    >
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-success">
                    <?= $edit !== null ? 'Simpan Perubahan' : 'Tambah Pengguna' ?>
                </button>
                <a class="btn btn-light" href="<?= e(url('pages/pengguna.php')) ?>">Reset Form</a>
            </div>
        </form>
    </section>

    <section class="card">
        <div class="card-header">
            <h3>Daftar Pengguna</h3>
            <span class="text-muted"><?= count($daftarPengguna) ?> akun</span>
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Peran</th>
                        <th>Status</th>
                        <th>Dibuat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($daftarPengguna)): ?>
                        <tr>
                            <td colspan="7" class="text-center">Belum ada pengguna.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($daftarPengguna as $i => $row): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td>
                                    <?= e($row['nama']) ?>
                                    <?php if ((int) $row['id'] === (int) $user['id']): ?>
                                        <span class="chip">Anda</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= e($row['username']) ?></td>
                                <td><?= e(peranLabel($row['peran'])) ?></td>
                                <td><?= statusBadge($row['status']) ?></td>
                                <td class="nowrap"><?= e(tanggalIndo($row['dibuat_pada'])) ?></td>
                                <td>
                                    <div class="actions">
                                        <a
                                            class="btn btn-light btn-sm"
                                            href="<?= e(url('pages/pengguna.php?edit=' . (int) $row['id'])) ?>"
                                        >Ubah</a>

                                        <?php if ((int) $row['id'] !== (int) $user['id']): ?>
                                            <form
                                                method="post"
                                                data-confirm="Hapus pengguna &quot;<?= e($row['nama']) ?>&quot;? Tindakan ini tidak dapat dibatalkan."
                                            >
                                                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                                <input type="hidden" name="aksi" value="hapus">
                                                <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
