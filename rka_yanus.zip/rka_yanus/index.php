<?php
declare(strict_types=1);

require __DIR__ . '/config/database.php';
require __DIR__ . '/includes/functions.php';

requireLogin();

$user = currentUser();
$pageTitle = 'Dashboard';
$currentPage = 'dashboard';

/* ---------------------------------------------------------------------
 * Filter tahun anggaran
 * ------------------------------------------------------------------- */

$tahunList = array_map(
    'intval',
    $pdo->query(
        'SELECT DISTINCT tahun_anggaran FROM kegiatan ORDER BY tahun_anggaran DESC'
    )->fetchAll(PDO::FETCH_COLUMN)
);

$tahunParam = filter_input(INPUT_GET, 'tahun', FILTER_VALIDATE_INT);
$tahun = is_int($tahunParam) && in_array($tahunParam, $tahunList, true)
    ? $tahunParam
    : 0;

$filterKegiatan = $tahun > 0 ? ' AND k.tahun_anggaran = :tahun' : '';
$filterAktif = $tahun > 0 ? ' AND k.tahun_anggaran = :tahun' : '';
$params = $tahun > 0 ? [':tahun' => $tahun] : [];

$dasarTransaksi = '
    INNER JOIN sub_kegiatan sk ON sk.id = ra.sub_kegiatan_id
    INNER JOIN kegiatan k ON k.id = sk.kegiatan_id';

/* ---------------------------------------------------------------------
 * KPI utama
 * ------------------------------------------------------------------- */

$stmt = $pdo->prepare(
    'SELECT
        COUNT(DISTINCT ra.id) AS jml_rincian,
        COALESCE(SUM(ra.total_pagu), 0) AS pagu,
        COALESCE(SUM(rz.total_realisasi), 0) AS realisasi,
        COALESCE(SUM(rz.sisa_pagu), 0) AS sisa
    FROM rincian_anggaran ra
    ' . $dasarTransaksi . '
    LEFT JOIN v_rincian_ringkasan rz ON rz.rincian_id = ra.id
    WHERE ra.status <> \'DIBATALKAN\'' . $filterAktif
);
$stmt->execute($params);
$kpi = $stmt->fetch();

$pagu = (float) $kpi['pagu'];
$totalRealisasi = (float) $kpi['realisasi'];
$sisaPagu = $pagu - $totalRealisasi;
$persenSerapan = $pagu > 0 ? $totalRealisasi / $pagu * 100 : 0.0;

$stmt = $pdo->prepare(
    'SELECT
        COALESCE(SUM(b.jumlah_dibayar), 0) AS total,
        COUNT(b.id) AS jml
    FROM realisasi_pembayaran b
    INNER JOIN realisasi_anggaran r ON r.id = b.realisasi_id
    INNER JOIN rincian_anggaran ra ON ra.id = r.rincian_anggaran_id'
    . $dasarTransaksi . '
    WHERE r.status <> \'DIBATALKAN\'
      AND ra.status <> \'DIBATALKAN\'' . $filterAktif
);
$stmt->execute($params);
$bayar = $stmt->fetch();

$totalDibayar = (float) $bayar['total'];
$jumlahPembayaran = (int) $bayar['jml'];
$belumDibayar = max(0, $totalRealisasi - $totalDibayar);
$persenDibayar = $totalRealisasi > 0 ? $totalDibayar / $totalRealisasi * 100 : 0.0;

/* ---------------------------------------------------------------------
 * Jumlah data & status
 * ------------------------------------------------------------------- */

$stmt = $pdo->prepare(
    'SELECT
        COUNT(DISTINCT k.id) AS kegiatan,
        COUNT(DISTINCT sk.id) AS sub_kegiatan,
        COUNT(DISTINCT ra.id) AS rincian,
        COUNT(DISTINCT r.id) AS realisasi
    FROM kegiatan k
    LEFT JOIN sub_kegiatan sk ON sk.kegiatan_id = k.id
    LEFT JOIN rincian_anggaran ra
        ON ra.sub_kegiatan_id = sk.id AND ra.status <> \'DIBATALKAN\'
    LEFT JOIN realisasi_anggaran r
        ON r.rincian_anggaran_id = ra.id AND r.status <> \'DIBATALKAN\'
    WHERE 1 = 1' . $filterKegiatan
);
$stmt->execute($params);
$jumlah = $stmt->fetch();

$stmt = $pdo->prepare(
    'SELECT ra.status, COUNT(*) AS jml
    FROM rincian_anggaran ra
    ' . $dasarTransaksi . '
    WHERE 1 = 1' . $filterAktif . '
    GROUP BY ra.status'
);
$stmt->execute($params);
$rincianStatus = ['DRAFT' => 0, 'AKTIF' => 0, 'DIBATALKAN' => 0];
foreach ($stmt->fetchAll() as $row) {
    $rincianStatus[$row['status']] = (int) $row['jml'];
}

$stmt = $pdo->prepare(
    'SELECT r.status, COUNT(*) AS jml
    FROM realisasi_anggaran r
    INNER JOIN rincian_anggaran ra ON ra.id = r.rincian_anggaran_id'
    . $dasarTransaksi . '
    WHERE 1 = 1' . $filterAktif . '
    GROUP BY r.status'
);
$stmt->execute($params);
$realisasiStatus = ['DRAFT' => 0, 'BERJALAN' => 0, 'SELESAI' => 0, 'DIBATALKAN' => 0];
foreach ($stmt->fetchAll() as $row) {
    $realisasiStatus[$row['status']] = (int) $row['jml'];
}

/* ---------------------------------------------------------------------
 * Peringatan
 * ------------------------------------------------------------------- */

$stmt = $pdo->prepare(
    'SELECT
        COALESCE(SUM(CASE
            WHEN TRIM(COALESCE(r.nomor_bast, \'\')) = \'\'
             AND r.status IN (\'BERJALAN\', \'SELESAI\')
             AND r.tanggal_selesai < CURDATE()
            THEN 1 ELSE 0 END), 0) AS bast_terlambat,
        COALESCE(SUM(CASE
            WHEN TRIM(COALESCE(r.nomor_bast, \'\')) = \'\'
             AND r.status = \'BERJALAN\'
             AND r.tanggal_selesai BETWEEN CURDATE()
                 AND DATE_ADD(CURDATE(), INTERVAL 14 DAY)
            THEN 1 ELSE 0 END), 0) AS segera_berakhir,
        COALESCE(SUM(CASE
            WHEN COALESCE(bayar.total, 0) > r.nilai_realisasi
            THEN 1 ELSE 0 END), 0) AS kelebihan_bayar,
        COALESCE(SUM(CASE
            WHEN r.status = \'SELESAI\'
             AND COALESCE(bayar.total, 0) < r.nilai_realisasi
            THEN 1 ELSE 0 END), 0) AS belum_lunas
    FROM realisasi_anggaran r
    INNER JOIN rincian_anggaran ra ON ra.id = r.rincian_anggaran_id'
    . $dasarTransaksi . '
    LEFT JOIN (
        SELECT realisasi_id, SUM(jumlah_dibayar) AS total
        FROM realisasi_pembayaran
        GROUP BY realisasi_id
    ) AS bayar ON bayar.realisasi_id = r.id
    WHERE r.status <> \'DIBATALKAN\'' . $filterAktif
);
$stmt->execute($params);
$peringatan = $stmt->fetch();

$stmt = $pdo->prepare(
    'SELECT COUNT(*) AS jml
    FROM rincian_anggaran ra
    ' . $dasarTransaksi . '
    WHERE ra.status <> \'DIBATALKAN\'
      AND NOT EXISTS (
          SELECT 1 FROM realisasi_anggaran r
          WHERE r.rincian_anggaran_id = ra.id
            AND r.status <> \'DIBATALKAN\'
      )' . $filterAktif
);
$stmt->execute($params);
$rincianTanpaRealisasi = (int) $stmt->fetchColumn();

/* Daftar singkat untuk kartu perhatian */
$stmt = $pdo->prepare(
    'SELECT r.id, r.tanggal_selesai, ra.kode_rup, ra.uraian,
            DATEDIFF(CURDATE(), r.tanggal_selesai) AS lewat
    FROM realisasi_anggaran r
    INNER JOIN rincian_anggaran ra ON ra.id = r.rincian_anggaran_id'
    . $dasarTransaksi . '
    WHERE r.status IN (\'BERJALAN\', \'SELESAI\')
      AND TRIM(COALESCE(r.nomor_bast, \'\')) = \'\'
      AND r.tanggal_selesai < CURDATE()' . $filterAktif . '
    ORDER BY r.tanggal_selesai ASC
    LIMIT 5'
);
$stmt->execute($params);
$bastTerlambatList = $stmt->fetchAll();

$stmt = $pdo->prepare(
    'SELECT r.id, r.tanggal_selesai, ra.kode_rup, ra.uraian,
            DATEDIFF(r.tanggal_selesai, CURDATE()) AS sisa_hari
    FROM realisasi_anggaran r
    INNER JOIN rincian_anggaran ra ON ra.id = r.rincian_anggaran_id'
    . $dasarTransaksi . '
    WHERE r.status = \'BERJALAN\'
      AND TRIM(COALESCE(r.nomor_bast, \'\')) = \'\'
      AND r.tanggal_selesai BETWEEN CURDATE()
          AND DATE_ADD(CURDATE(), INTERVAL 14 DAY)' . $filterAktif . '
    ORDER BY r.tanggal_selesai ASC
    LIMIT 5'
);
$stmt->execute($params);
$segeraBerakhirList = $stmt->fetchAll();

$stmt = $pdo->prepare(
    'SELECT r.id, r.nilai_realisasi, ra.kode_rup, ra.uraian,
            rz.total_dibayar
    FROM realisasi_anggaran r
    INNER JOIN rincian_anggaran ra ON ra.id = r.rincian_anggaran_id'
    . $dasarTransaksi . '
    INNER JOIN v_realisasi_ringkasan rz ON rz.realisasi_id = r.id
    WHERE r.status <> \'DIBATALKAN\'
      AND rz.total_dibayar > r.nilai_realisasi' . $filterAktif . '
    ORDER BY (rz.total_dibayar - r.nilai_realisasi) DESC
    LIMIT 5'
);
$stmt->execute($params);
$kelebihanBayarList = $stmt->fetchAll();

$adaPeringatan = (
    (int) $peringatan['bast_terlambat'] > 0 ||
    (int) $peringatan['segera_berakhir'] > 0 ||
    (int) $peringatan['kelebihan_bayar'] > 0 ||
    (int) $peringatan['belum_lunas'] > 0 ||
    $rincianTanpaRealisasi > 0
);

/* ---------------------------------------------------------------------
 * Serapan per kegiatan
 * ------------------------------------------------------------------- */

$stmt = $pdo->prepare(
    'SELECT
        k.id,
        k.kode_kegiatan,
        k.nama_kegiatan,
        k.tahun_anggaran,
        COUNT(DISTINCT sk.id) AS jml_sub,
        COUNT(DISTINCT ra.id) AS jml_rincian,
        COALESCE(SUM(ra.total_pagu), 0) AS pagu,
        COALESCE(SUM(rz.total_realisasi), 0) AS realisasi
    FROM kegiatan k
    LEFT JOIN sub_kegiatan sk ON sk.kegiatan_id = k.id
    LEFT JOIN rincian_anggaran ra
        ON ra.sub_kegiatan_id = sk.id AND ra.status <> \'DIBATALKAN\'
    LEFT JOIN v_rincian_ringkasan rz ON rz.rincian_id = ra.id
    WHERE 1 = 1' . $filterKegiatan . '
    GROUP BY k.id, k.kode_kegiatan, k.nama_kegiatan, k.tahun_anggaran
    ORDER BY pagu DESC, k.nama_kegiatan ASC
    LIMIT 8'
);
$stmt->execute($params);
$perKegiatan = $stmt->fetchAll();

/* ---------------------------------------------------------------------
 * Rekening dengan pagu terbesar
 * ------------------------------------------------------------------- */

$stmt = $pdo->prepare(
    'SELECT
        mr.kode_rekening,
        mr.nama_rekening,
        COALESCE(SUM(ra.total_pagu), 0) AS pagu,
        COALESCE(SUM(rz.total_realisasi), 0) AS realisasi
    FROM rincian_anggaran ra
    ' . $dasarTransaksi . '
    INNER JOIN master_rekening mr ON mr.id = ra.rekening_id
    LEFT JOIN v_rincian_ringkasan rz ON rz.rincian_id = ra.id
    WHERE ra.status <> \'DIBATALKAN\'' . $filterAktif . '
    GROUP BY mr.id, mr.kode_rekening, mr.nama_rekening
    ORDER BY pagu DESC
    LIMIT 6'
);
$stmt->execute($params);
$topRekening = $stmt->fetchAll();

$maxPaguRekening = 0.0;
foreach ($topRekening as $rek) {
    $maxPaguRekening = max($maxPaguRekening, (float) $rek['pagu']);
}

/* ---------------------------------------------------------------------
 * Aktivitas terbaru
 * ------------------------------------------------------------------- */

$stmt = $pdo->prepare(
    'SELECT
        r.id,
        r.status,
        r.metode,
        r.nilai_realisasi,
        r.tanggal_selesai,
        r.nomor_bast,
        ra.id AS rincian_id,
        ra.kode_rup,
        ra.uraian,
        COALESCE(p.nama_penyedia, r.pelaksana_swakelola) AS pelaksana,
        COALESCE(rz.total_dibayar, 0) AS total_dibayar
    FROM realisasi_anggaran r
    INNER JOIN rincian_anggaran ra ON ra.id = r.rincian_anggaran_id'
    . $dasarTransaksi . '
    LEFT JOIN master_penyedia p ON p.id = r.penyedia_id
    LEFT JOIN v_realisasi_ringkasan rz ON rz.realisasi_id = r.id
    WHERE 1 = 1' . $filterAktif . '
    ORDER BY r.id DESC
    LIMIT 6'
);
$stmt->execute($params);
$realisasiTerbaru = $stmt->fetchAll();

$stmt = $pdo->prepare(
    'SELECT
        b.id,
        b.tanggal_bayar,
        b.jenis,
        b.jumlah_dibayar,
        b.nomor_sp2d,
        ra.kode_rup,
        ra.uraian
    FROM realisasi_pembayaran b
    INNER JOIN realisasi_anggaran r ON r.id = b.realisasi_id
    INNER JOIN rincian_anggaran ra ON ra.id = r.rincian_anggaran_id'
    . $dasarTransaksi . '
    WHERE r.status <> \'DIBATALKAN\''
    . $filterAktif . '
    ORDER BY b.tanggal_bayar DESC, b.id DESC
    LIMIT 6'
);
$stmt->execute($params);
$pembayaranTerbaru = $stmt->fetchAll();

/* ---------------------------------------------------------------------
 * Perjalanan dinas
 * ------------------------------------------------------------------- */

$stmt = $pdo->prepare(
    'SELECT
        COUNT(*) AS jml_st,
        COALESCE(SUM(vp.jumlah_peserta), 0) AS jml_peserta,
        COALESCE(SUM(vp.total_biaya), 0) AS total_biaya
    FROM perjalanan_dinas pd
    INNER JOIN sub_kegiatan sk ON sk.id = pd.sub_kegiatan_id
    INNER JOIN kegiatan k ON k.id = sk.kegiatan_id
    LEFT JOIN v_perjalanan_ringkasan vp ON vp.perjalanan_id = pd.id
    WHERE 1 = 1' . $filterAktif
);
$stmt->execute($params);
$ringkasPerjadin = $stmt->fetch();

$stmt = $pdo->prepare(
    'SELECT
        pd.id,
        pd.nomor_st,
        pd.tanggal_berangkat,
        pd.tanggal_kembali,
        pd.tujuan,
        COALESCE(vp.jumlah_peserta, 0) AS jumlah_peserta,
        COALESCE(vp.total_biaya, 0) AS total_biaya
    FROM perjalanan_dinas pd
    INNER JOIN sub_kegiatan sk ON sk.id = pd.sub_kegiatan_id
    INNER JOIN kegiatan k ON k.id = sk.kegiatan_id
    LEFT JOIN v_perjalanan_ringkasan vp ON vp.perjalanan_id = pd.id
    WHERE 1 = 1' . $filterAktif . '
    ORDER BY pd.tanggal_berangkat DESC, pd.id DESC
    LIMIT 5'
);
$stmt->execute($params);
$perjadinTerbaru = $stmt->fetchAll();

$labelJenis = [
    'UANG_MUKA' => 'Uang Muka',
    'TERMIN'    => 'Termin',
    'PELUNASAN' => 'Pelunasan',
];

$judulPeriode = $tahun > 0 ? 'Tahun Anggaran ' . $tahun : 'Semua Tahun Anggaran';

require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/sidebar.php';
?>

<main class="main-content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Dashboard</h2>
            <p class="page-description">
                Ringkasan pagu, realisasi, dan pembayaran <?= e($judulPeriode) ?>.
            </p>
        </div>

        <div class="page-actions">
            <?php if (canManage()): ?>
                <a class="btn btn-light" href="<?= e(url('pages/pembayaran.php')) ?>">Catat Pembayaran</a>
                <a class="btn btn-success" href="<?= e(url('pages/realisasi.php')) ?>">Tambah Realisasi</a>
            <?php endif; ?>
        </div>
    </div>

    <form method="get" action="<?= e(url('index.php')) ?>" class="filter-bar">
        <div class="form-group">
            <label for="tahun">Tahun Anggaran</label>
            <select id="tahun" name="tahun" data-auto-submit>
                <option value="0">Semua Tahun</option>
                <?php foreach ($tahunList as $th): ?>
                    <option value="<?= $th ?>" <?= $tahun === $th ? 'selected' : '' ?>>
                        <?= $th ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <a class="btn btn-outline-dark btn-sm" href="<?= e(url('index.php')) ?>">Reset</a>
        <span class="text-muted">
            <?= e((string) $jumlah['kegiatan']) ?> kegiatan,
            <?= e((string) $jumlah['sub_kegiatan']) ?> sub kegiatan,
            <?= e((string) $kpi['jml_rincian']) ?> rincian anggaran
        </span>
    </form>

    <div class="kpi-grid">
        <article class="kpi">
            <span class="kpi-label">Total Pagu</span>
            <span class="kpi-value" title="<?= e(rupiah($pagu)) ?>">
                <?= e(rupiahRingkas($pagu)) ?>
            </span>
            <span class="kpi-sub">
                <?= e((string) $kpi['jml_rincian']) ?> rincian aktif
                &middot; <?= e((string) $jumlah['kegiatan']) ?> kegiatan
            </span>
        </article>

        <article class="kpi kpi--accent">
            <span class="kpi-label">Realisasi</span>
            <span class="kpi-value" title="<?= e(rupiah($totalRealisasi)) ?>">
                <?= e(rupiahRingkas($totalRealisasi)) ?>
            </span>
            <span class="kpi-sub">
                <strong><?= e(persen($persenSerapan)) ?></strong> dari pagu
            </span>
        </article>

        <article class="kpi kpi--info">
            <span class="kpi-label">Pembayaran</span>
            <span class="kpi-value" title="<?= e(rupiah($totalDibayar)) ?>">
                <?= e(rupiahRingkas($totalDibayar)) ?>
            </span>
            <span class="kpi-sub">
                <strong><?= e(persen($persenDibayar)) ?></strong> dari nilai realisasi
                &middot; <?= e((string) $jumlahPembayaran) ?> transaksi
            </span>
        </article>

        <article class="kpi <?= $sisaPagu < 0 ? 'kpi--danger' : 'kpi--warning' ?>">
            <span class="kpi-label">Sisa Pagu</span>
            <span class="kpi-value" title="<?= e(rupiah($sisaPagu)) ?>">
                <?= e(rupiahRingkas($sisaPagu)) ?>
            </span>
            <span class="kpi-sub">
                Belum dibayar <strong><?= e(rupiahRingkas($belumDibayar)) ?></strong>
            </span>
        </article>
    </div>

    <div class="grid-2">
        <section class="card">
            <div class="card-header">
                <div>
                    <h3>Serapan Anggaran</h3>
                    <p class="card-subtitle"><?= e($judulPeriode) ?></p>
                </div>
                <span class="chip"><?= e(persen($persenSerapan)) ?></span>
            </div>

            <div class="progress mb-16" role="progressbar"
                 aria-valuenow="<?= (int) min(100, round($persenSerapan)) ?>"
                 aria-valuemin="0" aria-valuemax="100">
                <div class="progress-bar" style="width:<?= e((string) min(100, max(0, $persenSerapan))) ?>%"></div>
            </div>

            <div class="stat-list">
                <div class="stat-row">
                    <span class="label">Pagu anggaran</span>
                    <span class="value"><?= rupiah($pagu) ?></span>
                </div>
                <div class="stat-row">
                    <span class="label">Nilai realisasi</span>
                    <span class="value"><?= rupiah($totalRealisasi) ?></span>
                </div>
                <div class="stat-row">
                    <span class="label">Sisa pagu</span>
                    <span class="value <?= $sisaPagu < 0 ? 'text-danger' : '' ?>">
                        <?= rupiah($sisaPagu) ?>
                    </span>
                </div>
                <div class="stat-row">
                    <span class="label">Sudah dibayar</span>
                    <span class="value"><?= rupiah($totalDibayar) ?></span>
                </div>
                <div class="stat-row">
                    <span class="label">Belum dibayar</span>
                    <span class="value"><?= rupiah($belumDibayar) ?></span>
                </div>
            </div>

            <?php if ($sisaPagu < 0): ?>
                <div class="alert alert-danger mb-0" style="margin-top:16px">
                    Realisasi melebihi pagu sebesar <?= rupiah(abs($sisaPagu)) ?>.
                </div>
            <?php endif; ?>
        </section>

        <section class="card">
            <div class="card-header">
                <div>
                    <h3>Status Data</h3>
                    <p class="card-subtitle">Distribusi status rincian dan realisasi.</p>
                </div>
            </div>

            <div class="stat-list mb-16">
                <div class="stat-row">
                    <span class="label">Rincian anggaran</span>
                    <span class="value"><?= e((string) $jumlah['rincian']) ?> data</span>
                </div>
                <div class="stat-row">
                    <span class="label">Realisasi</span>
                    <span class="value"><?= e((string) $jumlah['realisasi']) ?> data</span>
                </div>
                <div class="stat-row">
                    <span class="label">Pembayaran tercatat</span>
                    <span class="value"><?= e((string) $jumlahPembayaran) ?> transaksi</span>
                </div>
            </div>

            <div class="stat-list">
                <?php foreach ($rincianStatus as $status => $jml): ?>
                    <div class="stat-row">
                        <span class="label">Rincian <?= e(ucfirst(strtolower($status))) ?></span>
                        <span class="value"><?= statusBadge($status) ?> <?= $jml ?></span>
                    </div>
                <?php endforeach; ?>

                <?php foreach ($realisasiStatus as $status => $jml): ?>
                    <div class="stat-row">
                        <span class="label">Realisasi <?= e(ucfirst(strtolower($status))) ?></span>
                        <span class="value"><?= statusBadge($status) ?> <?= $jml ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </div>

    <section class="card">
        <div class="card-header">
            <div>
                <h3>Perlu Perhatian</h3>
                <p class="card-subtitle">Pemeriksaan otomatis terhadap data realisasi dan pembayaran.</p>
            </div>
            <?php if (!empty($bastTerlambatList)): ?>
                <a class="btn btn-light btn-sm" href="<?= e(url('pages/realisasi.php')) ?>">
                    Buka Realisasi
                </a>
            <?php endif; ?>
        </div>

        <?php if (!$adaPeringatan): ?>
            <div class="empty-state">
                <strong>Tidak ada peringatan.</strong>
                Semua realisasi tercatat lengkap untuk periode ini.
            </div>
        <?php else: ?>
            <div class="stat-list mb-16">
                <?php if ((int) $peringatan['bast_terlambat'] > 0): ?>
                    <div class="alert alert-danger mb-0">
                        <strong><?= (int) $peringatan['bast_terlambat'] ?> realisasi</strong>
                        melewati tanggal selesai tetapi BAST belum diisi.
                    </div>
                <?php endif; ?>

                <?php if ((int) $peringatan['segera_berakhir'] > 0): ?>
                    <div class="alert alert-warning mb-0">
                        <strong><?= (int) $peringatan['segera_berakhir'] ?> realisasi</strong>
                        akan berakhir dalam 14 hari ke depan.
                    </div>
                <?php endif; ?>

                <?php if ((int) $peringatan['kelebihan_bayar'] > 0): ?>
                    <div class="alert alert-danger mb-0">
                        <strong><?= (int) $peringatan['kelebihan_bayar'] ?> realisasi</strong>
                        memiliki total pembayaran melebihi nilai realisasi.
                    </div>
                <?php endif; ?>

                <?php if ((int) $peringatan['belum_lunas'] > 0): ?>
                    <div class="alert alert-info mb-0">
                        <strong><?= (int) $peringatan['belum_lunas'] ?> realisasi</strong>
                        berstatus Selesai tetapi belum dibayar penuh.
                    </div>
                <?php endif; ?>

                <?php if ($rincianTanpaRealisasi > 0): ?>
                    <div class="alert alert-info mb-0">
                        <strong><?= $rincianTanpaRealisasi ?> rincian anggaran</strong>
                        belum memiliki realisasi.
                    </div>
                <?php endif; ?>
            </div>

            <?php if (!empty($bastTerlambatList)): ?>
                <div class="table-wrapper">
                    <table class="table-compact">
                        <thead>
                            <tr>
                                <th>Kode RUP</th>
                                <th>Uraian</th>
                                <th>Tanggal Selesai</th>
                                <th class="num">Terlambat</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bastTerlambatList as $row): ?>
                                <tr>
                                    <td><?= e($row['kode_rup']) ?></td>
                                    <td><?= e($row['uraian']) ?></td>
                                    <td class="nowrap"><?= e(tanggalIndo($row['tanggal_selesai'])) ?></td>
                                    <td class="num text-danger"><?= (int) $row['lewat'] ?> hari</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </section>

    <section class="card">
        <div class="card-header">
            <div>
                <h3>Realisasi per Kegiatan</h3>
                <p class="card-subtitle">Serapan anggaran tiap kegiatan pada periode terpilih.</p>
            </div>
        </div>

        <?php if (empty($perKegiatan)): ?>
            <div class="empty-state">
                <strong>Belum ada kegiatan.</strong>
                Tambahkan kegiatan terlebih dahulu melalui menu Kegiatan.
            </div>
        <?php else: ?>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Kegiatan</th>
                            <th>Tahun</th>
                            <th class="num">Sub</th>
                            <th class="num">Rincian</th>
                            <th class="num">Pagu</th>
                            <th class="num">Realisasi</th>
                            <th class="num">Sisa</th>
                            <th style="min-width:150px">Serapan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($perKegiatan as $i => $row): ?>
                            <?php
                            $paguRow = (float) $row['pagu'];
                            $realRow = (float) $row['realisasi'];
                            $sisaRow = $paguRow - $realRow;
                            $persenRow = $paguRow > 0 ? $realRow / $paguRow * 100 : 0;
                            ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td>
                                    <strong><?= e($row['kode_kegiatan']) ?></strong><br>
                                    <span class="text-muted"><?= e($row['nama_kegiatan']) ?></span>
                                </td>
                                <td class="nowrap"><?= e($row['tahun_anggaran']) ?></td>
                                <td class="num"><?= (int) $row['jml_sub'] ?></td>
                                <td class="num"><?= (int) $row['jml_rincian'] ?></td>
                                <td class="num"><?= rupiah($paguRow) ?></td>
                                <td class="num"><?= rupiah($realRow) ?></td>
                                <td class="num"><?= rupiah($sisaRow) ?></td>
                                <td>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar--accent"
                                             style="width:<?= e((string) min(100, max(0, $persenRow))) ?>%"></div>
                                    </div>
                                    <div class="progress-meta">
                                        <span><?= e(persen($persenRow)) ?></span>
                                        <span><?= $sisaRow < 0 ? 'Melebihi pagu' : 'dari pagu' ?></span>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>

    <div class="grid-2">
        <section class="card">
            <div class="card-header">
                <div>
                    <h3>Rekening dengan Pagu Terbesar</h3>
                    <p class="card-subtitle">Enam kode rekening teratas.</p>
                </div>
            </div>

            <?php if (empty($topRekening)): ?>
                <div class="empty-state">Belum ada rincian anggaran.</div>
            <?php else: ?>
                <div class="bar-list">
                    <?php foreach ($topRekening as $rek): ?>
                        <?php
                        $paguRek = (float) $rek['pagu'];
                        $realRek = (float) $rek['realisasi'];
                        $persenRek = $paguRek > 0 ? $realRek / $paguRek * 100 : 0;
                        $lebarRek = $maxPaguRekening > 0 ? $paguRek / $maxPaguRekening * 100 : 0;
                        ?>
                        <div class="bar-item">
                            <div class="bar-head">
                                <span class="bar-title" title="<?= e($rek['nama_rekening']) ?>">
                                    <?= e($rek['kode_rekening']) ?>
                                </span>
                                <span class="bar-value"><?= rupiahRingkas($paguRek) ?></span>
                            </div>
                            <div class="progress">
                                <div class="progress-bar" style="width:<?= e((string) min(100, $lebarRek)) ?>%"></div>
                            </div>
                            <div class="progress-meta">
                                <span><?= e($rek['nama_rekening']) ?></span>
                                <span>Serapan <?= e(persen($persenRek)) ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <section class="card">
            <div class="card-header">
                <div>
                    <h3>Pembayaran Terbaru</h3>
                    <p class="card-subtitle">Enam transaksi pembayaran terakhir.</p>
                </div>
                <a class="btn btn-light btn-sm" href="<?= e(url('pages/pembayaran.php')) ?>">Lihat semua</a>
            </div>

            <?php if (empty($pembayaranTerbaru)): ?>
                <div class="empty-state">Belum ada pembayaran.</div>
            <?php else: ?>
                <ul class="timeline">
                    <?php foreach ($pembayaranTerbaru as $bayarRow): ?>
                        <li>
                            <span class="tgl"><?= e(tanggalIndo($bayarRow['tanggal_bayar'])) ?></span>
                            <span class="isi">
                                <strong><?= e($bayarRow['kode_rup']) ?></strong>
                                <small>
                                    <?= e($labelJenis[$bayarRow['jenis']] ?? $bayarRow['jenis']) ?>
                                    <?php if (!empty($bayarRow['nomor_sp2d'])): ?>
                                        &middot; SP2D <?= e($bayarRow['nomor_sp2d']) ?>
                                    <?php endif; ?>
                                </small>
                                <small><?= e($bayarRow['uraian']) ?></small>
                            </span>
                            <span class="nominal"><?= rupiah($bayarRow['jumlah_dibayar']) ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </section>
    </div>

    <section class="card">
        <div class="card-header">
            <div>
                <h3>Realisasi Terbaru</h3>
                <p class="card-subtitle">Enam data realisasi terakhir pada periode ini.</p>
            </div>
            <a class="btn btn-light btn-sm" href="<?= e(url('pages/realisasi.php')) ?>">Lihat semua</a>
        </div>

        <?php if (empty($realisasiTerbaru)): ?>
            <div class="empty-state">Belum ada realisasi anggaran.</div>
        <?php else: ?>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Kode RUP</th>
                            <th>Uraian</th>
                            <th>Pelaksana</th>
                            <th class="num">Nilai</th>
                            <th class="num">Dibayar</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($realisasiTerbaru as $row): ?>
                            <tr>
                                <td class="nowrap"><?= e($row['kode_rup']) ?></td>
                                <td><?= e($row['uraian']) ?></td>
                                <td><?= e($row['pelaksana'] ?? '-') ?></td>
                                <td class="num"><?= rupiah($row['nilai_realisasi']) ?></td>
                                <td class="num"><?= rupiah($row['total_dibayar']) ?></td>
                                <td><?= statusBadge($row['status']) ?></td>
                                <td>
                                    <a
                                        class="btn btn-light btn-sm"
                                        href="<?= e(url('pages/anggaran_detail.php?id=' . (int) $row['rincian_id'])) ?>"
                                    >Detail</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>

    <section class="card">
        <div class="card-header">
            <div>
                <h3>Perjalanan Dinas</h3>
                <p class="card-subtitle">Rekap belanja perjalanan dinas pada periode ini.</p>
            </div>
            <div class="page-actions">
                <a
                    class="btn btn-light btn-sm"
                    href="<?= e(url('pages/perjalanan_dinas_cetak.php?tahun=' . $tahun)) ?>"
                >Buka Rekap</a>
                <?php if (canManage()): ?>
                    <a
                        class="btn btn-success btn-sm"
                        href="<?= e(url('pages/perjalanan_dinas.php')) ?>"
                    >Catat Perjalanan</a>
                <?php endif; ?>
            </div>
        </div>

        <div class="grid-2">
            <div class="stat-list">
                <div class="stat-row">
                    <span class="label">Surat tugas</span>
                    <span class="value"><?= (int) $ringkasPerjadin['jml_st'] ?> surat tugas</span>
                </div>
                <div class="stat-row">
                    <span class="label">Peserta</span>
                    <span class="value"><?= (int) $ringkasPerjadin['jml_peserta'] ?> orang</span>
                </div>
                <div class="stat-row">
                    <span class="label">Total biaya</span>
                    <span class="value"><strong><?= rupiah($ringkasPerjadin['total_biaya']) ?></strong></span>
                </div>
            </div>

            <div>
                <?php if (empty($perjadinTerbaru)): ?>
                    <div class="empty-state">Belum ada perjalanan dinas.</div>
                <?php else: ?>
                    <ul class="timeline">
                        <?php foreach ($perjadinTerbaru as $pdRow): ?>
                            <li>
                                <span class="tgl"><?= e(tanggalIndo($pdRow['tanggal_berangkat'])) ?></span>
                                <span class="isi">
                                    <strong><?= e($pdRow['nomor_st']) ?></strong>
                                    <small><?= e($pdRow['tujuan']) ?></small>
                                    <small><?= (int) $pdRow['jumlah_peserta'] ?> peserta</small>
                                </span>
                                <span class="nominal"><?= rupiah($pdRow['total_biaya']) ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php if (canManage()): ?>
        <section class="card">
            <div class="card-header">
                <div>
                    <h3>Aksi Cepat</h3>
                    <p class="card-subtitle">Lanjutkan pencatatan data anggaran.</p>
                </div>
            </div>
            <div class="page-actions">
                <a class="btn btn-light" href="<?= e(url('pages/kegiatan.php')) ?>">Tambah Kegiatan</a>
                <a class="btn btn-light" href="<?= e(url('pages/sub_kegiatan.php')) ?>">Tambah Sub Kegiatan</a>
                <a class="btn btn-light" href="<?= e(url('pages/anggaran.php')) ?>">Tambah Rincian Anggaran</a>
                <a class="btn btn-light" href="<?= e(url('pages/perjalanan_dinas.php')) ?>">Catat Perjalanan Dinas</a>
                <a class="btn btn-success" href="<?= e(url('pages/realisasi.php')) ?>">Tambah Realisasi</a>
            </div>
        </section>
    <?php endif; ?>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
