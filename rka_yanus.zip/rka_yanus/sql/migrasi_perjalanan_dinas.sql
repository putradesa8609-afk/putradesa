-- =====================================================================
-- Migrasi modul Rekap Perjalanan Dinas
--
-- Jalankan sekali pada database yang sudah ada:
--   phpMyAdmin : tab Import, pilih file ini, klik Go.
--   Terminal   : mysql -u root -p db_rka_yanus < sql/migrasi_perjalanan_dinas.sql
--
-- Aman dijalankan berulang (CREATE TABLE IF NOT EXISTS dan
-- CREATE OR REPLACE VIEW).
-- =====================================================================

USE db_rka_yanus;

CREATE TABLE IF NOT EXISTS perjalanan_dinas (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    sub_kegiatan_id BIGINT UNSIGNED NOT NULL,
    rekening_id BIGINT UNSIGNED NOT NULL,
    nomor_st VARCHAR(100) NOT NULL,
    tanggal_st DATE NOT NULL,
    maksud VARCHAR(500) NOT NULL,
    tujuan VARCHAR(255) NOT NULL,
    lama_hari INT NOT NULL DEFAULT 1,
    tanggal_berangkat DATE NOT NULL,
    tanggal_kembali DATE NOT NULL,
    catatan TEXT NULL,
    dibuat_oleh BIGINT UNSIGNED NULL,
    dibuat_pada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    diperbarui_pada TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_pd_nomor_st (nomor_st),
    KEY idx_pd_tanggal (tanggal_berangkat),
    KEY idx_pd_sub_kegiatan (sub_kegiatan_id),
    KEY idx_pd_rekening (rekening_id),
    KEY idx_pd_dibuat_oleh (dibuat_oleh),
    CONSTRAINT fk_pd_sub_kegiatan
      FOREIGN KEY (sub_kegiatan_id) REFERENCES sub_kegiatan(id)
      ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_pd_rekening
      FOREIGN KEY (rekening_id) REFERENCES master_rekening(id)
      ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_pd_pengguna
      FOREIGN KEY (dibuat_oleh) REFERENCES pengguna(id)
      ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT chk_pd_lama_hari CHECK (lama_hari >= 1 AND lama_hari <= 365),
    CONSTRAINT chk_pd_tanggal CHECK (tanggal_kembali >= tanggal_berangkat)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS perjalanan_dinas_peserta (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    perjalanan_id BIGINT UNSIGNED NOT NULL,
    nama VARCHAR(150) NOT NULL,
    nip VARCHAR(30) NULL,
    pangkat VARCHAR(100) NULL,
    golongan_ruang VARCHAR(20) NULL,
    jabatan VARCHAR(150) NULL,
    nama_hotel VARCHAR(200) NULL,
    tanggal_check_in DATE NULL,
    tanggal_check_out DATE NULL,
    uang_harian DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    penginapan DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    representasi DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    transport_lokal DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    taksi_sewa DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    bbm DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    biaya_lain DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    total_biaya DECIMAL(18,2) GENERATED ALWAYS AS (
        ROUND(
            uang_harian + penginapan + representasi + transport_lokal
            + taksi_sewa + bbm + biaya_lain,
            2
        )
    ) STORED,
    dibuat_pada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_pdp_perjalanan (perjalanan_id),
    CONSTRAINT fk_pdp_perjalanan
      FOREIGN KEY (perjalanan_id) REFERENCES perjalanan_dinas(id)
      ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_pdp_uang_harian CHECK (uang_harian >= 0),
    CONSTRAINT chk_pdp_penginapan CHECK (penginapan >= 0),
    CONSTRAINT chk_pdp_representasi CHECK (representasi >= 0),
    CONSTRAINT chk_pdp_transport CHECK (transport_lokal >= 0),
    CONSTRAINT chk_pdp_taksi CHECK (taksi_sewa >= 0),
    CONSTRAINT chk_pdp_bbm CHECK (bbm >= 0),
    CONSTRAINT chk_pdp_biaya_lain CHECK (biaya_lain >= 0),
    CONSTRAINT chk_pdp_menginap CHECK (
        tanggal_check_out IS NULL
        OR tanggal_check_in IS NULL
        OR tanggal_check_out >= tanggal_check_in
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE OR REPLACE VIEW v_perjalanan_ringkasan AS
SELECT
    pd.id AS perjalanan_id,
    COUNT(p.id) AS jumlah_peserta,
    COALESCE(SUM(p.total_biaya), 0) AS total_biaya
FROM perjalanan_dinas AS pd
LEFT JOIN perjalanan_dinas_peserta AS p ON p.perjalanan_id = pd.id
GROUP BY pd.id;

-- Kolom jabatan untuk instalasi yang sudah memiliki tabel peserta
ALTER TABLE perjalanan_dinas_peserta
ADD COLUMN IF NOT EXISTS jabatan VARCHAR(150) NULL AFTER golongan_ruang;
