-- =====================================================================
-- Migrasi: kategori belanja pada rincian anggaran
-- Jalankan sekali pada database yang sudah berjalan.
-- =====================================================================

ALTER TABLE rincian_anggaran
    ADD COLUMN IF NOT EXISTS kategori_belanja
        ENUM('BARANG','JASA','MODAL','PERJALANAN_DINAS','PEMELIHARAAN')
        NULL DEFAULT NULL
        AFTER uraian;

CREATE INDEX IF NOT EXISTS idx_rincian_kategori
    ON rincian_anggaran (kategori_belanja);
